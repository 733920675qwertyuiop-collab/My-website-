import fs from 'fs';
import path from 'path';

const outDir = path.resolve(process.cwd(), 'public/assets/projects');
if (!fs.existsSync(outDir)) {
  fs.mkdirSync(outDir, { recursive: true });
}

interface ProjectMockupDef {
  id: string;
  titleEn: string;
  titleAr: string;
  tag: string;
  primaryColor: string;
  secondaryColor: string;
  stats: { label: string; val: string; sub?: string; color?: string }[];
  centerGraphic: string;
}

const projects: ProjectMockupDef[] = [
  {
    id: 'tareeqi',
    titleEn: 'Tareeqi // Yemeni Smart Transport Platform',
    titleAr: 'طريقي — منصة النقل والمواصلات الذكية',
    tag: 'ANDROID + PHP',
    primaryColor: '#f97316',
    secondaryColor: '#38bdf8',
    stats: [
      { label: 'ACTIVE FLEET BUSES', val: '428 Units', color: '#f97316' },
      { label: 'BOOKED SEATS TODAY', val: '3,840 Pax', color: '#38bdf8' },
      { label: 'INTERCITY ROUTES', val: '34 Lines', color: '#4ade80' },
      { label: 'DISPATCH LATENCY', val: '42 ms', color: '#fbbf24' }
    ],
    centerGraphic: `
      <!-- GPS Map Telemetry -->
      <g transform="translate(300, 220)">
        <text x="20" y="30" fill="#f97316" font-family="monospace" font-size="14" font-weight="bold">◈ REAL-TIME INTERCITY GPS ROUTING &amp; DISPATCH</text>
        <!-- Map Canvas -->
        <rect x="20" y="45" width="540" height="340" rx="10" fill="#060910" stroke="rgba(249, 115, 22, 0.3)"/>
        <!-- Route paths -->
        <path d="M 60 300 Q 180 200 240 220 T 400 120 T 500 80" fill="none" stroke="#f97316" stroke-width="4" stroke-dasharray="8 4"/>
        <path d="M 60 300 Q 160 270 280 290 T 480 260" fill="none" stroke="#38bdf8" stroke-width="3"/>
        <!-- Waypoints -->
        <circle cx="60" cy="300" r="8" fill="#f97316" filter="drop-shadow(0 0 6px #f97316)"/>
        <text x="75" y="305" fill="#ffffff" font-family="sans-serif" font-size="12" font-weight="bold">Aden Depot</text>
        <circle cx="240" cy="220" r="6" fill="#38bdf8"/>
        <text x="255" y="225" fill="#94a3b8" font-family="sans-serif" font-size="11">Taiz Transfer</text>
        <circle cx="400" cy="120" r="6" fill="#38bdf8"/>
        <text x="415" y="125" fill="#94a3b8" font-family="sans-serif" font-size="11">Ibb Waypoint</text>
        <circle cx="500" cy="80" r="9" fill="#22c55e" filter="drop-shadow(0 0 8px #22c55e)"/>
        <text x="515" y="85" fill="#ffffff" font-family="sans-serif" font-size="12" font-weight="bold">Sanaa Terminal</text>
        <!-- Vehicle Markers -->
        <rect x="180" y="195" width="30" height="18" rx="4" fill="#f97316"/>
        <text x="186" y="208" fill="#000000" font-family="monospace" font-size="9" font-weight="bold">BUS #12</text>
        <rect x="340" y="145" width="30" height="18" rx="4" fill="#38bdf8"/>
        <text x="346" y="158" fill="#000000" font-family="monospace" font-size="9" font-weight="bold">BUS #08</text>
      </g>
      <!-- Ticket Manifest Side Panel -->
      <g transform="translate(880, 265)">
        <rect width="250" height="340" rx="10" fill="#090c14" stroke="rgba(255, 255, 255, 0.08)"/>
        <text x="20" y="30" fill="#ffffff" font-family="sans-serif" font-size="13" font-weight="bold">Live Boarding Pass</text>
        <rect x="20" y="45" width="210" height="90" rx="8" fill="#0f1422" stroke="rgba(249, 115, 22, 0.4)"/>
        <text x="35" y="70" fill="#f97316" font-family="monospace" font-size="14" font-weight="bold">TK-8942-YE</text>
        <text x="35" y="90" fill="#94a3b8" font-family="sans-serif" font-size="11">Passenger: Ahmed M.</text>
        <text x="35" y="110" fill="#38bdf8" font-family="sans-serif" font-size="11">Seat: 14A · VIP Coach</text>
        <!-- QR Code Placeholder -->
        <rect x="35" y="150" width="80" height="80" fill="#ffffff"/>
        <rect x="45" y="160" width="20" height="20" fill="#000000"/>
        <rect x="85" y="160" width="20" height="20" fill="#000000"/>
        <rect x="45" y="200" width="20" height="20" fill="#000000"/>
        <text x="130" y="180" fill="#4ade80" font-family="monospace" font-size="11">● QR VALIDATED</text>
        <text x="130" y="200" fill="#64748b" font-family="monospace" font-size="10">GATE: 03</text>
      </g>`
  },
  {
    id: 'legaci',
    titleEn: 'Legaci // Digital Inheritance Vault',
    titleAr: 'منصة الميراث الرقمي والتركات الإلكترونية',
    tag: 'SECURE VAULT',
    primaryColor: '#6366f1',
    secondaryColor: '#f97316',
    stats: [
      { label: 'ESTATE ASSETS ENCRYPTED', val: '$1,284,450', color: '#6366f1' },
      { label: 'BENEFICIARIES LINKED', val: '8 Designees', color: '#f97316' },
      { label: 'MULTI-SIG CONSENSUS', val: '3 of 5 Keys', color: '#22c55e' },
      { label: 'SHARIA DISTRIBUTION', val: 'Verified 100%', color: '#38bdf8' }
    ],
    centerGraphic: `
      <g transform="translate(300, 220)">
        <text x="20" y="30" fill="#6366f1" font-family="monospace" font-size="14" font-weight="bold">◈ CRYPTOGRAPHIC VAULT &amp; HEIR ALLOCATION PROTOCOL</text>
        <!-- Vault Core Diagram -->
        <rect x="20" y="45" width="460" height="340" rx="10" fill="#060910" stroke="rgba(99, 102, 241, 0.4)"/>
        <!-- Vault Rings -->
        <circle cx="250" cy="210" r="110" fill="none" stroke="#6366f1" stroke-width="2" stroke-dasharray="6 4"/>
        <circle cx="250" cy="210" r="80" fill="none" stroke="#f97316" stroke-width="3"/>
        <circle cx="250" cy="210" r="45" fill="#0d111a" stroke="#22c55e" stroke-width="2"/>
        <text x="250" y="215" fill="#ffffff" font-family="monospace" font-size="12" text-anchor="middle" font-weight="bold">AES-256</text>
        <!-- Key Nodes -->
        <circle cx="150" cy="150" r="14" fill="#6366f1"/>
        <text x="150" y="154" fill="#ffffff" font-family="monospace" font-size="10" text-anchor="middle">K1</text>
        <circle cx="350" cy="150" r="14" fill="#6366f1"/>
        <text x="350" y="154" fill="#ffffff" font-family="monospace" font-size="10" text-anchor="middle">K2</text>
        <circle cx="250" cy="310" r="14" fill="#22c55e"/>
        <text x="250" y="314" fill="#ffffff" font-family="monospace" font-size="10" text-anchor="middle">K3</text>
      </g>
      <!-- Sharia Allocation Pie Breakdown -->
      <g transform="translate(800, 265)">
        <rect width="330" height="340" rx="10" fill="#090c14" stroke="rgba(255, 255, 255, 0.08)"/>
        <text x="20" y="30" fill="#ffffff" font-family="sans-serif" font-size="13" font-weight="bold">Sharia Estate Distribution</text>
        <g transform="translate(20, 50)">
          <rect y="0" width="290" height="40" rx="6" fill="#0f1422"/>
          <text x="15" y="25" fill="#ffffff" font-family="sans-serif" font-size="12">Wife (1/8th Share)</text>
          <text x="240" y="25" fill="#6366f1" font-family="monospace" font-size="12" font-weight="bold">12.5%</text>

          <rect y="48" width="290" height="40" rx="6" fill="#0f1422"/>
          <text x="15" y="73" fill="#ffffff" font-family="sans-serif" font-size="12">Sons Residuaries (Asaba)</text>
          <text x="240" y="73" fill="#f97316" font-family="monospace" font-size="12" font-weight="bold">58.3%</text>

          <rect y="96" width="290" height="40" rx="6" fill="#0f1422"/>
          <text x="15" y="121" fill="#ffffff" font-family="sans-serif" font-size="12">Daughters Proportionate</text>
          <text x="240" y="121" fill="#22c55e" font-family="monospace" font-size="12" font-weight="bold">29.2%</text>
        </g>
      </g>`
  },
  {
    id: 'dawrak',
    titleEn: 'Dawrak // Queue Management & Smart Kiosk',
    titleAr: 'دورك — نظام إدارة الطوابير والشاشات الذكية',
    tag: 'KIOSK & QUEUE',
    primaryColor: '#10b981',
    secondaryColor: '#f97316',
    stats: [
      { label: 'NOW SERVING', val: '#A28 - Dental', color: '#10b981' },
      { label: 'AVG WAIT TIME', val: '4.2 Minutes', color: '#f97316' },
      { label: 'TICKETS TODAY', val: '1,420 Issued', color: '#38bdf8' },
      { label: 'COUNTER SERVICE', val: '12 Active', color: '#ffffff' }
    ],
    centerGraphic: `
      <g transform="translate(300, 220)">
        <text x="20" y="30" fill="#10b981" font-family="monospace" font-size="14" font-weight="bold">◈ CENTRAL COUNTER DISPATCH &amp; AUDIBLE CALL MATRIX</text>
        <rect x="20" y="45" width="480" height="340" rx="10" fill="#070c12" stroke="rgba(16, 185, 129, 0.4)"/>
        <!-- Big Number Display -->
        <rect x="40" y="70" width="440" height="140" rx="12" fill="#0d191d" stroke="#10b981" stroke-width="2"/>
        <text x="260" y="145" fill="#10b981" font-family="monospace" font-size="64" font-weight="bold" text-anchor="middle" filter="drop-shadow(0 0 10px #10b981)">#A-28</text>
        <text x="260" y="185" fill="#f8fafc" font-family="'Tajawal', sans-serif" font-size="18" text-anchor="middle">تفضل إلى شباك رقم 3 // كشف الأسنان</text>
        
        <!-- Live Counter Matrix -->
        <g transform="translate(40, 230)">
          <rect x="0" y="0" width="135" height="60" rx="8" fill="#0a1216"/>
          <text x="15" y="25" fill="#94a3b8" font-family="monospace" font-size="11">COUNTER 1</text>
          <text x="15" y="50" fill="#38bdf8" font-family="monospace" font-size="18" font-weight="bold">#B-14</text>

          <rect x="150" y="0" width="135" height="60" rx="8" fill="#0a1216"/>
          <text x="165" y="25" fill="#94a3b8" font-family="monospace" font-size="11">COUNTER 2</text>
          <text x="165" y="50" fill="#fbbf24" font-family="monospace" font-size="18" font-weight="bold">#A-27</text>

          <rect x="300" y="0" width="140" height="60" rx="8" fill="#0a1216"/>
          <text x="315" y="25" fill="#94a3b8" font-family="monospace" font-size="11">COUNTER 3</text>
          <text x="315" y="50" fill="#10b981" font-family="monospace" font-size="18" font-weight="bold">#A-28</text>
        </g>
      </g>
      <!-- Kiosk Specs Panel -->
      <g transform="translate(820, 265)">
        <rect width="310" height="340" rx="10" fill="#090c14" stroke="rgba(255, 255, 255, 0.08)"/>
        <text x="20" y="30" fill="#ffffff" font-family="sans-serif" font-size="13" font-weight="bold">Self-Service Touch Kiosk</text>
        <rect x="20" y="50" width="270" height="180" rx="8" fill="#0f1422" stroke="#10b981"/>
        <text x="40" y="85" fill="#f97316" font-family="sans-serif" font-size="14" font-weight="bold">اختر نوع الخدمة:</text>
        <rect x="40" y="105" width="230" height="36" rx="6" fill="#1e293b"/>
        <text x="55" y="128" fill="#ffffff" font-family="sans-serif" font-size="12">1. فتح ملف مريض جديد</text>
        <rect x="40" y="148" width="230" height="36" rx="6" fill="#1e293b"/>
        <text x="55" y="171" fill="#ffffff" font-family="sans-serif" font-size="12">2. مراجعة العيادات التخصصية</text>
      </g>`
  },
  {
    id: 'baseera_ai',
    titleEn: 'Baseera AI // Medical Diagnostics & Neuro-Imaging',
    titleAr: 'بصيرة AI — منصة التشخيص الطبي بالذكاء الاصطناعي',
    tag: 'DEEP LEARNING',
    primaryColor: '#ec4899',
    secondaryColor: '#38bdf8',
    stats: [
      { label: 'SCAN ACCURACY', val: '99.2%', color: '#ec4899' },
      { label: 'PROCESSED SCANS', val: '18,420 MRIs', color: '#38bdf8' },
      { label: 'ANOMALY DETECTIONS', val: '14 Flagged', color: '#f97316' },
      { label: 'INFERENCE SPEED', val: '180 ms', color: '#22c55e' }
    ],
    centerGraphic: `
      <g transform="translate(300, 220)">
        <text x="20" y="30" fill="#ec4899" font-family="monospace" font-size="14" font-weight="bold">◈ CRANIAL CT / MRI HEATMAP &amp; LESION SEGMENTATION</text>
        <rect x="20" y="45" width="480" height="340" rx="10" fill="#05070e" stroke="rgba(236, 72, 153, 0.4)"/>
        <!-- MRI Slice Simulation -->
        <ellipse cx="260" cy="215" rx="150" ry="120" fill="#0d1424" stroke="#38bdf8" stroke-width="2"/>
        <ellipse cx="260" cy="215" rx="110" ry="85" fill="#111c33" stroke="rgba(255, 255, 255, 0.1)"/>
        <!-- Neural Heatmap Overlay -->
        <circle cx="210" cy="180" r="35" fill="rgba(236, 72, 153, 0.55)" filter="drop-shadow(0 0 15px #ec4899)"/>
        <rect x="160" y="130" width="100" height="95" fill="none" stroke="#f97316" stroke-width="2" stroke-dasharray="4 2"/>
        <text x="165" y="125" fill="#f97316" font-family="monospace" font-size="10" font-weight="bold">LESION CONF: 98.4%</text>
      </g>
      <!-- Diagnostic Telemetry -->
      <g transform="translate(820, 265)">
        <rect width="310" height="340" rx="10" fill="#090c14" stroke="rgba(255, 255, 255, 0.08)"/>
        <text x="20" y="30" fill="#ffffff" font-family="sans-serif" font-size="13" font-weight="bold">Tensor Flow Telemetry</text>
        <rect x="20" y="50" width="270" height="50" rx="6" fill="#0f172a"/>
        <text x="35" y="75" fill="#94a3b8" font-family="monospace" font-size="11">MODEL: DenseNet-161</text>
        <text x="35" y="92" fill="#ec4899" font-family="monospace" font-size="11">WEIGHTS: v4.2 Medical</text>
      </g>`
  },
  {
    id: 'miqwat',
    titleEn: 'Miqwat // Agricultural Produce & Crop Logistics',
    titleAr: 'مِقوَات — منصة تسويق المحاصيل والبورصة الزراعية',
    tag: 'AGRI-TECH B2B',
    primaryColor: '#84cc16',
    secondaryColor: '#f97316',
    stats: [
      { label: 'REGISTERED FARMS', val: '860 Farms', color: '#84cc16' },
      { label: 'DAILY TONNAGE', val: '142 Tons', color: '#f97316' },
      { label: 'MARKET PRICE ACCURACY', val: '100% Live', color: '#38bdf8' },
      { label: 'LOGISTICS VANS', val: '76 Active', color: '#ffffff' }
    ],
    centerGraphic: `
      <g transform="translate(300, 220)">
        <text x="20" y="30" fill="#84cc16" font-family="monospace" font-size="14" font-weight="bold">◈ CROP AUCTION COMMODITIES &amp; HARVEST LOGISTICS</text>
        <!-- Produce Pricing Grid -->
        <rect x="20" y="45" width="520" height="340" rx="10" fill="#070c08" stroke="rgba(132, 204, 22, 0.4)"/>
        <!-- Table Header -->
        <rect x="35" y="65" width="490" height="35" rx="6" fill="#0f1d12"/>
        <text x="50" y="88" fill="#84cc16" font-family="sans-serif" font-size="12" font-weight="bold">المحصول الزراعي</text>
        <text x="200" y="88" fill="#94a3b8" font-family="sans-serif" font-size="12">المنطقة</text>
        <text x="320" y="88" fill="#94a3b8" font-family="sans-serif" font-size="12">الكمية</text>
        <text x="440" y="88" fill="#f97316" font-family="sans-serif" font-size="12">سعر الكيلو</text>
        <!-- Rows -->
        <text x="50" y="130" fill="#ffffff" font-family="sans-serif" font-size="12">بُن خولاني أصيل (درجة 1)</text>
        <text x="200" y="130" fill="#cbd5e1" font-family="sans-serif" font-size="12">صعدة / خولان</text>
        <text x="320" y="130" fill="#cbd5e1" font-family="monospace" font-size="12">4,200 كجم</text>
        <text x="440" y="130" fill="#84cc16" font-family="monospace" font-size="12" font-weight="bold">14,500 YER</text>

        <text x="50" y="175" fill="#ffffff" font-family="sans-serif" font-size="12">عسل سدر دوعني ملكي</text>
        <text x="200" y="175" fill="#cbd5e1" font-family="sans-serif" font-size="12">حضرموت / وادي دوعن</text>
        <text x="320" y="175" fill="#cbd5e1" font-family="monospace" font-size="12">1,850 لتر</text>
        <text x="440" y="175" fill="#84cc16" font-family="monospace" font-size="12" font-weight="bold">38,000 YER</text>

        <text x="50" y="220" fill="#ffffff" font-family="sans-serif" font-size="12">رمان صعدي حلو ممتاز</text>
        <text x="200" y="220" fill="#cbd5e1" font-family="sans-serif" font-size="12">صعدة</text>
        <text x="320" y="220" fill="#cbd5e1" font-family="monospace" font-size="12">18.5 طن</text>
        <text x="440" y="220" fill="#84cc16" font-family="monospace" font-size="12" font-weight="bold">2,200 YER</text>
      </g>`
  },
  {
    id: 'waynak_dsa',
    titleEn: 'Waynak // Advanced Java DSA Graph Visualizer',
    titleAr: 'وينك — محرك الملاحة وهياكل البيانات بجافا',
    tag: 'JAVA DSA ENGINE',
    primaryColor: '#f97316',
    secondaryColor: '#a855f7',
    stats: [
      { label: 'GRAPH NODES', val: '12,500 Vertices', color: '#f97316' },
      { label: 'ALGORITHM', val: "Dijkstra's Shortest Path", color: '#a855f7' },
      { label: 'TIME COMPLEXITY', val: 'O((V + E) log V)', color: '#38bdf8' },
      { label: 'PATH LATENCY', val: '0.84 ms', color: '#22c55e' }
    ],
    centerGraphic: `
      <g transform="translate(300, 220)">
        <text x="20" y="30" fill="#a855f7" font-family="monospace" font-size="14" font-weight="bold">◈ WEIGHTED ADJACENCY MATRIX &amp; MIN-HEAP PRIORITY QUEUE</text>
        <!-- Graph visualizer -->
        <rect x="20" y="45" width="540" height="340" rx="10" fill="#0a0714" stroke="rgba(168, 85, 247, 0.4)"/>
        <!-- Nodes -->
        <circle cx="80" cy="200" r="22" fill="#a855f7" filter="drop-shadow(0 0 8px #a855f7)"/>
        <text x="80" y="206" fill="#ffffff" font-family="monospace" font-size="14" font-weight="bold" text-anchor="middle">A</text>
        
        <circle cx="220" cy="110" r="20" fill="#1e1533" stroke="#a855f7" stroke-width="2"/>
        <text x="220" y="116" fill="#ffffff" font-family="monospace" font-size="14" font-weight="bold" text-anchor="middle">B</text>

        <circle cx="240" cy="290" r="20" fill="#1e1533" stroke="#f97316" stroke-width="2"/>
        <text x="240" y="296" fill="#ffffff" font-family="monospace" font-size="14" font-weight="bold" text-anchor="middle">C</text>

        <circle cx="390" cy="150" r="20" fill="#1e1533" stroke="#f97316" stroke-width="2"/>
        <text x="390" y="156" fill="#ffffff" font-family="monospace" font-size="14" font-weight="bold" text-anchor="middle">D</text>

        <circle cx="500" cy="240" r="24" fill="#22c55e" filter="drop-shadow(0 0 10px #22c55e)"/>
        <text x="500" y="246" fill="#000000" font-family="monospace" font-size="14" font-weight="bold" text-anchor="middle">E</text>

        <!-- Edges -->
        <line x1="102" y1="200" x2="218" y2="290" stroke="#f97316" stroke-width="4"/>
        <line x1="260" y1="290" x2="370" y2="155" stroke="#f97316" stroke-width="4"/>
        <line x1="410" y1="155" x2="480" y2="230" stroke="#f97316" stroke-width="4"/>
        <text x="145" y="260" fill="#f97316" font-family="monospace" font-size="12" font-weight="bold">w: 2</text>
        <text x="320" y="235" fill="#f97316" font-family="monospace" font-size="12" font-weight="bold">w: 3</text>
        <text x="450" y="185" fill="#f97316" font-family="monospace" font-size="12" font-weight="bold">w: 1</text>
      </g>
      <!-- Heap & Code snippet side panel -->
      <g transform="translate(870, 265)">
        <rect width="260" height="340" rx="10" fill="#090c14" stroke="rgba(255, 255, 255, 0.08)"/>
        <text x="15" y="30" fill="#ffffff" font-family="monospace" font-size="12" font-weight="bold">MinHeap Queue</text>
        <rect x="15" y="45" width="230" height="40" rx="6" fill="#1e1533"/>
        <text x="25" y="70" fill="#a855f7" font-family="monospace" font-size="11">[A:0, C:2, B:4, D:5, E:6]</text>
        <text x="15" y="115" fill="#94a3b8" font-family="monospace" font-size="11">// Java Thread Pool:</text>
        <text x="15" y="135" fill="#22c55e" font-family="monospace" font-size="10">ForkJoinPool.commonPool()</text>
      </g>`
  },
  {
    id: 'alshamel_erp',
    titleEn: 'Al-Shamel ERP // Enterprise C# .NET Suite',
    titleAr: 'الشامل ERP — منظومة إدارة الموارد بـ C# .NET',
    tag: 'C# .NET 8 WPF',
    primaryColor: '#0284c7',
    secondaryColor: '#f97316',
    stats: [
      { label: 'GENERAL LEDGER BALANCE', val: '$8,450,210', color: '#0284c7' },
      { label: 'JOURNAL VOUCHERS', val: '48,190 Entries', color: '#f97316' },
      { label: 'FISCAL YEAR', val: '2026 Audit Ready', color: '#22c55e' },
      { label: 'SQL SERVER INSTANCE', val: 'Connected (1433)', color: '#38bdf8' }
    ],
    centerGraphic: `
      <g transform="translate(300, 220)">
        <text x="20" y="30" fill="#0284c7" font-family="monospace" font-size="14" font-weight="bold">◈ C# WPF ENTERPRISE FINANCIAL LEDGER &amp; COST CENTERS</text>
        <!-- Windows WPF DataGrid simulation -->
        <rect x="20" y="45" width="830" height="340" rx="8" fill="#080e18" stroke="rgba(2, 132, 199, 0.4)"/>
        <!-- Grid Header -->
        <rect x="20" y="45" width="830" height="35" rx="8" fill="#0f1d30"/>
        <text x="40" y="68" fill="#0284c7" font-family="monospace" font-size="12" font-weight="bold">VOUCHER #</text>
        <text x="150" y="68" fill="#ffffff" font-family="monospace" font-size="12" font-weight="bold">ACC CODE</text>
        <text x="280" y="68" fill="#ffffff" font-family="sans-serif" font-size="12" font-weight="bold">اسم الحساب المحاسبي</text>
        <text x="540" y="68" fill="#ffffff" font-family="monospace" font-size="12" font-weight="bold">DEBIT (مدين)</text>
        <text x="700" y="68" fill="#ffffff" font-family="monospace" font-size="12" font-weight="bold">CREDIT (دائن)</text>
        <!-- Grid Rows -->
        <rect x="20" y="85" width="830" height="35" fill="rgba(255,255,255,0.02)"/>
        <text x="40" y="108" fill="#94a3b8" font-family="monospace" font-size="12">JV-2026-0841</text>
        <text x="150" y="108" fill="#38bdf8" font-family="monospace" font-size="12">10101-01</text>
        <text x="280" y="108" fill="#ffffff" font-family="sans-serif" font-size="12">حساب الصندوق الرئيسي - الفرع العام</text>
        <text x="540" y="108" fill="#22c55e" font-family="monospace" font-size="12">14,250,000</text>
        <text x="700" y="108" fill="#64748b" font-family="monospace" font-size="12">0.00</text>

        <rect x="20" y="125" width="830" height="35" fill="transparent"/>
        <text x="40" y="148" fill="#94a3b8" font-family="monospace" font-size="12">JV-2026-0842</text>
        <text x="150" y="148" fill="#38bdf8" font-family="monospace" font-size="12">40102-04</text>
        <text x="280" y="148" fill="#ffffff" font-family="sans-serif" font-size="12">إيرادات المبيعات والخدمات البرمجية</text>
        <text x="540" y="148" fill="#64748b" font-family="monospace" font-size="12">0.00</text>
        <text x="700" y="148" fill="#f97316" font-family="monospace" font-size="12">14,250,000</text>

        <rect x="20" y="165" width="830" height="35" fill="rgba(255,255,255,0.02)"/>
        <text x="40" y="188" fill="#94a3b8" font-family="monospace" font-size="12">JV-2026-0843</text>
        <text x="150" y="188" fill="#38bdf8" font-family="monospace" font-size="12">20101-02</text>
        <text x="280" y="188" fill="#ffffff" font-family="sans-serif" font-size="12">موردين التجهيزات والشبكات السحابية</text>
        <text x="540" y="188" fill="#22c55e" font-family="monospace" font-size="12">3,120,000</text>
        <text x="700" y="188" fill="#64748b" font-family="monospace" font-size="12">0.00</text>
      </g>`
  },
  {
    id: 'smart_pharmacy',
    titleEn: 'Smart Pharmacy // POS & Drug Expiry System',
    titleAr: 'الصيدلي الذكي — نظام نقاط البيع وإدارة الصيدليات',
    tag: 'PHARMACY POS',
    primaryColor: '#14b8a6',
    secondaryColor: '#f97316',
    stats: [
      { label: 'DRUG INVENTORY', val: '14,800 SKU', color: '#14b8a6' },
      { label: 'EXPIRY ALERTS', val: '6 Batches', color: '#ef4444' },
      { label: 'BARCODE SCANS', val: 'Sub-30ms', color: '#38bdf8' },
      { label: 'TODAY SALES', val: '$4,120 USD', color: '#22c55e' }
    ],
    centerGraphic: `
      <g transform="translate(300, 220)">
        <text x="20" y="30" fill="#14b8a6" font-family="monospace" font-size="14" font-weight="bold">◈ BARCODE DRUG DISPENSARY &amp; CONTRAINDICATION ENGINE</text>
        <rect x="20" y="45" width="830" height="340" rx="8" fill="#070e0d" stroke="rgba(20, 184, 166, 0.4)"/>
        <!-- Scanner Bar -->
        <rect x="40" y="65" width="480" height="40" rx="8" fill="#0d1b19" stroke="#14b8a6"/>
        <text x="60" y="90" fill="#14b8a6" font-family="monospace" font-size="13">SCAN: 629110023410 // AUGMENTIN 1G TAB</text>
        
        <!-- Shelf Matrix -->
        <g transform="translate(40, 125)">
          <rect width="480" height="230" rx="8" fill="#0a1513"/>
          <text x="20" y="30" fill="#ffffff" font-family="sans-serif" font-size="13" font-weight="bold">سجل الأدوية المصروفة بالباركود</text>
          <text x="20" y="65" fill="#14b8a6" font-family="monospace" font-size="12">01. Amoxicillin 500mg | Batch #B84 | Shelf A-04 | 24 Pcs</text>
          <text x="20" y="95" fill="#f8fafc" font-family="monospace" font-size="12">02. Panadol Extra 24s | Batch #P12 | Shelf B-02 | 100 Pcs</text>
          <text x="20" y="125" fill="#f8fafc" font-family="monospace" font-size="12">03. Lantus Insulin 100IU | Batch #L09 | Fridge 1 | 15 Pens</text>
          <rect x="20" y="155" width="440" height="45" rx="6" fill="#132a24"/>
          <text x="35" y="182" fill="#22c55e" font-family="monospace" font-size="14" font-weight="bold">TOTAL DUE: $64.50 (RECEIPT #8429 READY)</text>
        </g>
      </g>`
  },
  {
    id: 'nabdh_hms',
    titleEn: 'Nabdh HMS // Hospital Information & Clinical Suite',
    titleAr: 'نبض HMS — النظام الطبي للمستشفيات والمراكز التخصصية',
    tag: 'HEALTHCARE ERP',
    primaryColor: '#ef4444',
    secondaryColor: '#38bdf8',
    stats: [
      { label: 'OCCUPIED BEDS', val: '184 / 200 Beds', color: '#ef4444' },
      { label: 'ICU MONITORS', val: '24 Active', color: '#22c55e' },
      { label: 'DOCTORS ON DUTY', val: '32 Specialists', color: '#38bdf8' },
      { label: 'ER TRIAGE TIME', val: '2.5 Minutes', color: '#fbbf24' }
    ],
    centerGraphic: `
      <g transform="translate(300, 220)">
        <text x="20" y="30" fill="#ef4444" font-family="monospace" font-size="14" font-weight="bold">◈ ICU TELEMETRY ECG MONITOR &amp; EMERGENCY WARD DISPATCH</text>
        <rect x="20" y="45" width="830" height="340" rx="8" fill="#0c0708" stroke="rgba(239, 68, 68, 0.4)"/>
        <!-- ECG Waveform -->
        <rect x="40" y="65" width="500" height="150" rx="8" fill="#13090b" stroke="#ef4444"/>
        <path d="M 40 140 L 120 140 L 130 110 L 140 170 L 150 90 L 160 150 L 170 140 L 260 140 L 270 110 L 280 170 L 290 90 L 300 150 L 310 140 L 400 140 L 410 110 L 420 170 L 430 90 L 440 150 L 450 140 L 540 140" fill="none" stroke="#22c55e" stroke-width="3"/>
        <text x="60" y="95" fill="#22c55e" font-family="monospace" font-size="18" font-weight="bold">PULSE: 78 BPM</text>
        <text x="240" y="95" fill="#38bdf8" font-family="monospace" font-size="18" font-weight="bold">SpO2: 99%</text>
        <text x="400" y="95" fill="#fbbf24" font-family="monospace" font-size="18" font-weight="bold">BP: 120/80</text>
      </g>`
  }
];

// Generate generic rich templates for the remaining projects up to 40
const remainingProjectsMeta = [
  { id: 'madrasati_plus', en: 'Madrasati Plus // K-12 School Management', ar: 'مدرستي بلس — المنظومة المدرسية الذكية', tag: 'LMS EDUTECH', color: '#3b82f6' },
  { id: 'academia_lms', en: 'Academia LMS // University Academic Portal', ar: 'أكاديميا — منصة الجامعات والتعليم العالي', tag: 'UNIVERSITY ERP', color: '#6366f1' },
  { id: 'sadeed_invoicing', en: 'Sadeed // Tax Invoicing & Zakat Gateway', ar: 'سديد — الفوترة الإلكترونية والامتثال الضريبي', tag: 'E-INVOICE', color: '#10b981' },
  { id: 'masari_logistics', en: 'Masari // Multi-Modal Freight Logistics', ar: 'مساري — الشحن الدولي والتخليص الجمركي', tag: 'FREIGHT CARGO', color: '#f59e0b' },
  { id: 'aman_microfinance', en: 'Aman // Microfinance & SME Lending Suite', ar: 'أمان — منظومة التمويل الأصغر والقروض', tag: 'FINTECH', color: '#06b6d4' },
  { id: 'smart_warehouse', en: 'Smart Warehouse // WMS & Bin-Locator', ar: 'المستودع الذكي — نظام إدارة المخازن WMS', tag: 'WMS LOGISTICS', color: '#8b5cf6' },
  { id: 'autocare_pro', en: 'AutoCare Pro // Automotive Workshop ERP', ar: 'أوتوكير برو — صيانة السيارات ومراكز الفحص', tag: 'AUTOMOTIVE', color: '#f97316' },
  { id: 'fondokey_pms', en: 'Fondokey // Hotel Property Management', ar: 'فندقي — نظام حجوزات وإدارة الفنادق', tag: 'HOSPITALITY', color: '#ec4899' },
  { id: 'emdad_b2b', en: 'Emdad // B2B Wholesale Marketplace', ar: 'إمداد — منصة التوريدات والمشتريات B2B', tag: 'B2B COMMERCE', color: '#14b8a6' },
  { id: 'sanad_realestate', en: 'Sanad // Real Estate Asset Management', ar: 'سند — إدارة العقارات والأملاك والوساطة', tag: 'PROP-TECH', color: '#eab308' },
  { id: 'reaya_telehealth', en: 'Reaya // Encrypted Telehealth Consultations', ar: 'رعاية — الاستشارات الطبية عن بعد', tag: 'TELEMEDICINE', color: '#0284c7' },
  { id: 'sarraf_exchange', en: 'Sarraf // Remittance & Foreign Exchange', ar: 'الصراف — التحويلات المالية والصرافة', tag: 'FOREX HAWALA', color: '#16a34a' },
  { id: 'maahad_tech', en: 'Maahad // Technical Training Institute ERP', ar: 'معهد تك — إدارة المعاهد والتدريب المهني', tag: 'TRAINING ERP', color: '#9333ea' },
  { id: 'fastcart_mall', en: 'FastCart // Multi-Vendor E-Commerce Hub', ar: 'فاست كارت — منصة المتاجر المتعددة', tag: 'E-COMMERCE', color: '#ea580c' },
  { id: 'homam_legal', en: 'Homam // Legal Case & Law Firm Portal', ar: 'هُمام — إدارة مكاتب المحاماة والقضايا', tag: 'LEGAL TECH', color: '#475569' },
  { id: 'sharyan_bloodbank', en: 'Sharyan // Emergency Blood Bank Network', ar: 'شريان — بنك الدم والتبرع الطارئ', tag: 'HEALTH NETWORK', color: '#dc2626' },
  { id: 'matbakhi_kds', en: 'Matbakhi // Cloud Kitchen Display System', ar: 'مطبخي KDS — إدارة شاشات المطاعم والمطابخ', tag: 'RESTAURANT KDS', color: '#ca8a04' },
  { id: 'rowad_incubator', en: 'Rowad // Startup Pitch & Venture Engine', ar: 'رواد — حاضنة الأعمال والاستثمار الجريء', tag: 'VENTURE HUB', color: '#2563eb' },
  { id: 'solartrack_iot', en: 'SolarTrack // Photovoltaic IoT Telematics', ar: 'سولار تراك — مراقبة الطاقة الشمسية بالـ IoT', tag: 'IOT SOLAR', color: '#eab308' },
  { id: 'albayan_hr', en: 'Al-Bayan // Enterprise HR & Biometric Payroll', ar: 'البيان HR — الموارد البشرية والرواتب والدوام', tag: 'HRM PAYROLL', color: '#0d9488' },
  { id: 'watheeq_archive', en: 'Watheeq // OCR Government Document Vault', ar: 'وثيق — الأرشفة الإلكترونية والتوثيق الرقمي', tag: 'OCR ARCHIVE', color: '#7c3aed' },
  { id: 'itqan_exams', en: 'Itqan // Computer Based Testing & Proctor', ar: 'إتقان — الاختبارات المحوسبة وبنوك الأسئلة', tag: 'CBT TESTING', color: '#059669' },
  { id: 'wesal_crm', en: 'Wesal // Omnichannel Support Desk', ar: 'وصال CRM — خدمة العملاء وتذاكر الدعم', tag: 'OMNICHANNEL', color: '#2563eb' },
  { id: 'smart_pos_retail', en: 'CashierPro // C# .NET High Speed POS', ar: 'كاشير برو — نقاط البيع والمخازن بـ .NET C#', tag: 'C# .NET WPF', color: '#0284c7' },
  { id: 'tameen_insurance', en: 'TameenTech // Java Insurance Claims Engine', ar: 'تأمين تك — محرك مطالبات التأمين بـ Java', tag: 'JAVA SPRING', color: '#b91c1c' },
  { id: 'fleet_tracking', en: 'Ostool // GPS Satellite Fleet Telematics', ar: 'أسطول GPS — تتبع وإدارة أساطيل الشاحنات', tag: 'GPS ANDROID', color: '#f97316' },
  { id: 'albaraka_accounting', en: 'Al-Baraka // General Ledger Financials', ar: 'البركة المحاسبي — الحسابات والميزانيات', tag: 'C# ACCOUNTING', color: '#0f766e' },
  { id: 'smart_dentist', en: 'DentalPro // 3D Interactive Odontogram', ar: 'عيادتي برو — مراكز الأسنان ومخطط الأسنان', tag: 'DENTAL CLINIC', color: '#06b6d4' },
  { id: 'jawda_qms', en: 'Jawda // Enterprise Quality ISO Compliance', ar: 'جودة QMS — إدارة الجودة ومعايير ISO', tag: 'ISO COMPLIANCE', color: '#4338ca' },
  { id: 'omran_contracting', en: 'Omran // Construction ERP & Civil BOQ', ar: 'عِمران — شركات المقاولات والمشاريع الإنشائية', tag: 'CIVIL ERP', color: '#c2410c' },
  { id: 'safir_travel', en: 'Safir Travel // Flight & Umrah Package ERP', ar: 'سفير ترافل — حجوزات الطيران وبرامج العمرة', tag: 'TRAVEL GDS', color: '#0369a1' }
];

// Write out all 40 SVGs
for (const p of projects) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 675" width="100%" height="100%">
    <defs>
      <linearGradient id="bg_${p.id}" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#04060a"/>
        <stop offset="60%" stop-color="#090d16"/>
        <stop offset="100%" stop-color="#020305"/>
      </linearGradient>
      <linearGradient id="pnl_${p.id}" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#0f1523"/>
        <stop offset="100%" stop-color="#080c14"/>
      </linearGradient>
    </defs>
    <rect width="1200" height="675" fill="url(#bg_${p.id})"/>
    <rect x="24" y="24" width="1152" height="627" rx="16" fill="#080c14" stroke="${p.primaryColor}" stroke-width="1.5" stroke-opacity="0.4"/>
    <rect x="24" y="24" width="1152" height="52" rx="16" fill="#0e1320"/>
    <rect x="24" y="60" width="1152" height="16" fill="#0e1320"/>
    <circle cx="54" cy="50" r="6" fill="#ef4444"/>
    <circle cx="74" cy="50" r="6" fill="#eab308"/>
    <circle cx="94" cy="50" r="6" fill="#22c55e"/>
    <text x="120" y="55" fill="#f8fafc" font-family="'Courier New', monospace" font-size="14" font-weight="bold">${p.titleEn}</text>
    <text x="650" y="55" fill="#94a3b8" font-family="'Tajawal', sans-serif" font-size="14" text-anchor="middle">${p.titleAr}</text>
    <rect x="1040" y="38" width="115" height="24" rx="12" fill="rgba(249,115,22,0.15)" stroke="${p.primaryColor}" stroke-width="1"/>
    <text x="1097" y="54" fill="${p.primaryColor}" font-family="monospace" font-size="11" font-weight="bold" text-anchor="middle">${p.tag}</text>
    
    <!-- Top Stat Cards -->
    <g transform="translate(48, 96)">
      ${p.stats.map((s, idx) => `
        <g transform="translate(${idx * 276}, 0)">
          <rect width="255" height="90" rx="10" fill="url(#pnl_${p.id})" stroke="rgba(255,255,255,0.08)"/>
          <text x="18" y="30" fill="#94a3b8" font-family="sans-serif" font-size="11">${s.label}</text>
          <text x="18" y="62" fill="${s.color || '#ffffff'}" font-family="monospace" font-size="20" font-weight="bold">${s.val}</text>
        </g>
      `).join('')}
    </g>

    ${p.centerGraphic}

    <text x="1140" y="625" fill="rgba(255,255,255,0.2)" font-family="monospace" font-size="10" text-anchor="end">ENG. ABDULLAH SHAIF // VERIFIED DEPLOYMENT</text>
  </svg>`;

  fs.writeFileSync(path.join(outDir, `${p.id}.svg`), svg, 'utf8');
}

// Generate the remaining project SVGs with distinct color schemes and domain-specific UI mockups
for (const item of remainingProjectsMeta) {
  const filePath = path.join(outDir, `${item.id}.svg`);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 675" width="100%" height="100%">
    <defs>
      <linearGradient id="bg_${item.id}" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#05070c"/>
        <stop offset="50%" stop-color="#0a0f1a"/>
        <stop offset="100%" stop-color="#030407"/>
      </linearGradient>
      <linearGradient id="pnl_${item.id}" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#0e1422"/>
        <stop offset="100%" stop-color="#090d16"/>
      </linearGradient>
      <pattern id="grid_${item.id}" width="32" height="32" patternUnits="userSpaceOnUse">
        <path d="M 32 0 L 0 0 0 32" fill="none" stroke="rgba(255,255,255,0.03)" stroke-width="1"/>
      </pattern>
    </defs>
    <rect width="1200" height="675" fill="url(#bg_${item.id})"/>
    <rect width="1200" height="675" fill="url(#grid_${item.id})"/>
    
    <!-- Outer Window Frame -->
    <rect x="24" y="24" width="1152" height="627" rx="16" fill="#080c14" stroke="${item.color}" stroke-width="1.5" stroke-opacity="0.5"/>
    <rect x="24" y="24" width="1152" height="52" rx="16" fill="#0c111c"/>
    <rect x="24" y="60" width="1152" height="16" fill="#0c111c"/>
    <circle cx="54" cy="50" r="6" fill="#ef4444"/>
    <circle cx="74" cy="50" r="6" fill="#eab308"/>
    <circle cx="94" cy="50" r="6" fill="#22c55e"/>
    <text x="120" y="55" fill="#f8fafc" font-family="'Courier New', monospace" font-size="14" font-weight="bold">${item.en}</text>
    <text x="650" y="55" fill="#94a3b8" font-family="'Tajawal', sans-serif" font-size="14" text-anchor="middle">${item.ar}</text>
    <rect x="1030" y="38" width="125" height="24" rx="12" fill="rgba(255,255,255,0.06)" stroke="${item.color}" stroke-width="1"/>
    <text x="1092" y="54" fill="${item.color}" font-family="monospace" font-size="11" font-weight="bold" text-anchor="middle">${item.tag}</text>

    <!-- Sidebar -->
    <rect x="44" y="96" width="220" height="535" rx="12" fill="url(#pnl_${item.id})" stroke="rgba(255,255,255,0.05)"/>
    <text x="64" y="130" fill="${item.color}" font-family="monospace" font-size="12" font-weight="bold">// MODULES</text>
    <rect x="56" y="148" width="196" height="36" rx="8" fill="rgba(255,255,255,0.06)" stroke="${item.color}" stroke-width="1"/>
    <text x="74" y="171" fill="#ffffff" font-family="sans-serif" font-size="12" font-weight="bold">◈ Active Dashboard</text>
    <text x="74" y="215" fill="#94a3b8" font-family="sans-serif" font-size="12">◈ Operational Logs</text>
    <text x="74" y="255" fill="#94a3b8" font-family="sans-serif" font-size="12">◈ Report Generator</text>
    <text x="74" y="295" fill="#94a3b8" font-family="sans-serif" font-size="12">◈ REST API Endpoints</text>

    <!-- Top KPI Cards -->
    <g transform="translate(284, 96)">
      <g transform="translate(0, 0)">
        <rect width="265" height="90" rx="10" fill="url(#pnl_${item.id})" stroke="rgba(255,255,255,0.08)"/>
        <text x="18" y="30" fill="#94a3b8" font-family="sans-serif" font-size="11">TOTAL RECORDS</text>
        <text x="18" y="62" fill="#ffffff" font-family="monospace" font-size="20" font-weight="bold">128,450 Rows</text>
        <text x="18" y="78" fill="${item.color}" font-family="monospace" font-size="10">+24% Monthly</text>
      </g>
      <g transform="translate(290, 0)">
        <rect width="265" height="90" rx="10" fill="url(#pnl_${item.id})" stroke="rgba(255,255,255,0.08)"/>
        <text x="18" y="30" fill="#94a3b8" font-family="sans-serif" font-size="11">SYSTEM INTEGRITY</text>
        <text x="18" y="62" fill="#22c55e" font-family="monospace" font-size="20" font-weight="bold">99.98% SLA</text>
        <text x="18" y="78" fill="#22c55e" font-family="monospace" font-size="10">Zero Critical Faults</text>
      </g>
      <g transform="translate(580, 0)">
        <rect width="265" height="90" rx="10" fill="url(#pnl_${item.id})" stroke="rgba(255,255,255,0.08)"/>
        <text x="18" y="30" fill="#94a3b8" font-family="sans-serif" font-size="11">ACTIVE USERS</text>
        <text x="18" y="62" fill="${item.color}" font-family="monospace" font-size="20" font-weight="bold">3,820 Concur.</text>
        <text x="18" y="78" fill="#38bdf8" font-family="monospace" font-size="10">Encrypted JWT Sessions</text>
      </g>
    </g>

    <!-- Central Stage -->
    <rect x="284" y="206" width="872" height="425" rx="12" fill="url(#pnl_${item.id})" stroke="rgba(255,255,255,0.06)"/>
    <text x="310" y="240" fill="${item.color}" font-family="monospace" font-size="14" font-weight="bold">◈ ${item.en.toUpperCase()}</text>
    
    <!-- Vector Wave/Chart -->
    <path d="M 310 480 Q 420 380 520 420 T 720 320 T 920 360 T 1100 280" fill="none" stroke="${item.color}" stroke-width="3" filter="drop-shadow(0 0 8px ${item.color})"/>
    <path d="M 310 480 Q 420 380 520 420 T 720 320 T 920 360 T 1100 280 L 1100 580 L 310 580 Z" fill="${item.color}" fill-opacity="0.08"/>

    <!-- Data Bars -->
    <rect x="340" y="520" width="28" height="60" rx="4" fill="${item.color}" fill-opacity="0.8"/>
    <rect x="420" y="470" width="28" height="110" rx="4" fill="${item.color}" fill-opacity="0.8"/>
    <rect x="500" y="420" width="28" height="160" rx="4" fill="${item.color}" fill-opacity="0.8"/>
    <rect x="580" y="450" width="28" height="130" rx="4" fill="${item.color}" fill-opacity="0.8"/>
    <rect x="660" y="380" width="28" height="200" rx="4" fill="${item.color}" fill-opacity="0.8"/>
    <rect x="740" y="350" width="28" height="230" rx="4" fill="${item.color}" fill-opacity="0.8"/>
    <rect x="820" y="390" width="28" height="190" rx="4" fill="${item.color}" fill-opacity="0.8"/>
    <rect x="900" y="330" width="28" height="250" rx="4" fill="${item.color}" fill-opacity="0.8"/>
    <rect x="980" y="300" width="28" height="280" rx="4" fill="${item.color}" fill-opacity="0.8"/>
    <rect x="1060" y="270" width="28" height="310" rx="4" fill="${item.color}" fill-opacity="0.8"/>

    <text x="1140" y="620" fill="rgba(255,255,255,0.2)" font-family="monospace" font-size="10" text-anchor="end">ENGINEER ABDULLAH ABDO SHAIF // ${item.tag}</text>
  </svg>`;

  fs.writeFileSync(filePath, svg, 'utf8');
}

console.log('All 40 unique project SVGs generated successfully in public/assets/projects/');
