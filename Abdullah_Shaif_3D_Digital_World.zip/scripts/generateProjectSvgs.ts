import fs from 'fs';
import path from 'path';

const outputDir = path.resolve(process.cwd(), 'public/assets/projects');
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

// Helper to generate SVG mockups
function generateSvgMockup(config) {
  const {
    id,
    titleEn,
    titleAr,
    tag,
    primaryColor = '#f97316',
    secondaryColor = '#84cc16',
    darkBg = '#07090e',
    panelBg = '#0d111a',
    borderColor = 'rgba(249, 115, 22, 0.35)',
    type = 'dashboard', // 'erp', 'map', 'graph', 'chart', 'kiosk', 'code', 'mobile'
    stats = [],
    codeOrTable = ''
  } = config;

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 675" width="100%" height="100%">
  <defs>
    <linearGradient id="bgGrad_${id}" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#050608"/>
      <stop offset="60%" stop-color="${darkBg}"/>
      <stop offset="100%" stop-color="#020305"/>
    </linearGradient>
    <linearGradient id="panelGrad_${id}" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="${panelBg}"/>
      <stop offset="100%" stop-color="#080a10"/>
    </linearGradient>
    <linearGradient id="accentGrad_${id}" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="${primaryColor}"/>
      <stop offset="100%" stop-color="${secondaryColor}"/>
    </linearGradient>
    <filter id="glow_${id}" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="6" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>
    <pattern id="grid_${id}" width="40" height="40" patternUnits="userSpaceOnUse">
      <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255, 255, 255, 0.03)" stroke-width="1"/>
    </pattern>
  </defs>

  <!-- Background -->
  <rect width="1200" height="675" fill="url(#bgGrad_${id})"/>
  <rect width="1200" height="675" fill="url(#grid_${id})"/>

  <!-- Outer Window Frame -->
  <rect x="24" y="24" width="1152" height="627" rx="16" fill="#080a10" stroke="${borderColor}" stroke-width="1.5" />

  <!-- Window Header Bar -->
  <rect x="24" y="24" width="1152" height="52" rx="16" fill="#0c1018" />
  <rect x="24" y="60" width="1152" height="16" fill="#0c1018" />
  <line x1="24" y1="76" x2="1176" y2="76" stroke="rgba(255, 255, 255, 0.08)" stroke-width="1" />

  <!-- Window Controls -->
  <circle cx="54" cy="50" r="6" fill="#ef4444" />
  <circle cx="74" cy="50" r="6" fill="#eab308" />
  <circle cx="94" cy="50" r="6" fill="#22c55e" />

  <!-- Window Title -->
  <text x="120" y="55" fill="#f8fafc" font-family="'Courier New', monospace, sans-serif" font-size="14" font-weight="bold">${titleEn}</text>
  <text x="600" y="55" fill="#94a3b8" font-family="'Tajawal', sans-serif" font-size="14" text-anchor="middle">${titleAr}</text>

  <!-- Status Badge -->
  <rect x="1050" y="38" width="102" height="24" rx="12" fill="rgba(249, 115, 22, 0.15)" stroke="${primaryColor}" stroke-width="1"/>
  <circle cx="1064" cy="50" r="3.5" fill="${primaryColor}"/>
  <text x="1076" y="54" fill="${primaryColor}" font-family="monospace" font-size="11" font-weight="bold">${tag}</text>

  <!-- Left Sidebar Navigation -->
  <rect x="44" y="96" width="220" height="535" rx="12" fill="url(#panelGrad_${id})" stroke="rgba(255, 255, 255, 0.05)" />
  <text x="64" y="130" fill="${primaryColor}" font-family="monospace" font-size="12" font-weight="bold">// NAVIGATION</text>

  <!-- Sidebar items -->
  <rect x="56" y="148" width="196" height="36" rx="8" fill="rgba(249, 115, 22, 0.18)" stroke="${primaryColor}" stroke-width="1" />
  <text x="74" y="171" fill="#ffffff" font-family="sans-serif" font-size="12" font-weight="bold">◈ Live Console</text>
  
  <rect x="56" y="194" width="196" height="32" rx="8" fill="transparent" />
  <text x="74" y="215" fill="#94a3b8" font-family="sans-serif" font-size="12">◈ Data Records</text>
  
  <rect x="56" y="234" width="196" height="32" rx="8" fill="transparent" />
  <text x="74" y="255" fill="#94a3b8" font-family="sans-serif" font-size="12">◈ Analytics Hub</text>

  <rect x="56" y="274" width="196" height="32" rx="8" fill="transparent" />
  <text x="74" y="295" fill="#94a3b8" font-family="sans-serif" font-size="12">◈ System Ledger</text>

  <rect x="56" y="314" width="196" height="32" rx="8" fill="transparent" />
  <text x="74" y="335" fill="#94a3b8" font-family="sans-serif" font-size="12">◈ Settings &amp; API</text>

  <!-- Mini System Telemetry in Sidebar -->
  <rect x="56" y="490" width="196" height="120" rx="8" fill="#05070a" stroke="rgba(255, 255, 255, 0.06)"/>
  <text x="68" y="515" fill="#64748b" font-family="monospace" font-size="10">CPU LOAD: 18%</text>
  <rect x="68" y="525" width="172" height="6" rx="3" fill="#1e293b"/>
  <rect x="68" y="525" width="31" height="6" rx="3" fill="${primaryColor}"/>
  
  <text x="68" y="555" fill="#64748b" font-family="monospace" font-size="10">MEMORY: 2.1 / 16 GB</text>
  <rect x="68" y="565" width="172" height="6" rx="3" fill="#1e293b"/>
  <rect x="68" y="565" width="22" height="6" rx="3" fill="${secondaryColor}"/>

  <text x="68" y="595" fill="#22c55e" font-family="monospace" font-size="10">● CLOUD DB CONNECTED</text>

  <!-- Main Content Area -->
  <!-- Top Stat Cards -->
  <g transform="translate(284, 96)">
    ${stats.map((s, idx) => `
      <g transform="translate(${idx * 224}, 0)">
        <rect width="210" height="90" rx="10" fill="url(#panelGrad_${id})" stroke="rgba(255, 255, 255, 0.08)"/>
        <text x="18" y="30" fill="#94a3b8" font-family="sans-serif" font-size="11">${s.label}</text>
        <text x="18" y="62" fill="${s.color || '#ffffff'}" font-family="monospace" font-size="20" font-weight="bold">${s.val}</text>
        <text x="18" y="78" fill="${secondaryColor}" font-family="monospace" font-size="10">${s.sub || '+12.5% vs avg'}</text>
      </g>
    `).join('')}
  </g>

  <!-- Main Visual Canvas / Central Stage -->
  <rect x="284" y="206" width="872" height="425" rx="12" fill="url(#panelGrad_${id})" stroke="rgba(255, 255, 255, 0.06)" />

  ${codeOrTable}

  <!-- Footer Watermark -->
  <text x="1140" y="618" fill="rgba(255, 255, 255, 0.15)" font-family="monospace" font-size="10" text-anchor="end">ENG. ABDULLAH SHAIF // ARCHITECTURE VERIFIED</text>
</svg>`;
}

export { generateSvgMockup, outputDir };
