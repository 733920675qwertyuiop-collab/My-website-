import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { initialProfile, initialProjects, initialSkills, initialServices } from './src/data/initialData';
import { ProfileInfo, ProjectItem, SkillItem, ServiceItem, ContactMessage } from './src/types/portfolio';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// In-memory data store with initial seeds
let currentProfile: ProfileInfo = { ...initialProfile };
let currentProjects: ProjectItem[] = [...initialProjects];
let currentSkills: SkillItem[] = [...initialSkills];
let currentServices: ServiceItem[] = [...initialServices];
let currentMessages: ContactMessage[] = [
  {
    id: 'msg_welcome_1',
    name: 'شركة يمن تيك للحلول الرقمية',
    email: 'info@yemen-tech.com',
    phone: '+967 771 234 567',
    serviceInterest: 'تصميم وتطوير المواقع والمنصات الإلكترونية',
    message: 'السلام عليكم يا بشمهندس عبدالله، نود التعاون معك في تطوير نظام نقل متكامل وموقع ويب تفاعلي. نرجو التواصل لتحديد موعد مقابلة العمل.',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    isRead: false
  }
];

// --- API Endpoints ---

// Profile
app.get('/api/profile', (_req: Request, res: Response) => {
  res.json(currentProfile);
});

app.put('/api/profile', (req: Request, res: Response) => {
  currentProfile = { ...currentProfile, ...req.body };
  res.json({ success: true, profile: currentProfile });
});

// Projects
app.get('/api/projects', (_req: Request, res: Response) => {
  res.json(currentProjects);
});

app.post('/api/projects', (req: Request, res: Response) => {
  const newProj: ProjectItem = {
    ...req.body,
    id: req.body.id || `proj_${Date.now()}`
  };
  currentProjects.unshift(newProj);
  res.status(201).json({ success: true, project: newProj });
});

app.put('/api/projects/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const idx = currentProjects.findIndex(p => p.id === id);
  if (idx !== -1) {
    currentProjects[idx] = { ...currentProjects[idx], ...req.body };
    res.json({ success: true, project: currentProjects[idx] });
  } else {
    res.status(404).json({ error: 'Project not found' });
  }
});

app.delete('/api/projects/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  currentProjects = currentProjects.filter(p => p.id !== id);
  res.json({ success: true, deletedId: id });
});

// Skills
app.get('/api/skills', (_req: Request, res: Response) => {
  res.json(currentSkills);
});

app.post('/api/skills', (req: Request, res: Response) => {
  const newSkill: SkillItem = {
    ...req.body,
    id: req.body.id || `skill_${Date.now()}`
  };
  currentSkills.push(newSkill);
  res.status(201).json({ success: true, skill: newSkill });
});

app.put('/api/skills/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const idx = currentSkills.findIndex(s => s.id === id);
  if (idx !== -1) {
    currentSkills[idx] = { ...currentSkills[idx], ...req.body };
    res.json({ success: true, skill: currentSkills[idx] });
  } else {
    res.status(404).json({ error: 'Skill not found' });
  }
});

app.delete('/api/skills/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  currentSkills = currentSkills.filter(s => s.id !== id);
  res.json({ success: true, deletedId: id });
});

// Services
app.get('/api/services', (_req: Request, res: Response) => {
  res.json(currentServices);
});

// Messages
app.get('/api/messages', (_req: Request, res: Response) => {
  res.json(currentMessages);
});

app.post('/api/messages', (req: Request, res: Response) => {
  const { name, email, phone, serviceInterest, message } = req.body;
  if (!name || !email || !message) {
    res.status(400).json({ error: 'Name, email, and message are required.' });
    return;
  }
  const newMsg: ContactMessage = {
    id: `msg_${Date.now()}`,
    name,
    email,
    phone: phone || '',
    serviceInterest: serviceInterest || 'General Inquiry',
    message,
    createdAt: new Date().toISOString(),
    isRead: false
  };
  currentMessages.unshift(newMsg);
  res.status(201).json({ success: true, message: 'Message sent successfully' });
});

app.put('/api/messages/:id/read', (req: Request, res: Response) => {
  const { id } = req.params;
  const msg = currentMessages.find(m => m.id === id);
  if (msg) {
    msg.isRead = true;
    res.json({ success: true });
  } else {
    res.status(404).json({ error: 'Message not found' });
  }
});

app.delete('/api/messages/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  currentMessages = currentMessages.filter(m => m.id !== id);
  res.json({ success: true, deletedId: id });
});

// Admin Auth
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (
    (email === 'admin@abdullah.dev' || email === 'bdh681100@gmail.com') && 
    (password === 'AbdullahAdmin2026!' || password === 'admin123')
  ) {
    res.json({
      success: true,
      token: 'jwt_mock_token_engineer_abdullah_secure_2026',
      user: {
        name: 'المهندس عبدالله عبدة شايف',
        email: email,
        role: 'superadmin'
      }
    });
  } else {
    res.status(401).json({ error: 'بيانات الدخول غير صحيحة. يرجى التأكد من البريد وكلمة المرور.' });
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req: Request, res: Response) => {
        res.sendFile(path.resolve(distPath, 'index.html'));
      });
    }
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`🚀 ABDULLAH SH AIF 3D Digital World Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
