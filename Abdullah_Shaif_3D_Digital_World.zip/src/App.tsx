import React, { useState, useEffect } from 'react';
import { WorldCanvas } from './components/3d/WorldCanvas';
import { TopNav } from './components/ui/TopNav';
import { ControlDock } from './components/ui/ControlDock';
import { CinematicHUD } from './components/ui/CinematicHUD';
import { AboutModal } from './components/ui/AboutModal';
import { SkillDetailModal } from './components/ui/SkillDetailModal';
import { SkillsBrowserModal } from './components/ui/SkillsBrowserModal';
import { ProjectDetailModal } from './components/ui/ProjectDetailModal';
import { ProjectsBrowserModal } from './components/ui/ProjectsBrowserModal';
import { ServicesModal } from './components/ui/ServicesModal';
import { ContactChamberModal } from './components/ui/ContactChamberModal';
import { ResumeModal } from './components/ui/ResumeModal';
import { AdminDashboardModal } from './components/ui/AdminDashboardModal';

import { initialProfile, initialProjects, initialSkills, initialServices } from './data/initialData';
import { ProfileInfo, ProjectItem, SkillItem, ServiceItem, SceneStation } from './types/portfolio';
import { cyberAudio } from './utils/audio';
import { generateFullPhpZip } from './utils/phpPackageGenerator';

export default function App() {
  // App data state
  const [profile, setProfile] = useState<ProfileInfo>(initialProfile);
  const [projects, setProjects] = useState<ProjectItem[]>(initialProjects);
  const [skills, setSkills] = useState<SkillItem[]>(initialSkills);
  const [services, setServices] = useState<ServiceItem[]>(initialServices);

  // Continuous Scroll & Drag Journey State (0.0 to 5.0)
  const [scrollProgress, setScrollProgress] = useState<number>(0.0);
  const [lang, setLang] = useState<'ar' | 'en'>('ar');
  const [highQuality, setHighQuality] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);

  // Modals state
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [selectedSkill, setSelectedSkill] = useState<SkillItem | null>(null);
  const [isSkillsBrowserOpen, setIsSkillsBrowserOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const [isProjectsBrowserOpen, setIsProjectsBrowserOpen] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [isResumeOpen, setIsResumeOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [prefilledInterest, setPrefilledInterest] = useState<string>('');

  // Fetch live backend data if available
  useEffect(() => {
    fetch('/api/profile')
      .then(res => res.json())
      .then(data => { if (data && data.nameAr) setProfile(data); })
      .catch(() => {});

    fetch('/api/projects')
      .then(res => res.json())
      .then(data => { if (Array.isArray(data) && data.length) setProjects(data); })
      .catch(() => {});

    fetch('/api/skills')
      .then(res => res.json())
      .then(data => { if (Array.isArray(data) && data.length) setSkills(data); })
      .catch(() => {});

    fetch('/api/services')
      .then(res => res.json())
      .then(data => { if (Array.isArray(data) && data.length) setServices(data); })
      .catch(() => {});
  }, []);

  // Update HTML dir and lang on language toggle
  useEffect(() => {
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  const handleToggleLang = () => {
    cyberAudio.playClickSound();
    setLang(prev => (prev === 'ar' ? 'en' : 'ar'));
  };

  const handleToggleSound = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    cyberAudio.setMuted(nextMuted);
  };

  const handleToggleQuality = () => {
    setHighQuality(prev => !prev);
  };

  const handleScrollDelta = (delta: number) => {
    setScrollProgress(prev => Math.max(0, Math.min(5.0, prev + delta)));
  };

  const currentStation: SceneStation = 
    scrollProgress < 0.9 ? 'home' :
    scrollProgress < 1.7 ? 'about' :
    scrollProgress < 3.3 ? 'projects' :
    scrollProgress < 4.1 ? 'skills' :
    scrollProgress < 4.7 ? 'services' : 'contact';

  const handleNavigateStation = (station: SceneStation) => {
    cyberAudio.playWarpSound();
    switch (station) {
      case 'home':
        setScrollProgress(0.0);
        break;
      case 'about':
        setScrollProgress(1.2);
        break;
      case 'skills':
        setScrollProgress(4.0);
        break;
      case 'projects':
        setScrollProgress(2.2);
        break;
      case 'services':
        setIsServicesOpen(true);
        break;
      case 'contact':
        setScrollProgress(4.8);
        break;
    }
  };

  const handleStationModalOpen = () => {
    switch (currentStation) {
      case 'about':
        setIsAboutOpen(true);
        break;
      case 'skills':
        setIsSkillsBrowserOpen(true);
        break;
      case 'projects':
        setIsProjectsBrowserOpen(true);
        break;
      case 'services':
        setIsServicesOpen(true);
        break;
      case 'contact':
        setIsContactOpen(true);
        break;
      default:
        break;
    }
  };

  const handleOrderProject = (projectTitle: string) => {
    setSelectedProject(null);
    setPrefilledInterest(projectTitle);
    setIsContactOpen(true);
  };

  const handleOrderService = (serviceTitle: string) => {
    setIsServicesOpen(false);
    setPrefilledInterest(serviceTitle);
    setIsContactOpen(true);
  };

  const handleDownloadPhpZip = async () => {
    try {
      cyberAudio.playClickSound();
      setIsDownloadingZip(true);
      const zipBlob = await generateFullPhpZip(profile, projects, skills, services);
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Abdullah_Shaif_Portfolio_PHP_MySQL.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      cyberAudio.playSuccessSound();
    } catch (err) {
      console.error('ZIP generation error:', err);
    } finally {
      setIsDownloadingZip(false);
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#050608] text-slate-100 select-none">
      {/* 3D WebGL World Canvas driven by continuous scroll & drag */}
      <WorldCanvas
        scrollProgress={scrollProgress}
        onScrollDelta={handleScrollDelta}
        projects={projects}
        skills={skills}
        services={services}
        onSelectProject={(p) => setSelectedProject(p)}
        onSelectSkill={(s) => setSelectedSkill(s)}
        highQuality={highQuality}
      />

      {/* Top Bar Navigation */}
      <TopNav
        currentStation={currentStation}
        onNavigate={handleNavigateStation}
        lang={lang}
        onToggleLang={handleToggleLang}
        isMuted={isMuted}
        onToggleSound={handleToggleSound}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenContact={() => {
          setPrefilledInterest('');
          setIsContactOpen(true);
        }}
      />

      {/* Cinematic HUD Story Overlay */}
      <CinematicHUD
        scrollProgress={scrollProgress}
        onSetScroll={(target) => setScrollProgress(target)}
        profile={profile}
        projects={projects}
        skills={skills}
        services={services}
        lang={lang}
        onOpenProjectModal={(p) => setSelectedProject(p)}
        onOpenProjectsBrowser={() => setIsProjectsBrowserOpen(true)}
        onOpenSkillsModal={() => setIsSkillsBrowserOpen(true)}
        onOpenContactModal={(interest) => {
          setPrefilledInterest(interest || '');
          setIsContactOpen(true);
        }}
        onOpenResumeModal={() => setIsResumeOpen(true)}
        onDownloadPhpZip={handleDownloadPhpZip}
        isDownloadingZip={isDownloadingZip}
      />

      {/* Collapsible Bottom Control Dock */}
      <ControlDock
        currentStation={currentStation}
        onNavigate={handleNavigateStation}
        lang={lang}
        highQuality={highQuality}
        onToggleQuality={handleToggleQuality}
        onDownloadPhpZip={handleDownloadPhpZip}
        isDownloadingZip={isDownloadingZip}
        onOpenStationModal={handleStationModalOpen}
      />

      {/* Modals & Detailed Inspection Drawers */}
      <AboutModal
        isOpen={isAboutOpen}
        onClose={() => setIsAboutOpen(false)}
        profile={profile}
        lang={lang}
        onOpenResume={() => {
          setIsAboutOpen(false);
          setIsResumeOpen(true);
        }}
      />

      <SkillDetailModal
        skill={selectedSkill}
        onClose={() => setSelectedSkill(null)}
        lang={lang}
      />

      <SkillsBrowserModal
        isOpen={isSkillsBrowserOpen}
        onClose={() => setIsSkillsBrowserOpen(false)}
        skills={skills}
        lang={lang}
        onSelectSkill={(s) => {
          setIsSkillsBrowserOpen(false);
          setSelectedSkill(s);
        }}
      />

      <ProjectDetailModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        lang={lang}
        onOrderSimilar={handleOrderProject}
      />

      <ProjectsBrowserModal
        isOpen={isProjectsBrowserOpen}
        onClose={() => setIsProjectsBrowserOpen(false)}
        projects={projects}
        lang={lang}
        onSelectProject={(p) => {
          setIsProjectsBrowserOpen(false);
          setSelectedProject(p);
        }}
      />

      <ServicesModal
        isOpen={isServicesOpen}
        onClose={() => setIsServicesOpen(false)}
        services={services}
        lang={lang}
        onOrderService={handleOrderService}
      />

      <ContactChamberModal
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
        profile={profile}
        services={services}
        lang={lang}
        prefilledInterest={prefilledInterest}
      />

      <ResumeModal
        isOpen={isResumeOpen}
        onClose={() => setIsResumeOpen(false)}
        profile={profile}
        projects={projects}
        skills={skills}
        lang={lang}
      />

      <AdminDashboardModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        profile={profile}
        onUpdateProfile={(updated) => setProfile(updated)}
        projects={projects}
        onUpdateProjects={(updated) => setProjects(updated)}
        skills={skills}
        onUpdateSkills={(updated) => setSkills(updated)}
        services={services}
        lang={lang}
        onDownloadPhpZip={handleDownloadPhpZip}
        isDownloadingZip={isDownloadingZip}
      />
    </div>
  );
}
