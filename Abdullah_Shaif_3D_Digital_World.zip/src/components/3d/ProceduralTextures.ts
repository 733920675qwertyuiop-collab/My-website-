import * as THREE from 'three';

/**
 * Procedural texture generators to ensure 100% zero external 404 dependencies.
 */

export function createCyberGridTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d')!;

  // Deep obsidian black background
  ctx.fillStyle = '#050608';
  ctx.fillRect(0, 0, 1024, 1024);

  // Hexagonal and orthogonal grid lines in amber glow
  ctx.strokeStyle = 'rgba(249, 115, 22, 0.2)';
  ctx.lineWidth = 1.5;

  const gridSize = 64;
  for (let x = 0; x <= 1024; x += gridSize) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 1024);
    ctx.stroke();
  }
  for (let y = 0; y <= 1024; y += gridSize) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(1024, y);
    ctx.stroke();
  }

  // Major accent circuit traces in electric orange & tactical olive
  ctx.strokeStyle = 'rgba(249, 115, 22, 0.55)';
  ctx.lineWidth = 2.5;
  for (let i = 0; i < 8; i++) {
    const rx = Math.floor(Math.random() * 16) * gridSize;
    const ry = Math.floor(Math.random() * 16) * gridSize;
    ctx.beginPath();
    ctx.moveTo(rx, ry);
    ctx.lineTo(rx + gridSize * 2, ry);
    ctx.lineTo(rx + gridSize * 3, ry + gridSize);
    ctx.stroke();

    // Circuit solder node dot
    ctx.fillStyle = i % 2 === 0 ? '#ff7700' : '#84cc16';
    ctx.beginPath();
    ctx.arc(rx, ry, 4.5, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(12, 12);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function createCodeMatrixTexture(title: string, subtitle: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Dark obsidian terminal screen
  ctx.fillStyle = '#090a0d';
  ctx.fillRect(0, 0, 1024, 512);

  // Border glow in neon orange
  ctx.strokeStyle = '#f97316';
  ctx.lineWidth = 6;
  ctx.strokeRect(4, 4, 1016, 504);

  // Top header bar
  ctx.fillStyle = '#18191f';
  ctx.fillRect(6, 6, 1012, 48);
  ctx.fillStyle = '#fb923c';
  ctx.font = 'bold 22px monospace';
  ctx.fillText(`ENGINEER TERMINAL :: ${title}`, 24, 38);

  // Terminal code lines
  ctx.fillStyle = '#84cc16';
  ctx.font = '18px monospace';
  ctx.fillText('// Systems Kernel & Real-time Architecture', 30, 90);

  const lines = [
    `namespace Abdullah\\Core\\Architecture;`,
    `class EngineKernel extends ServiceProvider {`,
    `    protected array $modules = ['Tareeqi', 'Legaci', 'Dawrak', 'BaseeraAI', 'Miqwat'];`,
    `    public function boot(): void {`,
    `        $this->bind(Database::class, fn() => new MySQLConnectionPool());`,
    `        $this->security->enforceHeaders(['X-Content-Type-Options' => 'nosniff']);`,
    `        $this->telemetry->stream('${subtitle}');`,
    `    }`,
    `}`
  ];

  ctx.fillStyle = '#fdba74';
  ctx.font = '19px monospace';
  lines.forEach((line, index) => {
    ctx.fillText(line, 30, 130 + index * 34);
  });

  // Futuristic status footer
  ctx.fillStyle = '#c2410c';
  ctx.fillRect(6, 460, 1012, 46);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 18px monospace';
  ctx.fillText('STATUS: SYSTEMS NOMINAL | MEMORY: 64MB | LATENCY: 0.2ms', 30, 490);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function createTechIconTexture(name: string, color: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#070d1e';
  ctx.fillRect(0, 0, 256, 256);

  ctx.strokeStyle = color;
  ctx.lineWidth = 8;
  ctx.strokeRect(8, 8, 240, 240);

  // Circular inner glow
  ctx.beginPath();
  ctx.arc(128, 128, 80, 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
  ctx.lineWidth = 3;
  ctx.stroke();

  // Tech text
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 36px "Chakra Petch", monospace, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(name, 128, 128);

  // Subtitle
  ctx.fillStyle = color;
  ctx.font = '16px monospace';
  ctx.fillText('ENGINEER', 128, 175);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}
