import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { ProjectItem, SkillItem, ServiceItem } from '../../types/portfolio';
import { createCyberGridTexture, createCodeMatrixTexture, createTechIconTexture } from './ProceduralTextures';

interface WorldCanvasProps {
  scrollProgress: number; // 0.0 to 5.0
  onScrollDelta: (delta: number) => void;
  projects: ProjectItem[];
  skills: SkillItem[];
  services: ServiceItem[];
  onSelectProject: (project: ProjectItem) => void;
  onSelectSkill: (skill: SkillItem) => void;
  highQuality: boolean;
}

// Pre-allocated scratch objects for zero GC in animation loop
const _vec3 = new THREE.Vector3();
const _targetPos = new THREE.Vector3();
const _targetLook = new THREE.Vector3();
const _raycaster = new THREE.Raycaster();
const _mouse = new THREE.Vector2();

export const WorldCanvas: React.FC<WorldCanvasProps> = ({
  scrollProgress,
  onScrollDelta,
  projects,
  skills,
  onSelectProject,
  onSelectSkill,
  highQuality
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<number>(scrollProgress);
  scrollRef.current = scrollProgress;

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x040507);
    scene.fog = new THREE.FogExp2(0x040507, 0.024);

    const camera = new THREE.PerspectiveCamera(54, width / height, 0.1, 150);
    camera.position.set(0, 2.8, 6.2);
    const lookAtTarget = new THREE.Vector3(0, 1.8, 0);
    camera.lookAt(lookAtTarget);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl && highQuality,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, highQuality ? 2 : 1.25));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;
    renderer.shadowMap.enabled = !isSoftwareGl && highQuality;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Studio Environment Reflections
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Lighting in Neon Orange and Tactical Amber/Olive
    const hemiLight = new THREE.HemisphereLight(0xf97316, 0x141a0e, 0.75);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xff7700, 1.9);
    keyLight.position.set(8, 14, 10);
    if (!isSoftwareGl && highQuality) {
      keyLight.castShadow = true;
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x84cc16, 1.4);
    rimLight.position.set(-10, 8, -8);
    scene.add(rimLight);

    // Dynamic Mouse-Tracking Ambient & Specular Lights for high realism and luxury highlights
    const mousePointLight = new THREE.PointLight(0xff7700, 3.8, 32, 1.2);
    mousePointLight.position.set(0, 3, 5);
    scene.add(mousePointLight);

    const mouseOliveFill = new THREE.PointLight(0x84cc16, 1.9, 24, 1.4);
    mouseOliveFill.position.set(-2, 2, 4);
    scene.add(mouseOliveFill);

    // Floor Grid in Deep Obsidian
    const floorGeo = new THREE.PlaneGeometry(240, 320);
    const floorTex = createCyberGridTexture();
    const floorMat = new THREE.MeshStandardMaterial({
      map: floorTex,
      roughness: 0.25,
      metalness: 0.9
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(0, 0, -50);
    floor.receiveShadow = !isSoftwareGl && highQuality;
    scene.add(floor);

    const textureLoader = new THREE.TextureLoader();

    // ----------------------------------------------------
    // HERO 3D PORTRAIT STAGE (Abdullah's Authentic Portrait)
    // ----------------------------------------------------
    const heroStage = new THREE.Group();
    heroStage.position.set(0, 0, 0);

    // Base emitter pedestal with counter-rotating rings
    const pedestalGeo = new THREE.CylinderGeometry(3.2, 3.6, 0.25, 48);
    const pedestalMat = new THREE.MeshStandardMaterial({
      color: 0x0a0c10,
      roughness: 0.2,
      metalness: 0.95
    });
    const pedestal = new THREE.Mesh(pedestalGeo, pedestalMat);
    pedestal.position.y = 0.125;
    heroStage.add(pedestal);

    const ring1Geo = new THREE.TorusGeometry(3.0, 0.04, 16, 64);
    const orangeRingMat = new THREE.MeshBasicMaterial({ color: 0xff6600 });
    const ring1 = new THREE.Mesh(ring1Geo, orangeRingMat);
    ring1.rotation.x = Math.PI / 2;
    ring1.position.y = 0.26;
    heroStage.add(ring1);

    const ring2Geo = new THREE.TorusGeometry(2.1, 0.035, 16, 64);
    const oliveRingMat = new THREE.MeshBasicMaterial({ color: 0x84cc16 });
    const ring2 = new THREE.Mesh(ring2Geo, oliveRingMat);
    ring2.rotation.x = Math.PI / 2;
    ring2.position.y = 0.27;
    heroStage.add(ring2);

    // Holographic Authentic Portrait Plane of Abdullah with High-Resolution Sharpening Filter
    const portraitGroup = new THREE.Group();
    portraitGroup.position.set(1.4, 2.5, 0.5);

    // Create high-resolution sharpening canvas
    const portraitCanvas = document.createElement('canvas');
    portraitCanvas.width = 1080;
    portraitCanvas.height = 2400;
    const portraitTex = new THREE.CanvasTexture(portraitCanvas);
    portraitTex.colorSpace = THREE.SRGBColorSpace;
    portraitTex.generateMipmaps = true;
    portraitTex.minFilter = THREE.LinearMipmapLinearFilter;
    portraitTex.magFilter = THREE.LinearFilter;
    if (renderer.capabilities?.getMaxAnisotropy) {
      portraitTex.anisotropy = renderer.capabilities.getMaxAnisotropy();
    }

    const rawPortrait = new Image();
    rawPortrait.crossOrigin = 'anonymous';
    rawPortrait.src = '/assets/aistudio/Screenshot_20261111-161120_d453d279.png';
    rawPortrait.onload = () => {
      const pctx = portraitCanvas.getContext('2d', { willReadFrequently: true });
      if (!pctx) return;

      // Draw high-res original
      pctx.drawImage(rawPortrait, 0, 0, 1080, 2400);

      try {
        const imgData = pctx.getImageData(0, 0, 1080, 2400);
        const d = imgData.data;
        // Sharpening & dynamic range expansion factor
        const contrast = 1.15; // 15% micro-contrast boost for facial definition
        const factor = (259 * (contrast * 255 + 255)) / (255 * (259 - contrast * 255));
        for (let i = 0; i < d.length; i += 4) {
          d[i] = Math.min(255, Math.max(0, factor * (d[i] - 128) + 128));     // R
          d[i + 1] = Math.min(255, Math.max(0, factor * (d[i + 1] - 128) + 128)); // G
          d[i + 2] = Math.min(255, Math.max(0, factor * (d[i + 2] - 128) + 128)); // B
        }
        pctx.putImageData(imgData, 0, 0);
      } catch {
        // Fallback to unedited canvas if crossOrigin restriction applies
      }
      portraitTex.needsUpdate = true;
    };

    const pHeight = 3.6;
    const pWidth = 1.62; // 3.6 * (1080 / 2400) = 1.62 exact aspect ratio
    const portraitGeo = new THREE.PlaneGeometry(pWidth, pHeight);
    const portraitMat = new THREE.MeshBasicMaterial({
      map: portraitTex,
      transparent: false,
      side: THREE.DoubleSide
    });
    const portraitMesh = new THREE.Mesh(portraitGeo, portraitMat);
    portraitGroup.add(portraitMesh);

    // Holographic Cyber Frame with bevelled borders in electric orange
    const holoFrameGeo = new THREE.BoxGeometry(pWidth + 0.12, pHeight + 0.12, 0.04);
    const holoFrameMat = new THREE.MeshBasicMaterial({
      color: 0xff7700,
      wireframe: true
    });
    const holoFrame = new THREE.Mesh(holoFrameGeo, holoFrameMat);
    portraitGroup.add(holoFrame);

    heroStage.add(portraitGroup);

    // Code Matrix Monolith on the left
    const codeScreenGroup = new THREE.Group();
    codeScreenGroup.position.set(-1.8, 2.3, 0);
    codeScreenGroup.rotation.y = 0.35;

    const screenGeo = new THREE.BoxGeometry(2.6, 1.6, 0.04);
    const codeTex = createCodeMatrixTexture('ABDULLAH SHAIF', 'SYSTEM ARCHITECT & ANDROID DEV');
    const screenMat = new THREE.MeshBasicMaterial({ map: codeTex });
    const screenMesh = new THREE.Mesh(screenGeo, screenMat);
    codeScreenGroup.add(screenMesh);

    const screenBorderGeo = new THREE.BoxGeometry(2.68, 1.68, 0.05);
    const screenBorderMat = new THREE.MeshBasicMaterial({ color: 0xf97316, wireframe: true });
    const screenBorder = new THREE.Mesh(screenBorderGeo, screenBorderMat);
    codeScreenGroup.add(screenBorder);

    heroStage.add(codeScreenGroup);
    scene.add(heroStage);

    // ----------------------------------------------------
    // ALL 40 3D PROJECT TERMINALS (Continuous Cyber Promenade)
    // ----------------------------------------------------
    const projectStationsGroup = new THREE.Group();
    const projectMeshes: THREE.Group[] = [];

    // Render all 40 projects along a dual-sided high-tech avenue
    projects.forEach((proj, idx) => {
      const pGroup = new THREE.Group();
      const isEven = idx % 2 === 0;
      const pairRow = Math.floor(idx / 2); // 0 to 19 (for 40 projects)
      const pZ = -12 - pairRow * 4.6;      // spans from -12 to -99.4
      const pX = isEven ? -3.5 : 3.5;
      const pY = 2.0;

      pGroup.position.set(pX, pY, pZ);
      pGroup.rotation.y = isEven ? 0.32 : -0.32;

      // Pedestal
      const baseGeo = new THREE.CylinderGeometry(1.2, 1.4, 0.6, 24);
      const baseMesh = new THREE.Mesh(baseGeo, pedestalMat);
      baseMesh.position.y = -1.6;
      pGroup.add(baseMesh);

      // Rotating Project Display Screen
      const pScreenGeo = new THREE.PlaneGeometry(3.6, 2.05);
      const pTex = textureLoader.load(proj.imageUrl);
      pTex.colorSpace = THREE.SRGBColorSpace;
      const pScreenMat = new THREE.MeshBasicMaterial({ map: pTex, side: THREE.DoubleSide });
      const pScreen = new THREE.Mesh(pScreenGeo, pScreenMat);
      pScreen.userData = { type: 'project', data: proj, index: idx };
      pGroup.add(pScreen);

      // Glowing Neon Cyber Border in Electric Orange
      const pBorderGeo = new THREE.BoxGeometry(3.72, 2.17, 0.05);
      const pBorderMat = new THREE.MeshBasicMaterial({ color: 0xff6600, wireframe: true });
      const pBorder = new THREE.Mesh(pBorderGeo, pBorderMat);
      pGroup.add(pBorder);

      // Floating holographic label plate with Arabic title and tech stack
      const labelCanvas = document.createElement('canvas');
      labelCanvas.width = 512;
      labelCanvas.height = 128;
      const lctx = labelCanvas.getContext('2d')!;
      lctx.fillStyle = '#080a0e';
      lctx.fillRect(0, 0, 512, 128);
      lctx.strokeStyle = '#f97316';
      lctx.lineWidth = 4;
      lctx.strokeRect(4, 4, 504, 120);
      lctx.fillStyle = '#ffffff';
      lctx.font = 'bold 26px "Tajawal", sans-serif';
      lctx.textAlign = 'center';
      lctx.fillText(`${idx + 1}. ${proj.titleAr}`, 256, 48);
      lctx.fillStyle = '#fb923c';
      lctx.font = 'bold 18px monospace';
      lctx.fillText(`[${proj.category.toUpperCase()}] ${proj.technologies.slice(0, 2).join(' · ')}`, 256, 92);

      const labelTex = new THREE.CanvasTexture(labelCanvas);
      labelTex.colorSpace = THREE.SRGBColorSpace;
      const labelGeo = new THREE.PlaneGeometry(2.8, 0.7);
      const labelMat = new THREE.MeshBasicMaterial({ map: labelTex });
      const labelMesh = new THREE.Mesh(labelGeo, labelMat);
      labelMesh.position.set(0, -1.35, 0.1);
      pGroup.add(labelMesh);

      projectStationsGroup.add(pGroup);
      projectMeshes.push(pGroup);
    });

    scene.add(projectStationsGroup);

    // ----------------------------------------------------
    // SKILLS MATRIX (Orbital Cloud at Z: -118)
    // ----------------------------------------------------
    const skillsCloudGroup = new THREE.Group();
    skillsCloudGroup.position.set(0, 2.5, -118);

    // Central rotating hypercube in glowing amber
    const hyperCoreGeo = new THREE.IcosahedronGeometry(1.2);
    const hyperCoreMat = new THREE.MeshStandardMaterial({
      color: 0xff7700,
      metalness: 0.9,
      roughness: 0.1,
      wireframe: true
    });
    const hyperCore = new THREE.Mesh(hyperCoreGeo, hyperCoreMat);
    skillsCloudGroup.add(hyperCore);

    const skillNodes: { mesh: THREE.Mesh; baseAngle: number; radius: number; speed: number; skill: SkillItem }[] = [];
    skills.slice(0, 12).forEach((skill, idx) => {
      const radius = 3.6 + (idx % 3) * 0.8;
      const angle = (idx / 12) * Math.PI * 2;
      const x = Math.cos(angle) * radius;
      const y = Math.sin(idx * 1.2) * 1.4;
      const z = Math.sin(angle) * radius;

      const nodeGeo = new THREE.DodecahedronGeometry(0.5);
      const nodeTex = createTechIconTexture(skill.name.split(' ')[0], skill.color);
      const nodeMat = new THREE.MeshStandardMaterial({
        map: nodeTex,
        roughness: 0.25,
        metalness: 0.8,
        color: new THREE.Color(skill.color)
      });
      const nodeMesh = new THREE.Mesh(nodeGeo, nodeMat);
      nodeMesh.position.set(x, y, z);
      nodeMesh.userData = { type: 'skill', data: skill };

      skillsCloudGroup.add(nodeMesh);
      skillNodes.push({ mesh: nodeMesh, baseAngle: angle, radius, speed: 0.3 + (idx % 2) * 0.1, skill });
    });

    scene.add(skillsCloudGroup);

    // ----------------------------------------------------
    // PARTICLE VORTEX FIELD (Amber Embers)
    // ----------------------------------------------------
    const particleCount = isSoftwareGl ? 350 : 1200;
    const particleGeo = new THREE.BufferGeometry();
    const pPositions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      pPositions[i * 3] = (Math.random() - 0.5) * 50;
      pPositions[i * 3 + 1] = Math.random() * 12 + 0.2;
      pPositions[i * 3 + 2] = -Math.random() * 140 + 8;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(pPositions, 3));
    const particleMat = new THREE.PointsMaterial({
      size: 0.08,
      color: 0xf97316,
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // ----------------------------------------------------
    // INTERACTION & MOUSE PARALLAX CONTROLS
    // ----------------------------------------------------
    let mouseX = 0;
    let mouseY = 0;
    let isMouseDown = false;
    let startY = 0;

    const onPointerMove = (e: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      const nx = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const ny = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      mouseX = nx;
      mouseY = ny;

      _mouse.x = nx;
      _mouse.y = ny;

      if (isMouseDown) {
        const deltaY = e.clientY - startY;
        startY = e.clientY;
        onScrollDelta(-deltaY * 0.006);
      }
    };

    const onPointerDown = (e: PointerEvent) => {
      isMouseDown = true;
      startY = e.clientY;
    };

    const onPointerUp = () => {
      isMouseDown = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      onScrollDelta(e.deltaY * 0.0025);
    };

    const onClick = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      _mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      _mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      _raycaster.setFromCamera(_mouse, camera);
      const allClickables: THREE.Object3D[] = [];
      projectMeshes.forEach(p => allClickables.push(p.children[1]));
      skillNodes.forEach(s => allClickables.push(s.mesh));

      const intersects = _raycaster.intersectObjects(allClickables, true);
      if (intersects.length > 0) {
        const hit = intersects[0].object;
        if (hit.userData.type === 'project') {
          onSelectProject(hit.userData.data);
        } else if (hit.userData.type === 'skill') {
          onSelectSkill(hit.userData.data);
        }
      }
    };

    container.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    container.addEventListener('wheel', onWheel, { passive: false });
    container.addEventListener('click', onClick);

    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    // ----------------------------------------------------
    // ANIMATION & CAMERA INTERPOLATION LOOP
    // ----------------------------------------------------
    const clock = new THREE.Clock();
    let frameId = 0;

    // Spline-like trajectory for the camera traversing all 40 projects
    const computeCameraSpline = (progress: number) => {
      let camX = 0;
      let camY = 2.8;
      let camZ = 6.2;
      let lookX = 0;
      let lookY = 1.8;
      let lookZ = 0;

      if (progress <= 1.0) {
        const t = progress;
        // From home (Z: 6.2) to Identity focus (Z: 3.8, angled)
        camX = THREE.MathUtils.lerp(0, 1.2, t);
        camY = THREE.MathUtils.lerp(2.8, 2.5, t);
        camZ = THREE.MathUtils.lerp(6.2, 3.8, t);
        lookX = THREE.MathUtils.lerp(0, 1.4, t);
        lookY = THREE.MathUtils.lerp(1.8, 2.5, t);
        lookZ = THREE.MathUtils.lerp(0, 0.5, t);
      } else if (progress <= 1.7) {
        // Approaching projects promenade gateway
        const t = (progress - 1.0) / 0.7;
        camX = THREE.MathUtils.lerp(1.2, 0, t);
        camY = THREE.MathUtils.lerp(2.5, 2.7, t);
        camZ = THREE.MathUtils.lerp(3.8, -4.0, t);
        lookX = THREE.MathUtils.lerp(1.4, 0, t);
        lookY = THREE.MathUtils.lerp(2.5, 2.1, t);
        lookZ = THREE.MathUtils.lerp(0.5, -14.0, t);
      } else if (progress <= 3.8) {
        // Gliding all the way through the 40 projects promenade (from Z: -4 to Z: -102)
        const t = (progress - 1.7) / 2.1; // 0 to 1 across 40 projects
        const targetProjZ = -10 - t * 92;
        const sway = Math.sin(t * Math.PI * 6) * 1.5;

        camX = sway;
        camY = 2.4 + Math.sin(t * Math.PI * 4) * 0.2;
        camZ = targetProjZ + 7.5;
        lookX = -sway * 0.35;
        lookY = 2.0;
        lookZ = targetProjZ - 3.0;
      } else {
        // Gliding into Skills Cloud (Z: -118)
        const t = (progress - 3.8) / 1.2;
        camX = Math.sin(t * Math.PI) * 4.0;
        camY = 3.0;
        camZ = THREE.MathUtils.lerp(-104, -112, t);
        lookX = 0;
        lookY = 2.5;
        lookZ = -118;
      }

      return { camX, camY, camZ, lookX, lookY, lookZ };
    };

    function tick() {
      const delta = Math.min(clock.getDelta(), 0.1);
      const elapsed = clock.getElapsedTime();

      // Compute camera target from scroll position + mouse parallax
      const spline = computeCameraSpline(scrollRef.current);
      const parallaxFactor = 0.6;
      _targetPos.set(
        spline.camX + mouseX * parallaxFactor,
        spline.camY + mouseY * (parallaxFactor * 0.6),
        spline.camZ
      );
      _targetLook.set(
        spline.lookX + mouseX * (parallaxFactor * 0.4),
        spline.lookY + mouseY * (parallaxFactor * 0.4),
        spline.lookZ
      );

      // Silky-smooth exponential damping
      const damp = 1 - Math.exp(-4.2 * delta);
      camera.position.lerp(_targetPos, damp);
      lookAtTarget.lerp(_targetLook, damp);
      camera.lookAt(lookAtTarget);

      // Dynamic mouse-tracking ambient and specular point lighting
      const mouseTargetX = camera.position.x + (mouseX * 5.5);
      const mouseTargetY = camera.position.y + (mouseY * 4.2);
      const mouseTargetZ = camera.position.z - 2.5;
      mousePointLight.position.lerp(new THREE.Vector3(mouseTargetX, mouseTargetY, mouseTargetZ), 0.12);
      mouseOliveFill.position.lerp(new THREE.Vector3(mouseTargetX - 2.2, mouseTargetY - 1.4, mouseTargetZ - 1.0), 0.09);

      // Living cinematic pulse & ambient sheen
      mousePointLight.intensity = (highQuality ? 3.8 : 2.4) + Math.sin(elapsed * 2.8) * 0.45;
      mouseOliveFill.intensity = (highQuality ? 1.9 : 1.2) + Math.cos(elapsed * 2.2) * 0.25;
      hemiLight.intensity = 0.75 + (mouseY + 1.0) * 0.16;

      // Animate Hero Hologram & rings
      ring1.rotation.z = elapsed * 0.4;
      ring2.rotation.z = -elapsed * 0.6;
      portraitGroup.rotation.y = Math.sin(elapsed * 1.2) * 0.08 + mouseX * 0.15;
      portraitGroup.rotation.x = -mouseY * 0.1;
      codeScreenGroup.rotation.y = 0.35 + Math.sin(elapsed * 0.8) * 0.05;

      // Animate project screens gently floating
      projectMeshes.forEach((mesh, idx) => {
        mesh.position.y = 2.0 + Math.sin(elapsed * 1.5 + idx) * 0.12;
      });

      // Animate skills orbiting cloud
      hyperCore.rotation.x = elapsed * 0.6;
      hyperCore.rotation.y = elapsed * 0.9;
      skillNodes.forEach((node) => {
        const curAngle = node.baseAngle + elapsed * node.speed;
        node.mesh.position.x = Math.cos(curAngle) * node.radius;
        node.mesh.position.z = Math.sin(curAngle) * node.radius;
        node.mesh.position.y = Math.sin(elapsed * 2 + node.baseAngle) * 0.8;
        node.mesh.rotation.y = elapsed * 1.2;
      });

      // Animate particles drifting
      const pArr = particleGeo.attributes.position.array as Float32Array;
      for (let i = 0; i < particleCount; i++) {
        pArr[i * 3 + 2] += 0.04;
        if (pArr[i * 3 + 2] > 8) {
          pArr[i * 3 + 2] = -55;
        }
      }
      particleGeo.attributes.position.needsUpdate = true;

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        const gl = renderer.getContext() as WebGL2RenderingContext;
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
          if (state === gl.UNSIGNALED) {
            frameId = window.setTimeout(poll, 5);
          } else {
            gl.deleteSync(sync);
            frameId = window.setTimeout(tick, 80);
          }
        };
        frameId = window.setTimeout(poll, 5);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    tick();

    return () => {
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', onResize);
      container.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      container.removeEventListener('wheel', onWheel);
      container.removeEventListener('click', onClick);

      renderer.dispose();
      floorTex.dispose();
      floorGeo.dispose();
      floorMat.dispose();
      particleGeo.dispose();
      particleMat.dispose();
    };
  }, [highQuality, onScrollDelta, onSelectProject, onSelectSkill, projects, skills]);

  return (
    <div
      ref={mountRef}
      className="absolute inset-0 w-full h-full overflow-hidden cursor-grab active:cursor-grabbing select-none"
    />
  );
};
