import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, ShieldCheck, Terminal, Download } from 'lucide-react';
import { ProfileInfo } from '../../types/portfolio';
import { cyberAudio } from '../../utils/audio';
import { ModalCloseButton } from './ModalCloseButton';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: ProfileInfo;
  lang: 'ar' | 'en';
  onOpenResume: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({
  isOpen,
  onClose,
  profile,
  lang,
  onOpenResume
}) => {
  const isAr = lang === 'ar';

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-xs"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 25 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -15 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-[#08090d] border border-orange-500/30 rounded-2xl shadow-2xl p-6 md:p-8 text-slate-100"
          >
            {/* Global Animated Close Button */}
            <ModalCloseButton onClose={onClose} />

            {/* Header Unboxed Metadata */}
            <div className="flex items-center gap-2 text-xs font-semibold text-orange-400 mb-2">
              <span>{isAr ? 'الملف الشخصي والمهني' : 'Professional Biography'}</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>{isAr ? 'مهندس نظم وتطبيقات' : 'Systems & Mobile Architect'}</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-6 font-cyber">
              {isAr ? 'عن المهندس عبدالله عبدة شايف' : 'About Engineer Abdullah Abdo Shaif'}
            </h2>

            {/* 2-Column Split: Image on Left/Right & Bio Narrative */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch mb-8">
              {/* Portrait Showcase Card */}
              <div className="md:col-span-5 flex flex-col items-center">
                <div className="relative w-full aspect-[9/16] max-h-[460px] rounded-2xl overflow-hidden border border-orange-500/40 shadow-2xl bg-black">
                  <img
                    src={profile.avatarUrl}
                    alt={isAr ? profile.nameAr : profile.nameEn}
                    className="w-full h-full object-cover object-[center_25%]"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-3 left-3 rtl:left-auto rtl:right-3 px-2 py-0.5 bg-black/80 backdrop-blur-md border border-orange-500/40 rounded text-[10px] text-orange-400 font-mono font-bold">
                    {isAr ? 'الصورة الشخصية الحقيقية' : 'Authentic Portrait'}
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent flex items-end p-4">
                    <div>
                      <p className="text-sm font-bold text-white font-cyber">
                        {isAr ? profile.nameAr : profile.nameEn}
                      </p>
                      <p className="text-xs text-orange-400">
                        {isAr ? 'مهندس برمجيات ونظم معلومات' : 'Software & IS Engineer'}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="w-full mt-3 p-3 bg-black/60 rounded-lg border border-slate-800/80 text-xs text-slate-300 space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-400">{isAr ? 'الموقع الجغرافي:' : 'Location:'}</span>
                    <span className="font-medium text-white">{isAr ? profile.locationAr : profile.locationEn}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">{isAr ? 'البريد الإلكتروني:' : 'Email:'}</span>
                    <span className="font-mono text-orange-400">{profile.email}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">{isAr ? 'الحالة الحالية:' : 'Status:'}</span>
                    <span className="text-lime-400 font-semibold">{isAr ? 'متاح للمشاريع والتعاقد' : 'Open for Hire'}</span>
                  </div>
                </div>
              </div>

              {/* Biography Text & Engineering Principles */}
              <div className="md:col-span-7 flex flex-col justify-between">
                <div className="space-y-4 text-sm leading-relaxed text-slate-300">
                  <p className="p-4 bg-orange-950/20 border-r-2 rtl:border-r-2 rtl:border-l-0 ltr:border-l-2 ltr:border-r-0 border-orange-500 rounded-lg text-slate-200">
                    {isAr ? profile.bioAr : profile.bioEn}
                  </p>

                  <h3 className="text-base font-bold text-white pt-2 font-cyber">
                    {isAr ? 'المبادئ البرمجية والهندسية التي ألتزم بها:' : 'Core Engineering Principles:'}
                  </h3>

                  <div className="space-y-2.5">
                    <div className="flex items-start gap-2.5">
                      <CheckCircle2 className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold text-white text-xs block">
                          {isAr ? '1. كود نظيف ومعمارية قابلة للتوسع (Clean Architecture)' : '1. Clean Architecture & Scalability'}
                        </span>
                        <span className="text-xs text-slate-400">
                          {isAr
                            ? 'كتابة شيفرات برمجية واضحة وموثقة تلتزم بمبادئ OOP ومعمارية MVC وتسهل التطوير المستقبلي.'
                            : 'Writing well-documented, testable code adhering to strict OOP patterns and modular MVC boundaries.'}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <ShieldCheck className="w-4 h-4 text-lime-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold text-white text-xs block">
                          {isAr ? '2. أمان البيانات والحماية الشاملة (Security-First)' : '2. Security-First Architecture'}
                        </span>
                        <span className="text-xs text-slate-400">
                          {isAr
                            ? 'حماية مطلقة ضد ثغرات الحقن SQL Injection، هجمات XSS وCSRF، وتشفير الجلسات وكلمات المرور.'
                            : 'Enforcing OWASP guidelines, prepared PDO statements, AES encryption, and robust CSRF/XSS defenses.'}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <Terminal className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold text-white text-xs block">
                          {isAr ? '3. تكامل الأنظمة وحلول واقعية (Production-Ready Solutions)' : '3. Resilient Real-World Systems'}
                        </span>
                        <span className="text-xs text-slate-400">
                          {isAr
                            ? 'بناء أنظمة تعالج مشكلات حقيقية وتعمل بسلاسة حتى في ظروف الاتصال الضعيفة وأكشاك الخدمة.'
                            : 'Engineering offline-tolerant systems tailored to live operating constraints, kiosk displays, and high-concurrency.'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Quick Actions Row */}
                <div className="flex items-center gap-3 pt-6 border-t border-slate-800 mt-6">
                  <button
                    onClick={() => {
                      cyberAudio.playClickSound();
                      onOpenResume();
                    }}
                    className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-black bg-orange-500 hover:bg-orange-400 rounded-lg transition-all shadow-md shadow-orange-500/20 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>{isAr ? 'عرض السيرة الذاتية المفصلة' : 'View Full Resume'}</span>
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
