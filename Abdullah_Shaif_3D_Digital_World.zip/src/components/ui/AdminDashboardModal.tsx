import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Save, Trash2, Plus, Download, CheckCircle2, AlertCircle, LogOut } from 'lucide-react';
import { ProfileInfo, ProjectItem, SkillItem, ServiceItem, ContactMessage } from '../../types/portfolio';
import { cyberAudio } from '../../utils/audio';
import { ModalCloseButton } from './ModalCloseButton';

interface AdminDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: ProfileInfo;
  onUpdateProfile: (p: ProfileInfo) => void;
  projects: ProjectItem[];
  onUpdateProjects: (projs: ProjectItem[]) => void;
  skills: SkillItem[];
  onUpdateSkills: (s: SkillItem[]) => void;
  services: ServiceItem[];
  lang: 'ar' | 'en';
  onDownloadPhpZip: () => void;
  isDownloadingZip: boolean;
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({
  isOpen,
  onClose,
  profile,
  onUpdateProfile,
  projects,
  onUpdateProjects,
  skills,
  lang,
  onDownloadPhpZip,
  isDownloadingZip
}) => {
  const isAr = lang === 'ar';
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [email, setEmail] = useState('admin@abdullah.dev');
  const [password, setPassword] = useState('AbdullahAdmin2026!');
  const [loginError, setLoginError] = useState('');
  const [activeTab, setActiveTab] = useState<'profile' | 'projects' | 'skills' | 'messages'>('profile');

  // Form states
  const [editProfile, setEditProfile] = useState<ProfileInfo>({ ...profile });
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // New Project Form
  const [isAddingProject, setIsAddingProject] = useState(false);
  const [newProject, setNewProject] = useState<Partial<ProjectItem>>({
    titleAr: '',
    titleEn: '',
    taglineAr: '',
    category: 'web',
    descriptionAr: '',
    technologies: ['PHP', 'MySQL', 'React'],
    featuresAr: [''],
    imageUrl: '/src/assets/images/tareeqi_transport_platform_1794403804965.jpg',
    featured: true
  });

  const showNotification = (type: 'success' | 'error', text: string) => {
    setNotification({ type, text });
    setTimeout(() => setNotification(null), 3500);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setIsAuthenticated(true);
        cyberAudio.playSuccessSound();
        fetch('/api/messages')
          .then(r => r.json())
          .then(msgs => setMessages(msgs))
          .catch(() => {});
      } else {
        setLoginError(data.error || (isAr ? 'فشل تسجيل الدخول' : 'Invalid credentials'));
      }
    } catch {
      setLoginError(isAr ? 'تعذر الاتصال بخادم المصادقة' : 'Authentication server offline');
    }
  };

  const handleSaveProfile = async () => {
    try {
      const res = await fetch('/api/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editProfile)
      });
      if (res.ok) {
        onUpdateProfile(editProfile);
        cyberAudio.playSuccessSound();
        showNotification('success', isAr ? 'تم حفظ التعديلات بنجاح' : 'Profile updated successfully');
      }
    } catch {
      showNotification('error', isAr ? 'فشل حفظ التعديلات' : 'Failed to save updates');
    }
  };

  const handleDeleteProject = async (id: string) => {
    if (!confirm(isAr ? 'هل أنت متأكد من حذف هذا المشروع؟' : 'Are you sure you want to delete this project?')) return;
    try {
      const res = await fetch(`/api/projects/${id}`, { method: 'DELETE' });
      if (res.ok) {
        const updated = projects.filter(p => p.id !== id);
        onUpdateProjects(updated);
        cyberAudio.playClickSound();
        showNotification('success', isAr ? 'تم حذف المشروع' : 'Project deleted');
      }
    } catch {
      showNotification('error', 'Failed to delete');
    }
  };

  const handleAddProject = async (e: React.FormEvent) => {
    e.preventDefault();
    const id = `proj_${Date.now()}`;
    const toSave: ProjectItem = {
      id,
      titleAr: newProject.titleAr || 'مشروع جديد',
      titleEn: newProject.titleEn || 'New Project',
      taglineAr: newProject.taglineAr || '',
      taglineEn: newProject.taglineEn || '',
      descriptionAr: newProject.descriptionAr || '',
      descriptionEn: newProject.descriptionEn || '',
      technologies: newProject.technologies || ['PHP', 'MySQL'],
      category: (newProject.category as any) || 'web',
      imageUrl: newProject.imageUrl || '/src/assets/images/tareeqi_transport_platform_1794403804965.jpg',
      featuresAr: newProject.featuresAr || [],
      featuresEn: newProject.featuresEn || [],
      featured: true
    };

    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(toSave)
      });
      if (res.ok) {
        onUpdateProjects([toSave, ...projects]);
        setIsAddingProject(false);
        cyberAudio.playSuccessSound();
        showNotification('success', isAr ? 'تمت إضافة المشروع الجديد بنجاح' : 'Project created');
      }
    } catch {
      showNotification('error', 'Failed to add project');
    }
  };

  const handleDeleteMessage = async (id: string) => {
    try {
      await fetch(`/api/messages/${id}`, { method: 'DELETE' });
      setMessages(messages.filter(m => m.id !== id));
      cyberAudio.playClickSound();
    } catch {
      // ignore
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-xs"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 25 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -15 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-5xl max-h-[92vh] overflow-y-auto bg-[#08090d] border border-orange-500/30 rounded-2xl p-6 md:p-8 shadow-2xl text-slate-100"
          >
            {/* Global Animated Close Button */}
            <ModalCloseButton onClose={onClose} />

            {/* Notification Toast */}
            {notification && (
              <div
                className={`fixed top-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold shadow-lg ${
                  notification.type === 'success'
                    ? 'bg-emerald-950 border border-emerald-500 text-emerald-300'
                    : 'bg-red-950 border border-red-500 text-red-300'
                }`}
              >
                {notification.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                <span>{notification.text}</span>
              </div>
            )}

            {!isAuthenticated ? (
              /* LOGIN SCREEN */
              <div className="max-w-md mx-auto py-8">
                <div className="text-center mb-6">
                  <div className="w-12 h-12 bg-orange-950/60 border border-orange-500/40 rounded-xl flex items-center justify-center mx-auto mb-3 text-orange-400">
                    <Lock className="w-6 h-6" />
                  </div>
                  <h2 className="text-2xl font-bold text-white font-cyber">
                    {isAr ? 'لوحة تحكم إدارة النظام' : 'Admin Security Console'}
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    {isAr
                      ? 'تسجيل الدخول لإدارة المشاريع والخدمات والرسائل'
                      : 'Authorized Personnel Only :: Enterprise Portal'}
                  </p>
                </div>

                {loginError && (
                  <div className="p-3 mb-4 bg-red-950/40 border border-red-500/40 rounded-lg text-xs text-red-300 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{loginError}</span>
                  </div>
                )}

                <form onSubmit={handleLogin} className="space-y-4 bg-black/60 p-6 rounded-xl border border-slate-800">
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1">
                      {isAr ? 'البريد الإلكتروني للمدير' : 'Admin Email'}
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3.5 py-2 text-xs text-white bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-lg outline-none font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1">
                      {isAr ? 'كلمة المرور' : 'Password'}
                    </label>
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-3.5 py-2 text-xs text-white bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-lg outline-none font-mono"
                    />
                  </div>

                  <div className="p-2.5 bg-black/80 rounded border border-slate-800 text-[11px] text-slate-400 space-y-1">
                    <p className="text-orange-400 font-semibold">{isAr ? 'بيانات الدخول المعتمدة:' : 'Credentials:'}</p>
                    <p>Email: <code className="text-white">admin@abdullah.dev</code></p>
                    <p>Pass: <code className="text-white">AbdullahAdmin2026!</code></p>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 px-4 text-xs font-bold text-black bg-orange-500 hover:bg-orange-400 rounded-lg transition-colors cursor-pointer shadow-md shadow-orange-500/20"
                  >
                    {isAr ? 'تسجيل الدخول الآمن' : 'Authorize & Enter'}
                  </button>
                </form>
              </div>
            ) : (
              /* AUTHENTICATED DASHBOARD */
              <div>
                {/* Top Bar with Logout */}
                <div className="flex flex-wrap items-center justify-between gap-4 pb-4 mb-6 border-b border-slate-800">
                  <div>
                    <span className="text-xs font-mono text-orange-400 font-semibold">SECURITY_LEVEL: SUPERADMIN</span>
                    <h2 className="text-xl font-bold text-white font-cyber">
                      {isAr ? 'لوحة تحكم الموقع — المهندس عبدالله' : 'System Administration Console'}
                    </h2>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={onDownloadPhpZip}
                      disabled={isDownloadingZip}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-black bg-orange-500 hover:bg-orange-400 rounded-lg transition-colors shadow-sm cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{isAr ? 'تصدير حزمة PHP + SQL' : 'Export Full PHP Package'}</span>
                    </button>

                    <button
                      onClick={() => setIsAuthenticated(false)}
                      className="flex items-center gap-1 px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-900 border border-slate-800 rounded-lg transition-colors cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>{isAr ? 'خروج' : 'Logout'}</span>
                    </button>
                  </div>
                </div>

                {/* Tabs */}
                <div className="flex items-center gap-2 mb-6 border-b border-slate-800 pb-2 overflow-x-auto">
                  {[
                    { id: 'profile', labelAr: 'المعلومات الشخصية والاتصال', labelEn: 'Profile & Contact' },
                    { id: 'projects', labelAr: `المشاريع (${projects.length})`, labelEn: `Projects (${projects.length})` },
                    { id: 'skills', labelAr: `المهارات (${skills.length})`, labelEn: `Skills (${skills.length})` },
                    { id: 'messages', labelAr: `صندوق الرسائل (${messages.length})`, labelEn: `Messages (${messages.length})` }
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                        activeTab === tab.id ? 'bg-orange-500 text-black shadow-sm font-bold' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {isAr ? tab.labelAr : tab.labelEn}
                    </button>
                  ))}
                </div>

                {/* TAB 1: Profile & Contact */}
                {activeTab === 'profile' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1">الاسم بالعربية</label>
                        <input
                          type="text"
                          value={editProfile.nameAr}
                          onChange={(e) => setEditProfile({ ...editProfile, nameAr: e.target.value })}
                          className="w-full px-3 py-2 text-xs text-white bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-lg outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1">Name in English</label>
                        <input
                          type="text"
                          value={editProfile.nameEn}
                          onChange={(e) => setEditProfile({ ...editProfile, nameEn: e.target.value })}
                          className="w-full px-3 py-2 text-xs text-white bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-lg outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1">المسمى الوظيفي (عربي)</label>
                        <input
                          type="text"
                          value={editProfile.titleAr}
                          onChange={(e) => setEditProfile({ ...editProfile, titleAr: e.target.value })}
                          className="w-full px-3 py-2 text-xs text-white bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-lg outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1">Title in English</label>
                        <input
                          type="text"
                          value={editProfile.titleEn}
                          onChange={(e) => setEditProfile({ ...editProfile, titleEn: e.target.value })}
                          className="w-full px-3 py-2 text-xs text-white bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-lg outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1">البريد الإلكتروني</label>
                        <input
                          type="email"
                          value={editProfile.email}
                          onChange={(e) => setEditProfile({ ...editProfile, email: e.target.value })}
                          className="w-full px-3 py-2 text-xs text-white bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-lg outline-none font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1">رقم الواتساب</label>
                        <input
                          type="text"
                          value={editProfile.whatsapp}
                          onChange={(e) => setEditProfile({ ...editProfile, whatsapp: e.target.value })}
                          className="w-full px-3 py-2 text-xs text-white bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-lg outline-none font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1">الموقع الجغرافي</label>
                        <input
                          type="text"
                          value={editProfile.locationAr}
                          onChange={(e) => setEditProfile({ ...editProfile, locationAr: e.target.value })}
                          className="w-full px-3 py-2 text-xs text-white bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-lg outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-400 mb-1">النبذة المهنية (عربي)</label>
                      <textarea
                        rows={4}
                        value={editProfile.bioAr}
                        onChange={(e) => setEditProfile({ ...editProfile, bioAr: e.target.value })}
                        className="w-full px-3 py-2 text-xs text-white bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-lg outline-none resize-none"
                      />
                    </div>

                    <div className="flex justify-end pt-4">
                      <button
                        onClick={handleSaveProfile}
                        className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-black bg-orange-500 hover:bg-orange-400 rounded-lg transition-colors cursor-pointer shadow-sm shadow-orange-500/20"
                      >
                        <Save className="w-4 h-4" />
                        <span>حفظ التعديلات</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* TAB 2: Projects CRUD */}
                {activeTab === 'projects' && (
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-sm font-bold text-white">إدارة المشاريع والأنظمة</h3>
                      <button
                        onClick={() => setIsAddingProject(!isAddingProject)}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-black bg-orange-500 hover:bg-orange-400 rounded-lg cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>إضافة مشروع جديد</span>
                      </button>
                    </div>

                    {isAddingProject && (
                      <form onSubmit={handleAddProject} className="p-4 mb-6 bg-black/80 border border-orange-500/30 rounded-xl space-y-3">
                        <h4 className="text-xs font-bold text-orange-400">إدخال مشروع جديد</h4>
                        <div className="grid grid-cols-2 gap-3">
                          <input
                            placeholder="عنوان المشروع بالعربية"
                            required
                            value={newProject.titleAr}
                            onChange={(e) => setNewProject({ ...newProject, titleAr: e.target.value })}
                            className="px-3 py-1.5 text-xs bg-slate-950 border border-slate-800 focus:border-orange-500 text-white rounded"
                          />
                          <input
                            placeholder="Project Title (English)"
                            required
                            value={newProject.titleEn}
                            onChange={(e) => setNewProject({ ...newProject, titleEn: e.target.value })}
                            className="px-3 py-1.5 text-xs bg-slate-950 border border-slate-800 focus:border-orange-500 text-white rounded"
                          />
                        </div>
                        <textarea
                          placeholder="الوصف التفصيلي للمشروع"
                          required
                          rows={3}
                          value={newProject.descriptionAr}
                          onChange={(e) => setNewProject({ ...newProject, descriptionAr: e.target.value })}
                          className="w-full px-3 py-1.5 text-xs bg-slate-950 border border-slate-800 focus:border-orange-500 text-white rounded resize-none"
                        />
                        <div className="flex justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setIsAddingProject(false)}
                            className="px-3 py-1 text-xs text-slate-400 hover:text-white"
                          >
                            إلغاء
                          </button>
                          <button
                            type="submit"
                            className="px-4 py-1.5 text-xs font-bold text-black bg-orange-500 rounded"
                          >
                            حفظ المشروع
                          </button>
                        </div>
                      </form>
                    )}

                    <div className="space-y-3">
                      {projects.map((proj) => (
                        <div key={proj.id} className="flex items-center justify-between p-3.5 bg-black/60 border border-slate-800 rounded-xl">
                          <div className="flex items-center gap-3">
                            <img
                              src={proj.imageUrl}
                              alt=""
                              className="w-16 h-10 object-cover rounded border border-slate-800"
                            />
                            <div>
                              <h4 className="text-xs font-bold text-white">{proj.titleAr}</h4>
                              <span className="text-[11px] text-orange-400 font-mono">{proj.technologies.join(', ')}</span>
                            </div>
                          </div>
                          <button
                            onClick={() => handleDeleteProject(proj.id)}
                            className="p-2 text-slate-400 hover:text-red-400 hover:bg-slate-900 rounded transition-colors"
                            title="حذف المشروع"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* TAB 3: Skills */}
                {activeTab === 'skills' && (
                  <div className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {skills.map((s) => (
                        <div key={s.id} className="p-3 bg-black/60 border border-slate-800 rounded-xl flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: s.color }} />
                            <span className="text-xs font-bold text-white">{s.name}</span>
                          </div>
                          <span className="text-xs font-mono font-bold text-orange-400">{s.level}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* TAB 4: Messages */}
                {activeTab === 'messages' && (
                  <div className="space-y-3">
                    {messages.length === 0 ? (
                      <p className="text-xs text-slate-400 py-6 text-center">لا توجد رسائل واردة حالياً.</p>
                    ) : (
                      messages.map((msg) => (
                        <div key={msg.id} className="p-4 bg-black/60 border border-slate-800 rounded-xl space-y-2">
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="text-xs font-bold text-white">{msg.name}</span>
                              <span className="text-xs text-slate-400 font-mono mx-2">({msg.email})</span>
                              {msg.phone && <span className="text-xs text-slate-400 font-mono">| {msg.phone}</span>}
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-[11px] text-slate-500 font-mono">
                                {new Date(msg.createdAt).toLocaleDateString('ar-YE')}
                              </span>
                              <button
                                onClick={() => handleDeleteMessage(msg.id)}
                                className="p-1 text-slate-400 hover:text-red-400"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                          <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-2.5 rounded border border-slate-800">
                            {msg.message}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
