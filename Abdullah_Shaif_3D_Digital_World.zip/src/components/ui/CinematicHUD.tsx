import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sparkles, Send, FileText, ArrowDown, ChevronRight, ChevronLeft, 
  Layers, ShieldCheck, Cpu, Code2, MessageCircle, Download, X, Eye
} from 'lucide-react';
import { ProfileInfo, ProjectItem, SkillItem, ServiceItem } from '../../types/portfolio';
import { cyberAudio } from '../../utils/audio';

interface CinematicHUDProps {
  scrollProgress: number;
  onSetScroll: (target: number) => void;
  profile: ProfileInfo;
  projects: ProjectItem[];
  skills: SkillItem[];
  services: ServiceItem[];
  lang: 'ar' | 'en';
  onOpenProjectModal: (p: ProjectItem) => void;
  onOpenProjectsBrowser?: () => void;
  onOpenSkillsModal: () => void;
  onOpenContactModal: (service?: string) => void;
  onOpenResumeModal: () => void;
  onDownloadPhpZip: () => void;
  isDownloadingZip: boolean;
}

export const CinematicHUD: React.FC<CinematicHUDProps> = ({
  scrollProgress,
  onSetScroll,
  profile,
  projects,
  skills,
  lang,
  onOpenProjectModal,
  onOpenProjectsBrowser,
  onOpenSkillsModal,
  onOpenContactModal,
  onOpenResumeModal,
  onDownloadPhpZip,
  isDownloadingZip
}) => {
  const isAr = lang === 'ar';
  const [isDismissed, setIsDismissed] = useState(false);

  // Determine current chapter (0: Hero, 1: About, 2: Projects, 3: Skills, 4: Contact)
  let activeChapter = 0;
  if (scrollProgress < 0.8) activeChapter = 0;
  else if (scrollProgress < 1.7) activeChapter = 1;
  else if (scrollProgress < 3.8) activeChapter = 2;
  else if (scrollProgress < 4.6) activeChapter = 3;
  else activeChapter = 4;

  const prevChapterRef = useRef(activeChapter);

  // Re-reveal HUD panel when navigating between major chapters
  useEffect(() => {
    if (prevChapterRef.current !== activeChapter) {
      prevChapterRef.current = activeChapter;
      setIsDismissed(false);
    }
  }, [activeChapter]);

  // Active project index when in projects zone (scrollProgress: 1.7 to 3.8)
  const projProgress = Math.max(0, Math.min(1, (scrollProgress - 1.7) / 2.1));
  const activeProjIdx = Math.min(projects.length - 1, Math.floor(projProgress * projects.length));
  const currentProject = projects[activeProjIdx] || projects[0];

  const chapters = [
    { id: 0, labelAr: 'الرؤية والقيادة', labelEn: 'Cyber Hero', target: 0.0 },
    { id: 1, labelAr: 'فلسفة المهندس', labelEn: 'Architecture', target: 1.2 },
    { id: 2, labelAr: `المشاريع والأنظمة (${projects.length})`, labelEn: `Projects (${projects.length})`, target: 2.2 },
    { id: 3, labelAr: 'ترسانة المهارات', labelEn: 'Tech Arsenal', target: 4.0 },
    { id: 4, labelAr: 'غرفة التعاقد', labelEn: 'Mission Control', target: 4.8 }
  ];

  // Movie-grade transition easing curve
  const cinematicTransition = {
    duration: 0.7,
    ease: [0.16, 1, 0.3, 1] as const
  };

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-6 sm:p-10 z-10 overflow-hidden">
      {/* Top spacing under header */}
      <div className="h-16" />

      {/* FLOATING RESTORE BUTTON WHEN PANEL IS CLOSED */}
      <AnimatePresence>
        {isDismissed && (
          <motion.button
            initial={{ opacity: 0, scale: 0.9, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 15 }}
            transition={{ duration: 0.3 }}
            onClick={() => {
              cyberAudio.playClickSound();
              setIsDismissed(false);
            }}
            className="pointer-events-auto fixed top-20 right-6 rtl:right-auto rtl:left-6 z-30 flex items-center gap-2 px-4 py-2.5 bg-[#06070a]/95 hover:bg-black border border-orange-500/60 hover:border-orange-400 text-orange-400 hover:text-white rounded-xl text-xs font-bold shadow-2xl backdrop-blur-md cursor-pointer transition-all hover:scale-105 active:scale-95"
            title={isAr ? 'إظهار لوحة الشرح والتفاصيل' : 'Show Information Panel'}
          >
            <Eye className="w-4 h-4 text-orange-400" />
            <span>{isAr ? 'عرض لوحة الشرح' : 'Show Panel'}</span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* CHAPTER INDICATOR DOCK (RIGHT SIDE) WITH CIRCULAR SVG PROGRESS RING */}
      <motion.div
        initial={{ opacity: 0, x: isAr ? -30 : 30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="fixed top-1/2 -translate-y-1/2 right-4 rtl:right-auto rtl:left-4 z-20 flex flex-col gap-2.5 pointer-events-auto bg-[#07080b]/90 p-2.5 rounded-2xl border border-orange-500/25 backdrop-blur-md shadow-2xl"
      >
        {chapters.map((ch) => {
          const isActive = activeChapter === ch.id;

          // Compute sub-progress within this chapter (0 to 1)
          let subProgress = 0;
          if (ch.id === 0) subProgress = Math.min(1, Math.max(0, scrollProgress / 0.8));
          else if (ch.id === 1) subProgress = Math.min(1, Math.max(0, (scrollProgress - 0.8) / 0.9));
          else if (ch.id === 2) subProgress = Math.min(1, Math.max(0, (scrollProgress - 1.7) / 2.1));
          else if (ch.id === 3) subProgress = Math.min(1, Math.max(0, (scrollProgress - 3.8) / 0.8));
          else if (ch.id === 4) subProgress = Math.min(1, Math.max(0, (scrollProgress - 4.6) / 0.4));

          const radius = 10;
          const circumference = 2 * Math.PI * radius; // ~62.83
          const strokeDashoffset = circumference - (circumference * (isActive ? Math.max(0.1, subProgress) : 0));

          return (
            <button
              key={ch.id}
              onClick={() => {
                cyberAudio.playWarpSound();
                setIsDismissed(false);
                onSetScroll(ch.target);
              }}
              title={isAr ? ch.labelAr : ch.labelEn}
              className={`group flex items-center gap-2.5 text-xs font-mono transition-all text-left rtl:text-right cursor-pointer py-1 px-1.5 rounded-xl ${
                isActive ? 'text-orange-400 font-bold bg-orange-950/40 border border-orange-500/30' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
              }`}
            >
              {/* Circular SVG Progress Ring indicator around active navigation button */}
              <div className="relative w-7 h-7 flex items-center justify-center shrink-0">
                <svg className="w-7 h-7 -rotate-90 transform" viewBox="0 0 28 28">
                  <circle
                    cx="14"
                    cy="14"
                    r={radius}
                    fill="none"
                    stroke="rgba(255, 255, 255, 0.12)"
                    strokeWidth="2"
                  />
                  {isActive && (
                    <circle
                      cx="14"
                      cy="14"
                      r={radius}
                      fill="none"
                      stroke="#f97316"
                      strokeWidth="2.5"
                      strokeDasharray={circumference}
                      strokeDashoffset={strokeDashoffset}
                      strokeLinecap="round"
                      className="transition-all duration-300"
                    />
                  )}
                </svg>
                <span className={`absolute text-[9px] font-mono font-bold ${isActive ? 'text-orange-400' : 'text-slate-500'}`}>
                  0{ch.id + 1}
                </span>
              </div>
              <span className="hidden lg:inline text-[11px] whitespace-nowrap">
                {isAr ? ch.labelAr : ch.labelEn}
              </span>
            </button>
          );
        })}
      </motion.div>

      {/* DYNAMIC STORY SECTION OVERLAYS WITH FRAMER-MOTION */}
      <div className="flex-1 flex items-center">
        <AnimatePresence mode="wait">
          {!isDismissed && (
            <>
              {/* PHASE 0: HERO INTRO & 3D COMMAND */}
              {activeChapter === 0 && (
                <motion.div
                  key="chapter-0"
                  initial={{ opacity: 0, scale: 0.95, y: 35, filter: 'blur(10px)' }}
                  animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
                  exit={{ opacity: 0, scale: 0.98, y: -25, filter: 'blur(8px)' }}
                  transition={cinematicTransition}
                  className="relative max-w-2xl pointer-events-auto bg-[#06070a]/90 border border-orange-500/30 rounded-2xl p-6 sm:p-8 shadow-2xl"
                >
                  {/* Close 'X' Button to exit overlay and explore 3D site */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      cyberAudio.playClickSound();
                      setIsDismissed(true);
                    }}
                    className="absolute top-4 left-4 rtl:left-4 rtl:right-auto ltr:right-4 ltr:left-auto p-2 text-slate-400 hover:text-white bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-orange-500 rounded-xl transition-all z-20 cursor-pointer shadow-lg hover:scale-105 active:scale-95"
                    title={isAr ? 'إغلاق الواجهة والتصفح بالموقع' : 'Dismiss overlay to browse 3D site'}
                    aria-label="Close"
                  >
                    <X className="w-4 h-4" />
                  </button>

                  <div className="flex items-center gap-2 text-xs font-semibold text-orange-400 mb-3 uppercase tracking-wider font-mono">
                    <span className="text-amber-400">01 //</span>
                    <span>{isAr ? 'عالم المهندس الرقمي ثلاثي الأبعاد' : '3D Digital World'}</span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="text-lime-400">{isAr ? 'نظم معلومات & أندرويد' : 'Systems & Android'}</span>
                  </div>

                  <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight mb-3 font-cyber">
                    {isAr ? profile.nameAr : profile.nameEn}
                  </h1>

                  <p className="text-sm sm:text-base font-bold text-orange-400 mb-2 font-cyber">
                    {isAr ? profile.titleAr : profile.titleEn}
                  </p>

                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
                    {isAr ? profile.subTitleAr : profile.subTitleEn}
                  </p>

                  {/* Unboxed Statistics Proof Row */}
                  <div className="flex flex-wrap items-center gap-5 text-xs font-semibold text-slate-400 mb-6 py-3 border-y border-slate-800/80">
                    <div>
                      <span className="text-lg font-extrabold text-white font-cyber">{profile.yearsExperience}+ </span>
                      <span>{isAr ? 'سنوات هندسة برمجية' : 'Years Experience'}</span>
                    </div>
                    <span aria-hidden="true" className="text-slate-700">|</span>
                    <div>
                      <span className="text-lg font-extrabold text-orange-400 font-cyber">{profile.completedProjects}+ </span>
                      <span>{isAr ? 'مشروعاً وتطبيقاً معتمداً' : 'Enterprise Systems'}</span>
                    </div>
                    <span aria-hidden="true" className="text-slate-700">|</span>
                    <div>
                      <span className="text-lg font-extrabold text-lime-400 font-cyber">100% </span>
                      <span>{isAr ? 'حماية وأمان معتمد' : 'Clean MVC Security'}</span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      onClick={() => {
                        cyberAudio.playWarpSound();
                        onSetScroll(2.0);
                      }}
                      className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-black bg-orange-500 hover:bg-orange-400 active:scale-95 rounded-lg transition-all shadow-md shadow-orange-500/25 whitespace-nowrap cursor-pointer"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>{isAr ? `استكشف المشاريع والأنظمة (${projects.length}+)` : `Explore All Systems (${projects.length}+)`}</span>
                    </button>

                    <button
                      onClick={() => {
                        cyberAudio.playClickSound();
                        onOpenContactModal();
                      }}
                      className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg transition-all whitespace-nowrap cursor-pointer"
                    >
                      <MessageCircle className="w-4 h-4 text-emerald-400" />
                      <span>{isAr ? 'تواصل مباشر (واتساب)' : 'Direct WhatsApp'}</span>
                    </button>

                    <button
                      onClick={() => {
                        cyberAudio.playClickSound();
                        onOpenResumeModal();
                      }}
                      className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-amber-300 hover:text-white bg-amber-950/40 hover:bg-amber-900/50 border border-amber-500/40 rounded-lg transition-all whitespace-nowrap cursor-pointer"
                    >
                      <FileText className="w-4 h-4" />
                      <span>{isAr ? 'السيرة الذاتية (CV)' : 'Download CV'}</span>
                    </button>
                  </div>
                </motion.div>
              )}

              {/* PHASE 1: THE MIND & IDENTITY (من أنا) */}
              {activeChapter === 1 && (
                <motion.div
                  key="chapter-1"
                  initial={{ opacity: 0, scale: 0.95, y: 35, filter: 'blur(10px)' }}
                  animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
                  exit={{ opacity: 0, scale: 0.98, y: -25, filter: 'blur(8px)' }}
                  transition={cinematicTransition}
                  className="relative max-w-2xl pointer-events-auto bg-[#06070a]/90 border border-orange-500/30 rounded-2xl p-6 sm:p-8 shadow-2xl"
                >
                  {/* Close 'X' Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      cyberAudio.playClickSound();
                      setIsDismissed(true);
                    }}
                    className="absolute top-4 left-4 rtl:left-4 rtl:right-auto ltr:right-4 ltr:left-auto p-2 text-slate-400 hover:text-white bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-orange-500 rounded-xl transition-all z-20 cursor-pointer shadow-lg hover:scale-105 active:scale-95"
                    title={isAr ? 'إغلاق الواجهة والتصفح بالموقع' : 'Dismiss overlay to browse 3D site'}
                    aria-label="Close"
                  >
                    <X className="w-4 h-4" />
                  </button>

                  <div className="flex items-center gap-2 text-xs font-semibold text-orange-400 mb-2 uppercase font-mono">
                    <span className="text-amber-400">02 //</span>
                    <span>{isAr ? 'فلسفة ومنهجية المهندس' : 'The Engineer Mindset & Blueprint'}</span>
                  </div>

                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-4 font-cyber">
                    {isAr ? 'أنا عبدالله عبدة شايف' : 'Abdullah Abdo Shaif'}
                  </h2>

                  <p className="text-sm leading-relaxed text-slate-200 mb-6 bg-orange-950/20 p-4 rounded-xl border border-orange-500/20">
                    {isAr ? profile.bioAr : profile.bioEn}
                  </p>

                  <div className="space-y-3 mb-6">
                    <div className="flex items-start gap-3 text-xs text-slate-300">
                      <ShieldCheck className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold text-white block">
                          {isAr ? 'هندسة معمارية صارمة (Architectural Discipline):' : 'Architectural Discipline:'}
                        </span>
                        <span>{isAr ? 'بناء أنظمة متكاملة بـ PHP 8.2 وMySQL خالية من العشوائية، تتبع معمارية MVC النظيفة وتتحمل ملايين الاستعلامات.' : 'Robust PHP 8.2 / MySQL enterprise backend architecture following strict MVC.'}</span>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 text-xs text-slate-300">
                      <Cpu className="w-4 h-4 text-lime-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold text-white block">
                          {isAr ? 'تطبيقات أندرويد حية ومرنة (Android Native & Resilient):' : 'Native Android Resiliency:'}
                        </span>
                        <span>{isAr ? 'برمجة تطبيقات بـ Kotlin تعمل بسلاسة فائقة، متوافقة مع الـ GPS، والعمل بلا إنترنت (Offline-First).' : 'Jetpack & Kotlin native mobile apps engineered for GPS dispatch and offline usage.'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => {
                        cyberAudio.playWarpSound();
                        onSetScroll(2.0);
                      }}
                      className="flex items-center gap-2 px-4 py-2 text-xs font-bold text-black bg-orange-500 hover:bg-orange-400 rounded-lg transition-all cursor-pointer"
                    >
                      <span>{isAr ? 'المتابعة نحو معرض المشاريع' : 'Next: Projects'}</span>
                      <ChevronLeft className="w-4 h-4 rtl:rotate-0 ltr:rotate-180" />
                    </button>
                  </div>
                </motion.div>
              )}

              {/* PHASE 2: PROJECTS SHOWCASE WITH ROTATIONAL SLIDE */}
              {activeChapter === 2 && currentProject && (
                <motion.div
                  key={`chapter-2-${currentProject.id}`}
                  initial={{ opacity: 0, x: isAr ? -40 : 40, scale: 0.96, filter: 'blur(8px)' }}
                  animate={{ opacity: 1, x: 0, scale: 1, filter: 'blur(0px)' }}
                  exit={{ opacity: 0, x: isAr ? 40 : -40, scale: 0.96, filter: 'blur(8px)' }}
                  transition={cinematicTransition}
                  className="relative max-w-2xl pointer-events-auto bg-[#06070a]/90 border border-orange-500/35 rounded-2xl p-6 sm:p-8 shadow-2xl"
                >
                  {/* Close 'X' Button to exit overlay and explore 3D site directly */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      cyberAudio.playClickSound();
                      setIsDismissed(true);
                    }}
                    className="absolute top-4 left-4 rtl:left-4 rtl:right-auto ltr:right-4 ltr:left-auto p-2 text-slate-400 hover:text-white bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-orange-500 rounded-xl transition-all z-20 cursor-pointer shadow-lg hover:scale-105 active:scale-95"
                    title={isAr ? 'إغلاق الواجهة والتصفح بالموقع' : 'Dismiss overlay to browse 3D site'}
                    aria-label="Close"
                  >
                    <X className="w-4 h-4" />
                  </button>

                  <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                    <div className="flex items-center gap-2 text-xs font-semibold text-orange-400 uppercase font-mono">
                      <span className="text-amber-400">03 //</span>
                      <span className="px-2 py-0.5 bg-orange-950/60 border border-orange-500/30 rounded text-orange-300 font-bold">
                        {isAr ? `مشروع ${activeProjIdx + 1} من ${projects.length}` : `Project ${activeProjIdx + 1} of ${projects.length}`}
                      </span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-lime-400 font-mono">[{currentProject.category.toUpperCase()}]</span>
                    </div>

                    {/* Quick Stepper ◀ Prev / Next ▶ */}
                    <div className="flex items-center gap-1.5 pointer-events-auto">
                      <button
                        onClick={() => {
                          cyberAudio.playClickSound();
                          const prevIdx = activeProjIdx > 0 ? activeProjIdx - 1 : projects.length - 1;
                          onSetScroll(1.7 + (prevIdx / Math.max(1, projects.length - 1)) * 2.1);
                        }}
                        className="px-2.5 py-1 text-xs font-bold text-orange-400 hover:text-white bg-slate-900/90 hover:bg-orange-600/40 border border-slate-700 hover:border-orange-500 rounded-lg transition-all cursor-pointer flex items-center gap-1"
                        title={isAr ? 'المشروع السابق' : 'Previous Project'}
                      >
                        <ChevronRight className="w-3.5 h-3.5 rtl:rotate-0 ltr:rotate-180" />
                        <span className="hidden sm:inline">{isAr ? 'السابق' : 'Prev'}</span>
                      </button>

                      <button
                        onClick={() => {
                          cyberAudio.playClickSound();
                          const nextIdx = activeProjIdx < projects.length - 1 ? activeProjIdx + 1 : 0;
                          onSetScroll(1.7 + (nextIdx / Math.max(1, projects.length - 1)) * 2.1);
                        }}
                        className="px-2.5 py-1 text-xs font-bold text-orange-400 hover:text-white bg-slate-900/90 hover:bg-orange-600/40 border border-slate-700 hover:border-orange-500 rounded-lg transition-all cursor-pointer flex items-center gap-1"
                        title={isAr ? 'المشروع التالي' : 'Next Project'}
                      >
                        <span className="hidden sm:inline">{isAr ? 'التالي' : 'Next'}</span>
                        <ChevronLeft className="w-3.5 h-3.5 rtl:rotate-0 ltr:rotate-180" />
                      </button>
                    </div>
                  </div>

                  {/* 40-Project Scrubber Bar / Quick Jump */}
                  <div className="w-full mb-3 flex items-center gap-1 overflow-x-auto pb-1.5 scrollbar-thin">
                    {projects.map((p, idx) => {
                      const isSelected = activeProjIdx === idx;
                      return (
                        <button
                          key={p.id}
                          onClick={() => {
                            cyberAudio.playClickSound();
                            onSetScroll(1.7 + (idx / Math.max(1, projects.length - 1)) * 2.1);
                          }}
                          className={`shrink-0 transition-all cursor-pointer rounded-full ${
                            isSelected 
                              ? 'w-6 h-2 bg-orange-500 shadow-sm shadow-orange-500' 
                              : 'w-2 h-2 bg-slate-700 hover:bg-orange-400/70'
                          }`}
                          title={`${idx + 1}. ${p.titleAr}`}
                        />
                      );
                    })}
                  </div>

                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-1 font-cyber">
                    {isAr ? currentProject.titleAr : currentProject.titleEn}
                  </h2>
                  <p className="text-xs sm:text-sm font-semibold text-orange-400 mb-4">
                    {isAr ? currentProject.taglineAr : currentProject.taglineEn}
                  </p>

                  <p className="text-xs sm:text-sm leading-relaxed text-slate-300 mb-4 line-clamp-3">
                    {isAr ? currentProject.descriptionAr : currentProject.descriptionEn}
                  </p>

                  {/* Tech badges */}
                  <div className="flex flex-wrap gap-1.5 mb-6">
                    {currentProject.technologies.map((t, idx) => (
                      <span
                        key={idx}
                        className="text-xs font-mono text-orange-300 bg-slate-950 px-2.5 py-1 rounded border border-slate-800"
                      >
                        {t}
                      </span>
                    ))}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      onClick={() => {
                        cyberAudio.playClickSound();
                        onOpenProjectModal(currentProject);
                      }}
                      className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-black bg-orange-500 hover:bg-orange-400 rounded-lg transition-all shadow-md shadow-orange-500/25 cursor-pointer"
                    >
                      <Layers className="w-4 h-4" />
                      <span>{isAr ? 'عرض المواصفات والمعمارية' : 'View Architecture'}</span>
                    </button>

                    {onOpenProjectsBrowser && (
                      <button
                        onClick={() => {
                          cyberAudio.playClickSound();
                          onOpenProjectsBrowser();
                        }}
                        className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-orange-300 hover:text-white bg-orange-950/40 hover:bg-orange-900/60 border border-orange-500/40 rounded-lg transition-all cursor-pointer"
                      >
                        <span>{isAr ? `تصفح كافة المشاريع (${projects.length})` : `Browse All (${projects.length})`}</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        cyberAudio.playClickSound();
                        onOpenContactModal(isAr ? currentProject.titleAr : currentProject.titleEn);
                      }}
                      className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-slate-200 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg transition-all cursor-pointer"
                    >
                      <Send className="w-4 h-4 text-orange-400" />
                      <span>{isAr ? 'طلب نظام مماثل' : 'Commission Similar'}</span>
                    </button>
                  </div>
                </motion.div>
              )}

              {/* PHASE 3: TECH ARSENAL */}
              {activeChapter === 3 && (
                <motion.div
                  key="chapter-3"
                  initial={{ opacity: 0, scale: 0.95, y: 35, filter: 'blur(10px)' }}
                  animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
                  exit={{ opacity: 0, scale: 0.98, y: -25, filter: 'blur(8px)' }}
                  transition={cinematicTransition}
                  className="relative max-w-2xl pointer-events-auto bg-[#06070a]/90 border border-orange-500/30 rounded-2xl p-6 sm:p-8 shadow-2xl"
                >
                  {/* Close 'X' Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      cyberAudio.playClickSound();
                      setIsDismissed(true);
                    }}
                    className="absolute top-4 left-4 rtl:left-4 rtl:right-auto ltr:right-4 ltr:left-auto p-2 text-slate-400 hover:text-white bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-orange-500 rounded-xl transition-all z-20 cursor-pointer shadow-lg hover:scale-105 active:scale-95"
                    title={isAr ? 'إغلاق الواجهة والتصفح بالموقع' : 'Dismiss overlay to browse 3D site'}
                    aria-label="Close"
                  >
                    <X className="w-4 h-4" />
                  </button>

                  <div className="flex items-center gap-2 text-xs font-semibold text-orange-400 mb-2 uppercase font-mono">
                    <span className="text-amber-400">04 //</span>
                    <span>{isAr ? 'ترسانة المهارات ولغات البرمجة' : 'Technical Matrix & Stack'}</span>
                  </div>

                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-3 font-cyber">
                    {isAr ? 'أدوات بناء الأنظمة المعقدة' : 'Production Engineering Stack'}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
                    {isAr
                      ? 'إتقان حقيقي للواجهات الخلفية، قواعد البيانات، وتطبيقات الهواتف الأصلية بأعلى مقاييس الأداء.'
                      : 'Real-world expertise across backend microservices, relational databases, and native mobile ecosystems.'}
                  </p>

                  {/* Quick Skills highlights grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mb-6">
                    {skills.slice(0, 6).map((s) => (
                      <div key={s.id} className="p-2.5 bg-slate-900/80 rounded-lg border border-slate-800 flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{s.name}</span>
                        <span className="text-xs font-mono font-bold text-orange-400">{s.level}%</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => {
                        cyberAudio.playClickSound();
                        onOpenSkillsModal();
                      }}
                      className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-black bg-orange-500 hover:bg-orange-400 rounded-lg transition-all shadow-md shadow-orange-500/25 cursor-pointer"
                    >
                      <Code2 className="w-4 h-4" />
                      <span>{isAr ? 'فتح المصفوفة الكاملة وفحص الكود' : 'Open Complete Matrix & Code'}</span>
                    </button>

                    <button
                      onClick={() => {
                        cyberAudio.playWarpSound();
                        onSetScroll(4.8);
                      }}
                      className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-900 border border-slate-700 rounded-lg transition-all cursor-pointer"
                    >
                      <span>{isAr ? 'غرفة التواصل والتعاقد' : 'Next: Contact'}</span>
                      <ChevronLeft className="w-4 h-4 rtl:rotate-0 ltr:rotate-180" />
                    </button>
                  </div>
                </motion.div>
              )}

              {/* PHASE 4: MISSION CONTROL & CONTACT */}
              {activeChapter === 4 && (
                <motion.div
                  key="chapter-4"
                  initial={{ opacity: 0, scale: 0.95, y: 35, filter: 'blur(10px)' }}
                  animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
                  exit={{ opacity: 0, scale: 0.98, y: -25, filter: 'blur(8px)' }}
                  transition={cinematicTransition}
                  className="relative max-w-2xl pointer-events-auto bg-[#06070a]/90 border border-orange-500/35 rounded-2xl p-6 sm:p-8 shadow-2xl"
                >
                  {/* Close 'X' Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      cyberAudio.playClickSound();
                      setIsDismissed(true);
                    }}
                    className="absolute top-4 left-4 rtl:left-4 rtl:right-auto ltr:right-4 ltr:left-auto p-2 text-slate-400 hover:text-white bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-orange-500 rounded-xl transition-all z-20 cursor-pointer shadow-lg hover:scale-105 active:scale-95"
                    title={isAr ? 'إغلاق الواجهة والتصفح بالموقع' : 'Dismiss overlay to browse 3D site'}
                    aria-label="Close"
                  >
                    <X className="w-4 h-4" />
                  </button>

                  <div className="flex items-center gap-2 text-xs font-semibold text-orange-400 mb-2 uppercase font-mono">
                    <span className="text-amber-400">05 //</span>
                    <span>{isAr ? 'غرفة القيادة والتواصل المباشر' : 'Mission Control & Direct Contact'}</span>
                  </div>

                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-2 font-cyber">
                    {isAr ? 'جاهز لتحويل فكرتك إلى مشروع رقمي جبار؟' : 'Ready to Build Something Extraordinary?'}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
                    {isAr
                      ? 'تواصل معي مباشرة لمناقشة متطلبات مشروعك، تصميم بنيتك التحتية، أو التعاقد على بناء تطبيقات الهاتف والويب.'
                      : 'Initiate a direct dispatch to engineer your next high-concurrency mobile application or enterprise web system.'}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
                    <a
                      href={`https://wa.me/${profile.whatsapp.replace(/[^0-9]/g, '')}?text=${encodeURIComponent('السلام عليكم يا مهندس عبدالله شايف، أود الاستفسار عن مشروع برمجي.')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 p-3 bg-emerald-950/40 hover:bg-emerald-950/60 border border-emerald-500/40 rounded-xl transition-all"
                    >
                      <div className="p-2 bg-emerald-500 text-black rounded-lg">
                        <MessageCircle className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-white block">{isAr ? 'محادثة واتساب فورية' : 'Instant WhatsApp'}</span>
                        <span className="text-[11px] text-emerald-400 font-mono" dir="ltr">{profile.whatsapp}</span>
                      </div>
                    </a>

                    <a
                      href={`mailto:${profile.email}`}
                      className="flex items-center gap-3 p-3 bg-slate-900/60 hover:bg-slate-900 border border-slate-800 rounded-xl transition-all"
                    >
                      <div className="p-2 bg-orange-950 text-orange-400 border border-orange-500/30 rounded-lg">
                        <Send className="w-4 h-4" />
                      </div>
                      <div className="overflow-hidden">
                        <span className="text-xs font-bold text-white block">{isAr ? 'البريد الإلكتروني' : 'Email Dispatch'}</span>
                        <span className="text-[11px] text-slate-300 font-mono truncate block">{profile.email}</span>
                      </div>
                    </a>
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      onClick={() => {
                        cyberAudio.playClickSound();
                        onOpenContactModal();
                      }}
                      className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-black bg-orange-500 hover:bg-orange-400 rounded-lg transition-all shadow-md shadow-orange-500/25 cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                      <span>{isAr ? 'إرسال رسالة مشفرة من الموقع' : 'Send Encrypted Message'}</span>
                    </button>

                    <button
                      onClick={onDownloadPhpZip}
                      disabled={isDownloadingZip}
                      className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 rounded-lg transition-all shadow-md shadow-amber-500/20 cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>{isDownloadingZip ? (isAr ? 'جاري التحزيم...' : 'Packaging...') : (isAr ? 'تحميل حزمة PHP & MySQL' : 'Download PHP Package')}</span>
                    </button>
                  </div>
                </motion.div>
              )}
            </>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom Drag & Scroll Navigation Guide */}
      <div className="flex items-center justify-between text-xs text-slate-400 select-none pb-16 sm:pb-8">
        <div className="flex items-center gap-2">
          <ArrowDown className="w-4 h-4 text-orange-400 animate-bounce" />
          <span>
            {isAr
              ? 'اسحب بالفأرة أو استخدم عجلة التمرير (Scroll / Drag) للتجول عبر عالم المشاريع والمهارات'
              : 'Scroll or drag anywhere to travel through the 3D stations & projects'}
          </span>
        </div>

        {/* Scroll Progress percentage */}
        <div className="hidden sm:flex items-center gap-2 font-mono text-orange-400">
          <span>PROGRESS //</span>
          <span>{Math.round((scrollProgress / 5) * 100)}%</span>
        </div>
      </div>
    </div>
  );
};
