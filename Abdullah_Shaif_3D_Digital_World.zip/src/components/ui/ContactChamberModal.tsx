import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mail, Phone, MapPin, Send, MessageCircle, Github, Linkedin, CheckCircle2, AlertCircle } from 'lucide-react';
import { ProfileInfo, ServiceItem } from '../../types/portfolio';
import { cyberAudio } from '../../utils/audio';
import { ModalCloseButton } from './ModalCloseButton';

interface ContactChamberModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: ProfileInfo;
  services: ServiceItem[];
  lang: 'ar' | 'en';
  prefilledInterest?: string;
}

export const ContactChamberModal: React.FC<ContactChamberModalProps> = ({
  isOpen,
  onClose,
  profile,
  services,
  lang,
  prefilledInterest
}) => {
  const isAr = lang === 'ar';
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [serviceInterest, setServiceInterest] = useState(prefilledInterest || '');
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !message) {
      setStatus('error');
      setErrorMessage(isAr ? 'يرجى إكمال جميع الحقول المطلوبة' : 'Please fill all required fields');
      return;
    }

    setStatus('submitting');
    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          email,
          phone,
          serviceInterest: serviceInterest || (isAr ? 'استشارة عامة' : 'General Inquiry'),
          message
        })
      });

      if (res.ok) {
        setStatus('success');
        cyberAudio.playSuccessSound();
        setName('');
        setEmail('');
        setPhone('');
        setMessage('');
      } else {
        const data = await res.json();
        setStatus('error');
        setErrorMessage(data.error || (isAr ? 'حدث خطأ أثناء الإرسال' : 'Failed to send message'));
      }
    } catch {
      setStatus('error');
      setErrorMessage(isAr ? 'تعذر الاتصال بالخادم' : 'Server connection failed');
    }
  };

  const whatsappMessage = encodeURIComponent(
    isAr
      ? `مرحباً يا مهندس عبدالله شايف، أود الاستفسار والتنسيق معك بخصوص مشروع برمجي: ${serviceInterest || ''}`
      : `Hello Eng. Abdullah Shaif, I would like to consult with you regarding a software project: ${serviceInterest || ''}`
  );
  const whatsappUrl = `https://wa.me/${profile.whatsapp.replace(/[^0-9]/g, '')}?text=${whatsappMessage}`;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-xs"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 25 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -15 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto bg-[#08090d] border border-orange-500/30 rounded-2xl p-6 md:p-8 shadow-2xl text-slate-100"
          >
            {/* Global Animated Close Button */}
            <ModalCloseButton onClose={onClose} />

            {/* Header */}
            <div className="flex items-center gap-2 text-xs font-semibold text-orange-400 mb-2 uppercase">
              <span>{isAr ? 'غرفة التواصل والاتصال المباشر' : 'Cyber Communications Hub'}</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>{isAr ? 'المهندس عبدالله شايف' : 'Direct Line'}</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-2 font-cyber">
              {isAr ? 'تواصل مع المهندس عبدالله' : 'Connect with Eng. Abdullah'}
            </h2>
            <p className="text-sm text-slate-300 mb-8">
              {isAr
                ? 'متاح للمناقشات البرمجية، بناء الأنظمة المخصصة، وتطبيقات الهواتف والويب الذكية.'
                : 'Available for enterprise architecture consultations, bespoke mobile & web software solutions.'}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
              {/* Contact Details Column */}
              <div className="md:col-span-5 space-y-4">
                {/* WhatsApp direct card */}
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3.5 p-4 bg-emerald-950/40 hover:bg-emerald-950/60 border border-emerald-500/40 hover:border-emerald-400 rounded-xl transition-all group shadow-sm"
                >
                  <div className="p-2.5 bg-emerald-500 text-black rounded-lg group-hover:scale-105 transition-transform">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-emerald-400 font-semibold block">
                      {isAr ? 'واتساب مباشر (WhatsApp)' : 'Direct WhatsApp'}
                    </span>
                    <span className="text-sm font-bold text-white font-mono dir-ltr block text-left">
                      {profile.whatsapp}
                    </span>
                  </div>
                </a>

                {/* Email */}
                <a
                  href={`mailto:${profile.email}`}
                  className="flex items-center gap-3.5 p-4 bg-black/60 hover:bg-black/90 border border-slate-800 hover:border-orange-500/50 rounded-xl transition-all group"
                >
                  <div className="p-2.5 bg-orange-950/60 text-orange-400 rounded-lg group-hover:scale-105 transition-transform border border-orange-500/40">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div className="overflow-hidden">
                    <span className="text-xs text-slate-400 font-medium block">
                      {isAr ? 'البريد الإلكتروني المهني' : 'Email Address'}
                    </span>
                    <span className="text-xs sm:text-sm font-semibold text-white font-mono truncate block">
                      {profile.email}
                    </span>
                  </div>
                </a>

                {/* Location */}
                <div className="flex items-center gap-3.5 p-4 bg-black/60 border border-slate-800 rounded-xl">
                  <div className="p-2.5 bg-lime-950/50 text-lime-400 rounded-lg border border-lime-500/30">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 font-medium block">
                      {isAr ? 'الموقع الجغرافي ونطاق العمل' : 'Location & Coverage'}
                    </span>
                    <span className="text-xs sm:text-sm font-semibold text-white block">
                      {isAr ? profile.locationAr : profile.locationEn}
                    </span>
                  </div>
                </div>

                {/* Social Links */}
                <div className="flex items-center gap-2 pt-2">
                  <a
                    href={profile.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 bg-black/80 hover:bg-slate-900 border border-slate-800 hover:border-orange-500/40 rounded-lg text-xs font-semibold text-slate-300 hover:text-white transition-colors"
                  >
                    <Github className="w-4 h-4 text-orange-400" />
                    <span>GitHub</span>
                  </a>

                  <a
                    href={profile.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 bg-black/80 hover:bg-slate-900 border border-slate-800 hover:border-orange-500/40 rounded-lg text-xs font-semibold text-slate-300 hover:text-white transition-colors"
                  >
                    <Linkedin className="w-4 h-4 text-sky-400" />
                    <span>LinkedIn</span>
                  </a>

                  <a
                    href={profile.telegram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 bg-black/80 hover:bg-slate-900 border border-slate-800 hover:border-orange-500/40 rounded-lg text-xs font-semibold text-slate-300 hover:text-white transition-colors"
                  >
                    <Send className="w-4 h-4 text-orange-400" />
                    <span>Telegram</span>
                  </a>
                </div>
              </div>

              {/* Interactive Form Column */}
              <div className="md:col-span-7 bg-black/60 p-6 rounded-xl border border-slate-800/80">
                <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                  <Send className="w-4 h-4 text-orange-400" />
                  <span>{isAr ? 'إرسال رسالة مباشرة للمهندس' : 'Send an Encrypted Dispatch'}</span>
                </h3>

                {status === 'success' ? (
                  <div className="p-6 bg-emerald-950/40 border border-emerald-500/40 rounded-xl text-center space-y-3">
                    <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                    <h4 className="text-base font-bold text-white">
                      {isAr ? 'تم إرسال رسالتك بنجاح!' : 'Message Transmitted Successfully!'}
                    </h4>
                    <p className="text-xs text-slate-300">
                      {isAr
                        ? 'شكراً لتواصلك. سيقوم المهندس عبدالله بمراجعة رسالتك والرد عليك عبر البريد أو الواتساب في أقرب وقت.'
                        : 'Thank you for reaching out. Eng. Abdullah will review your inquiry and follow up shortly.'}
                    </p>
                    <button
                      onClick={() => setStatus('idle')}
                      className="px-4 py-2 text-xs font-semibold text-emerald-300 bg-emerald-900/40 rounded-lg hover:bg-emerald-900/60 transition-colors mt-2"
                    >
                      {isAr ? 'إرسال رسالة أخرى' : 'Send Another'}
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    {status === 'error' && (
                      <div className="p-3 bg-red-950/40 border border-red-500/40 rounded-lg text-xs text-red-300 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <span>{errorMessage}</span>
                      </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1">
                          {isAr ? 'الاسم الكريم *' : 'Your Name *'}
                        </label>
                        <input
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder={isAr ? 'مثال: محمد العمري' : 'e.g. John Doe'}
                          className="w-full px-3.5 py-2 text-xs text-white bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-lg outline-none transition-colors"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1">
                          {isAr ? 'البريد الإلكتروني *' : 'Email Address *'}
                        </label>
                        <input
                          type="email"
                          required
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="name@domain.com"
                          className="w-full px-3.5 py-2 text-xs text-white bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-lg outline-none transition-colors font-mono"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1">
                          {isAr ? 'رقم الهاتف / الواتساب' : 'Phone / WhatsApp'}
                        </label>
                        <input
                          type="text"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="+967 ..."
                          className="w-full px-3.5 py-2 text-xs text-white bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-lg outline-none transition-colors font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1">
                          {isAr ? 'الخدمة أو المشروع المطلوب' : 'Service or Project'}
                        </label>
                        <select
                          value={serviceInterest}
                          onChange={(e) => setServiceInterest(e.target.value)}
                          className="w-full px-3.5 py-2 text-xs text-white bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-lg outline-none transition-colors"
                        >
                          <option value="">{isAr ? '-- اختر نوع الخدمة --' : '-- Select Service --'}</option>
                          {services.map((s) => (
                            <option key={s.id} value={isAr ? s.titleAr : s.titleEn}>
                              {isAr ? s.titleAr : s.titleEn}
                            </option>
                          ))}
                          <option value="Custom Project">{isAr ? 'مشروع برمجي خاص' : 'Custom Project'}</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-400 mb-1">
                        {isAr ? 'تفاصيل الرسالة أو المشروع *' : 'Message or Project Scope *'}
                      </label>
                      <textarea
                        required
                        rows={4}
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder={
                          isAr
                            ? 'اكتب نبذة مختصرة عن متطلبات النظام أو الفكرة البرمجية التي تود تنفيذها...'
                            : 'Describe your system requirements, timeline, or technical inquiry...'
                        }
                        className="w-full px-3.5 py-2 text-xs text-white bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-lg outline-none transition-colors resize-none"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={status === 'submitting'}
                      className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs font-bold text-black bg-orange-500 hover:bg-orange-400 disabled:opacity-50 rounded-lg transition-all shadow-md shadow-orange-500/20 cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                      <span>
                        {status === 'submitting'
                          ? isAr
                            ? 'جاري إرسال الرسالة...'
                            : 'Transmitting...'
                          : isAr
                          ? 'إرسال الرسالة الآن'
                          : 'Transmit Dispatch'}
                      </span>
                    </button>
                  </form>
                )}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
