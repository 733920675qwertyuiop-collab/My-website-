import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Download, Sliders, Music, Eye } from 'lucide-react';
import { SceneStation } from '../../types/portfolio';
import { cyberAudio } from '../../utils/audio';

interface ControlDockProps {
  currentStation: SceneStation;
  onNavigate: (station: SceneStation) => void;
  lang: 'ar' | 'en';
  highQuality: boolean;
  onToggleQuality: () => void;
  onDownloadPhpZip: () => void;
  isDownloadingZip: boolean;
  onOpenStationModal: () => void;
}

export const ControlDock: React.FC<ControlDockProps> = ({
  currentStation,
  onNavigate,
  lang,
  highQuality,
  onToggleQuality,
  onDownloadPhpZip,
  isDownloadingZip,
  onOpenStationModal
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isAmbientOn, setIsAmbientOn] = useState(false);
  const isAr = lang === 'ar';

  const stations: { id: SceneStation; labelAr: string; labelEn: string }[] = [
    { id: 'home', labelAr: 'مكتب المهندس', labelEn: 'Cyber Office' },
    { id: 'about', labelAr: 'من أنا', labelEn: 'Identity Core' },
    { id: 'skills', labelAr: 'مصفوفة المهارات', labelEn: 'Skills Matrix' },
    { id: 'projects', labelAr: 'معرض المشاريع', labelEn: 'Projects Hub' },
    { id: 'services', labelAr: 'محطة الخدمات', labelEn: 'Services Lab' },
    { id: 'contact', labelAr: 'غرفة التواصل', labelEn: 'Comms Beacon' }
  ];

  const handleToggleAmbient = () => {
    const newState = cyberAudio.toggleAmbient();
    setIsAmbientOn(newState);
  };

  return (
    <div
      className={`fixed bottom-4 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center transition-transform duration-300 pointer-events-auto ${
        isCollapsed ? 'translate-y-[calc(100%-36px)]' : 'translate-y-0'
      }`}
      style={{ maxWidth: 'min(980px, 95vw)' }}
    >
      {/* Collapse / Expand Tab Button */}
      <button
        onClick={() => {
          cyberAudio.playClickSound();
          setIsCollapsed(!isCollapsed);
        }}
        className="flex items-center gap-2 px-3.5 py-1 text-xs font-semibold text-slate-300 hover:text-white bg-[#0e1015] border border-orange-500/25 border-b-0 rounded-t-lg shadow-md transition-colors cursor-pointer"
      >
        {isCollapsed ? (
          <>
            <ChevronUp className="w-3.5 h-3.5 text-orange-400" />
            <span>{isAr ? '▴ إظهار لوحة التحكم 3D' : '▴ Show 3D Controls'}</span>
          </>
        ) : (
          <>
            <ChevronDown className="w-3.5 h-3.5 text-orange-400" />
            <span>{isAr ? '▾ وضع السينما الكامل (إخفاء)' : '▾ Cinema Mode (Hide)'}</span>
          </>
        )}
      </button>

      {/* Main Glassmorphic Dock Container */}
      <div className="w-full bg-[#08090d]/95 border border-orange-500/25 rounded-xl p-2.5 shadow-2xl flex flex-wrap items-center justify-between gap-3 text-slate-200">
        {/* Navigation Stations Segmented Control */}
        <div className="flex items-center gap-1 overflow-x-auto py-0.5 max-w-full">
          {stations.map((st) => {
            const isActive = currentStation === st.id;
            return (
              <button
                key={st.id}
                onClick={() => {
                  cyberAudio.playWarpSound();
                  onNavigate(st.id);
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive
                    ? 'bg-orange-500/25 text-orange-300 border border-orange-500/50 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                {isAr ? st.labelAr : st.labelEn}
              </button>
            );
          })}
        </div>

        {/* Action & Quality Controls */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Detail inspection for current station */}
          {currentStation !== 'home' && (
            <button
              onClick={() => {
                cyberAudio.playClickSound();
                onOpenStationModal();
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-orange-400 hover:text-orange-300 bg-orange-950/40 border border-orange-500/30 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>{isAr ? 'تفاصيل القسم' : 'Inspect'}</span>
            </button>
          )}

          {/* Ambient Cyber Drone Toggle */}
          <button
            onClick={handleToggleAmbient}
            title={isAmbientOn ? 'إيقاف النغمة المحيطية' : 'تشغيل النغمة السحابية'}
            className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 transition-colors cursor-pointer ${
              isAmbientOn
                ? 'border-orange-400 text-orange-400 bg-orange-950/40'
                : 'border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Music className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isAr ? 'مؤثرات' : 'Ambience'}</span>
          </button>

          {/* Quality Toggle */}
          <button
            onClick={() => {
              cyberAudio.playClickSound();
              onToggleQuality();
            }}
            title={highQuality ? 'وضع الأداء الفائق (60 FPS)' : 'وضع التوفير الخفيف'}
            className="flex items-center gap-1 px-2 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-900 border border-slate-700/60 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
          >
            <Sliders className="w-3.5 h-3.5 text-amber-400" />
            <span>{highQuality ? '60 FPS' : 'Lite'}</span>
          </button>

          {/* Direct PHP + MySQL Package Download Button */}
          <button
            onClick={onDownloadPhpZip}
            disabled={isDownloadingZip}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-black bg-orange-500 hover:bg-orange-400 active:scale-95 disabled:opacity-50 rounded-lg transition-all whitespace-nowrap shadow-sm shadow-orange-500/25 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>
              {isDownloadingZip
                ? isAr
                  ? 'جاري الضغط...'
                  : 'Bundling...'
                : isAr
                ? 'تحميل حزمة PHP + MySQL'
                : 'Export PHP Package'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
