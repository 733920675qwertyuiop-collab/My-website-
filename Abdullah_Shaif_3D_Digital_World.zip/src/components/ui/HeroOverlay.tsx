import React from 'react';
import { Compass, Sparkles, Send, FileText, MousePointer } from 'lucide-react';
import { ProfileInfo, SceneStation } from '../../types/portfolio';
import { cyberAudio } from '../../utils/audio';

interface HeroOverlayProps {
  profile: ProfileInfo;
  lang: 'ar' | 'en';
  onNavigate: (station: SceneStation) => void;
  onOpenResume: () => void;
  onOpenContact: () => void;
}

export const HeroOverlay: React.FC<HeroOverlayProps> = ({
  profile,
  lang,
  onNavigate,
  onOpenResume,
  onOpenContact
}) => {
  const isAr = lang === 'ar';

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-6 md:p-12 z-10">
      {/* Top spacing under header */}
      <div className="h-16" />

      {/* Hero Typography & CTA Block */}
      <div className="max-w-2xl pointer-events-auto bg-[#08090d]/85 border border-orange-500/20 rounded-2xl p-6 md:p-8 shadow-2xl">
        {/* Unboxed Metadata Header Line (Zero-Pill Discipline) */}
        <div className="flex items-center gap-2 text-xs font-medium text-orange-400 mb-3">
          <span>{isAr ? 'عالم برمجيات 3D متقدم' : 'Advanced 3D Cyber Architecture'}</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>{isAr ? 'مهندس معتمد' : 'Verified Software Engineer'}</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>{isAr ? 'اليمن & العمل عن بعد' : 'Yemen & Global Remote'}</span>
        </div>

        {/* Primary Name Headline */}
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight leading-tight mb-3 font-cyber">
          {isAr ? profile.nameAr : profile.nameEn}
        </h1>

        {/* Specialization Subtitle */}
        <p className="text-sm md:text-base font-semibold text-orange-300 mb-2">
          {isAr ? profile.titleAr : profile.titleEn}
        </p>

        {/* Inspiring Slogan */}
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
          {isAr ? profile.subTitleAr : profile.subTitleEn}
        </p>

        {/* Unboxed Statistics Proof Row */}
        <div className="flex flex-wrap items-center gap-4 text-xs font-medium text-slate-400 mb-6 py-2.5 border-y border-slate-800">
          <div>
            <span className="text-base font-bold text-white font-cyber">{profile.yearsExperience}+ </span>
            <span>{isAr ? 'سنوات خبرة برمجية' : 'Years Experience'}</span>
          </div>
          <span aria-hidden="true" className="text-slate-700">|</span>
          <div>
            <span className="text-base font-bold text-orange-400 font-cyber">{profile.completedProjects}+ </span>
            <span>{isAr ? 'مشروعاً وتطبيقاً' : 'Completed Projects'}</span>
          </div>
          <span aria-hidden="true" className="text-slate-700">|</span>
          <div>
            <span className="text-base font-bold text-lime-400 font-cyber">{profile.satisfiedClients}+ </span>
            <span>{isAr ? 'عميلاً ومؤسسة' : 'Enterprise Clients'}</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => {
              cyberAudio.playWarpSound();
              onNavigate('projects');
            }}
            className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-black bg-orange-500 hover:bg-orange-400 active:scale-95 rounded-lg transition-all shadow-md shadow-orange-500/20 whitespace-nowrap cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>{isAr ? 'استكشف مشاريعي' : 'Explore Projects'}</span>
          </button>

          <button
            onClick={() => {
              cyberAudio.playWarpSound();
              onNavigate('skills');
            }}
            className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-slate-200 hover:text-white bg-slate-900/90 hover:bg-slate-800 border border-slate-700 rounded-lg transition-all whitespace-nowrap cursor-pointer"
          >
            <Compass className="w-4 h-4 text-orange-400" />
            <span>{isAr ? 'مصفوفة المهارات' : 'Tech Arsenal'}</span>
          </button>

          <button
            onClick={() => {
              cyberAudio.playClickSound();
              onOpenContact();
            }}
            className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-slate-200 hover:text-white bg-slate-900/90 hover:bg-slate-800 border border-slate-700 rounded-lg transition-all whitespace-nowrap cursor-pointer"
          >
            <Send className="w-4 h-4 text-orange-400" />
            <span>{isAr ? 'تواصل معي' : 'Contact Me'}</span>
          </button>

          <button
            onClick={() => {
              cyberAudio.playClickSound();
              onOpenResume();
            }}
            className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-lime-300 hover:text-white bg-lime-950/40 hover:bg-lime-900/50 border border-lime-500/40 rounded-lg transition-all whitespace-nowrap cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            <span>{isAr ? 'السيرة الذاتية (CV)' : 'Download CV'}</span>
          </button>
        </div>
      </div>

      {/* Subtle Bottom Interaction Hint */}
      <div className="flex items-center gap-2 text-xs text-slate-400 select-none pb-14 sm:pb-8">
        <MousePointer className="w-4 h-4 text-orange-400 animate-bounce" />
        <span>
          {isAr
            ? 'اسحب بالفأرة للتجول الحر 360° داخل المكتب، وانقر على الشاشات والمجسمات للاستكشاف'
            : 'Click and drag mouse to orbit 360° around the cyber office. Click on monitors and 3D nodes to inspect.'}
        </span>
      </div>
    </div>
  );
};
