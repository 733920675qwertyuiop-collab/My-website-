import React from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';
import { cyberAudio } from '../../utils/audio';

interface ModalCloseButtonProps {
  onClose: () => void;
  className?: string;
  title?: string;
}

export const ModalCloseButton: React.FC<ModalCloseButtonProps> = ({
  onClose,
  className = 'absolute top-4 right-4 rtl:right-auto rtl:left-4',
  title = 'إغلاق (Close)'
}) => {
  return (
    <motion.button
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      exit={{ scale: 0.8, opacity: 0 }}
      whileHover={{ scale: 1.1, rotate: 90 }}
      whileTap={{ scale: 0.9 }}
      transition={{ duration: 0.2 }}
      onClick={(e) => {
        e.stopPropagation();
        cyberAudio.playClickSound();
        onClose();
      }}
      className={`p-2.5 text-slate-300 hover:text-white bg-slate-900/90 hover:bg-orange-600/30 border border-slate-700/80 hover:border-orange-500 rounded-xl transition-colors z-30 cursor-pointer shadow-xl backdrop-blur-md flex items-center justify-center ${className}`}
      title={title}
      aria-label="Close"
    >
      <X className="w-5 h-5 text-orange-400 group-hover:text-white" />
    </motion.button>
  );
};
