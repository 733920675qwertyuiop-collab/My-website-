import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, Layers, Cpu, MessageSquare } from 'lucide-react';
import { ProjectItem } from '../../types/portfolio';
import { cyberAudio } from '../../utils/audio';
import { ModalCloseButton } from './ModalCloseButton';

interface ProjectDetailModalProps {
  project: ProjectItem | null;
  onClose: () => void;
  lang: 'ar' | 'en';
  onOrderSimilar: (projectName: string) => void;
}

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({
  project,
  onClose,
  lang,
  onOrderSimilar
}) => {
  const isAr = lang === 'ar';

  return (
    <AnimatePresence>
      {project && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-xs"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 25 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -15 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto bg-[#08090d] border border-orange-500/30 rounded-2xl p-6 md:p-8 shadow-2xl text-slate-100"
          >
            {/* Global Animated Close Button */}
            <ModalCloseButton onClose={onClose} />

            {/* Header Metadata */}
            <div className="flex items-center gap-2 text-xs font-semibold text-orange-400 mb-2 uppercase">
              <span>{isAr ? 'تفاصيل المشروع الهندسي' : 'Project Architecture Dossier'}</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>{project.category}</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-2 font-cyber">
              {isAr ? project.titleAr : project.titleEn}
            </h2>
            <p className="text-sm font-medium text-orange-300 mb-6">
              {isAr ? project.taglineAr : project.taglineEn}
            </p>

            {/* Media Preview Showcase */}
            <div className="relative w-full aspect-16/9 rounded-xl overflow-hidden border border-orange-500/25 mb-6 bg-black shadow-lg">
              <img
                src={project.imageUrl}
                alt={isAr ? project.titleAr : project.titleEn}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Technologies Row (Unboxed metadata style) */}
            <div className="flex flex-wrap items-center gap-2 mb-6">
              <span className="text-xs text-slate-400 font-semibold">{isAr ? 'التقنيات المستخدمة:' : 'Tech Stack:'}</span>
              {project.technologies.map((t, idx) => (
                <span
                  key={idx}
                  className="text-xs font-mono text-orange-300 bg-black px-2.5 py-1 rounded-md border border-slate-800"
                >
                  {t}
                </span>
              ))}
            </div>

            {/* Description */}
            <div className="mb-6 bg-black/60 p-5 rounded-xl border border-slate-800 text-sm leading-relaxed text-slate-200">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                {isAr ? 'الوصف الهندسي للمشروع:' : 'Executive Engineering Summary:'}
              </h3>
              <p>{isAr ? project.descriptionAr : project.descriptionEn}</p>
            </div>

            {/* Key Features & Architecture Split */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {/* Features */}
              <div className="bg-black/60 p-5 rounded-xl border border-slate-800">
                <h3 className="text-xs font-bold uppercase tracking-wider text-orange-400 mb-3 flex items-center gap-2">
                  <Layers className="w-4 h-4" />
                  <span>{isAr ? 'المميزات والخصائص البرمجية:' : 'Core Architectural Features:'}</span>
                </h3>
                <ul className="space-y-2.5">
                  {(isAr ? project.featuresAr : project.featuresEn).map((feat, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-orange-400 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Architecture Details */}
              <div className="bg-black/60 p-5 rounded-xl border border-slate-800">
                <h3 className="text-xs font-bold uppercase tracking-wider text-lime-400 mb-3 flex items-center gap-2">
                  <Cpu className="w-4 h-4" />
                  <span>{isAr ? 'معمارية النظام وقواعد البيانات:' : 'Backend & Data Flow Architecture:'}</span>
                </h3>
                <p className="text-xs leading-relaxed text-slate-300">
                  {isAr ? project.architectureDetailsAr : project.architectureDetailsEn}
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-800">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    cyberAudio.playClickSound();
                    onOrderSimilar(isAr ? project.titleAr : project.titleEn);
                  }}
                  className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-black bg-orange-500 hover:bg-orange-400 rounded-lg transition-all shadow-md shadow-orange-500/20 cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>{isAr ? 'طلب تنفيذ نظام مماثل' : 'Commission Similar Solution'}</span>
                </button>
              </div>

              <button
                onClick={() => {
                  cyberAudio.playClickSound();
                  onClose();
                }}
                className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-900 border border-slate-800 rounded-lg transition-colors cursor-pointer"
              >
                {isAr ? 'إغلاق المعاينة' : 'Dismiss'}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
