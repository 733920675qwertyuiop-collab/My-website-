import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Eye, Search } from 'lucide-react';
import { ProjectItem } from '../../types/portfolio';
import { cyberAudio } from '../../utils/audio';
import { ModalCloseButton } from './ModalCloseButton';

interface ProjectsBrowserModalProps {
  isOpen: boolean;
  onClose: () => void;
  projects: ProjectItem[];
  lang: 'ar' | 'en';
  onSelectProject: (p: ProjectItem) => void;
}

export const ProjectsBrowserModal: React.FC<ProjectsBrowserModalProps> = ({
  isOpen,
  onClose,
  projects,
  lang,
  onSelectProject
}) => {
  const [filter, setFilter] = useState<'all' | 'mobile' | 'web' | 'system' | 'ai'>('all');
  const [search, setSearch] = useState('');
  const isAr = lang === 'ar';

  const filtered = projects.filter((p) => {
    const matchesCategory = filter === 'all' || p.category === filter;
    const term = search.toLowerCase().trim();
    if (!term) return matchesCategory;
    return (
      matchesCategory &&
      (p.titleAr.toLowerCase().includes(term) ||
        p.titleEn.toLowerCase().includes(term) ||
        p.descriptionAr.toLowerCase().includes(term) ||
        p.descriptionEn.toLowerCase().includes(term) ||
        p.technologies.some((t) => t.toLowerCase().includes(term)))
    );
  });

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-xs"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 25 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -15 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-6xl max-h-[92vh] overflow-y-auto bg-[#08090d] border border-orange-500/30 rounded-2xl p-6 md:p-8 shadow-2xl text-slate-100"
          >
            {/* Global Animated Close Button */}
            <ModalCloseButton onClose={onClose} />

            {/* Header */}
            <div className="flex items-center gap-2 text-xs font-semibold text-orange-400 mb-2 uppercase">
              <span>{isAr ? 'معرض المشاريع والأنظمة المنفذة' : 'Engineering Projects Gallery'}</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>{projects.length} {isAr ? 'مشروعاً ونظاماً متكاملاً' : 'Full-Scale Deployments'}</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-4 font-cyber">
              {isAr ? 'المشاريع والمنصات الرقمية' : 'Software Deployments & Platforms'}
            </h2>

            {/* Interactive Filter Tabs and Search Bar */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-8">
              <div className="flex items-center gap-1.5 p-1 bg-black/70 border border-slate-800 rounded-xl overflow-x-auto">
                <button
                  onClick={() => setFilter('all')}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                    filter === 'all' ? 'bg-orange-500 text-black shadow-sm font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {isAr ? `الكل (${projects.length})` : `All (${projects.length})`}
                </button>
                <button
                  onClick={() => setFilter('system')}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                    filter === 'system' ? 'bg-orange-500 text-black shadow-sm font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {isAr ? 'أنظمة C# و.NET وجافا' : '.NET & Java Systems'}
                </button>
                <button
                  onClick={() => setFilter('web')}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                    filter === 'web' ? 'bg-orange-500 text-black shadow-sm font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {isAr ? 'منصات الويب ومواقع' : 'Web Platforms'}
                </button>
                <button
                  onClick={() => setFilter('mobile')}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                    filter === 'mobile' ? 'bg-orange-500 text-black shadow-sm font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {isAr ? 'تطبيقات الهاتف أندرويد' : 'Mobile Apps'}
                </button>
                <button
                  onClick={() => setFilter('ai')}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                    filter === 'ai' ? 'bg-orange-500 text-black shadow-sm font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {isAr ? 'ذكاء اصطناعي وIoT' : 'AI & IoT'}
                </button>
              </div>

              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 rtl:left-auto rtl:right-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder={isAr ? 'بحث بالاسم، التقنية (C#, Java, دورك)...' : 'Search by name or tech...'}
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full pl-9 rtl:pl-3 rtl:pr-9 pr-3 py-1.5 text-xs text-white bg-black/80 border border-slate-800 focus:border-orange-500 rounded-xl outline-none"
                />
              </div>
            </div>

            {/* Projects Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((proj) => (
                <div
                  key={proj.id}
                  className="bg-black/60 border border-slate-800/80 hover:border-orange-500/50 rounded-xl overflow-hidden flex flex-col justify-between transition-all group shadow-md hover:bg-black/80"
                >
                  <div>
                    {/* Media Image */}
                    <div className="relative w-full aspect-16/10 bg-black overflow-hidden">
                      <img
                        src={proj.imageUrl}
                        alt={isAr ? proj.titleAr : proj.titleEn}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#08090d] via-transparent to-transparent" />
                    </div>

                    <div className="p-5">
                      <span className="text-[11px] font-mono text-orange-400 font-semibold uppercase block mb-1">
                        {proj.category}
                      </span>

                      <h3 className="text-base font-bold text-white mb-2 group-hover:text-orange-300 transition-colors">
                        {isAr ? proj.titleAr : proj.titleEn}
                      </h3>

                      <p className="text-xs text-slate-300 leading-relaxed mb-4 line-clamp-3">
                        {isAr ? proj.descriptionAr : proj.descriptionEn}
                      </p>

                      {/* Tech stack */}
                      <div className="flex flex-wrap gap-1 mb-4">
                        {proj.technologies.slice(0, 3).map((t, idx) => (
                          <span
                            key={idx}
                            className="text-[11px] font-mono text-slate-300 bg-slate-950 px-2 py-0.5 rounded border border-slate-800"
                          >
                            {t}
                          </span>
                        ))}
                        {proj.technologies.length > 3 && (
                          <span className="text-[11px] font-mono text-orange-400/80 py-0.5">
                            +{proj.technologies.length - 3}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="p-5 pt-0">
                    <button
                      onClick={() => {
                        cyberAudio.playClickSound();
                        onSelectProject(proj);
                      }}
                      className="w-full flex items-center justify-center gap-2 py-2 px-3 text-xs font-semibold text-black bg-orange-500 hover:bg-orange-400 rounded-lg transition-colors cursor-pointer shadow-sm shadow-orange-500/20"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>{isAr ? 'عرض تفاصيل ومعمارية المشروع' : 'View Architecture'}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
