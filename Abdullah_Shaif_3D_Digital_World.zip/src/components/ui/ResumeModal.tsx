import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Printer, Mail, Phone, MapPin } from 'lucide-react';
import { ProfileInfo, ProjectItem, SkillItem } from '../../types/portfolio';
import { cyberAudio } from '../../utils/audio';
import { ModalCloseButton } from './ModalCloseButton';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: ProfileInfo;
  projects: ProjectItem[];
  skills: SkillItem[];
  lang: 'ar' | 'en';
}

export const ResumeModal: React.FC<ResumeModalProps> = ({
  isOpen,
  onClose,
  profile,
  projects,
  skills,
  lang
}) => {
  const isAr = lang === 'ar';

  const handlePrint = () => {
    cyberAudio.playClickSound();
    window.print();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-xs"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 25 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -15 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-4xl max-h-[94vh] overflow-y-auto bg-[#08090d] border border-orange-500/30 rounded-2xl shadow-2xl p-6 sm:p-10 text-slate-100 print:bg-white print:text-black print:border-none print:shadow-none print:p-0"
          >
            {/* Actions bar (hidden in print) */}
            <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-800 print:hidden">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-orange-400 font-mono">CV_DOCUMENT :: VERIFIED_AUTHENTIC</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrint}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-black bg-orange-500 hover:bg-orange-400 rounded-lg transition-colors cursor-pointer shadow-sm shadow-orange-500/20"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{isAr ? 'طباعة / حفظ PDF' : 'Print / Save PDF'}</span>
                </button>
                <ModalCloseButton onClose={onClose} className="relative top-0 right-0 rtl:left-0 rtl:right-0 p-1.5 rounded-lg" />
              </div>
            </div>

            {/* Printable CV Content */}
            <div className="space-y-6">
              {/* Header Lockup */}
              <div className="border-b border-slate-800 print:border-slate-300 pb-6">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white print:text-black font-cyber mb-1">
                  {isAr ? profile.nameAr : profile.nameEn}
                </h1>
                <p className="text-sm font-semibold text-orange-400 print:text-orange-700 mb-3">
                  {isAr ? profile.titleAr : profile.titleEn}
                </p>

                <div className="flex flex-wrap gap-4 text-xs text-slate-300 print:text-slate-700">
                  <span className="flex items-center gap-1">
                    <Mail className="w-3.5 h-3.5 text-orange-400 print:text-black" />
                    <span>{profile.email}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-orange-400 print:text-black" />
                    <span dir="ltr">{profile.whatsapp}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-orange-400 print:text-black" />
                    <span>{isAr ? profile.locationAr : profile.locationEn}</span>
                  </span>
                </div>
              </div>

              {/* Executive Summary */}
              <div>
                <h2 className="text-sm font-bold uppercase tracking-wider text-orange-400 print:text-black border-b border-slate-800 print:border-slate-300 pb-1 mb-2 font-cyber">
                  {isAr ? 'النبذة المهنية' : 'Executive Profile'}
                </h2>
                <p className="text-xs sm:text-sm leading-relaxed text-slate-300 print:text-slate-800">
                  {isAr ? profile.bioAr : profile.bioEn}
                </p>
              </div>

              {/* Key Engineering Projects */}
              <div>
                <h2 className="text-sm font-bold uppercase tracking-wider text-orange-400 print:text-black border-b border-slate-800 print:border-slate-300 pb-1 mb-3 font-cyber">
                  {isAr ? 'أبرز المشاريع والمنظومات المنفذة' : 'Key Engineering Projects'}
                </h2>
                <div className="space-y-4">
                  {projects.slice(0, 5).map((p) => (
                    <div key={p.id} className="p-3 bg-black/60 print:bg-slate-50 border border-slate-800/80 print:border-slate-200 rounded-lg">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="text-xs sm:text-sm font-bold text-white print:text-black">
                          {isAr ? p.titleAr : p.titleEn}
                        </h3>
                        <span className="text-[11px] font-mono text-orange-400 print:text-orange-800 uppercase font-bold">
                          {p.category}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 print:text-slate-700 mb-2">
                        {isAr ? p.descriptionAr : p.descriptionEn}
                      </p>
                      <div className="flex flex-wrap gap-1 text-[11px] text-slate-400 print:text-slate-600">
                        <span className="font-semibold text-orange-400/80">{isAr ? 'التقنيات:' : 'Tech:'}</span>
                        <span>{p.technologies.join(' · ')}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Technical Arsenal */}
              <div>
                <h2 className="text-sm font-bold uppercase tracking-wider text-orange-400 print:text-black border-b border-slate-800 print:border-slate-300 pb-1 mb-3 font-cyber">
                  {isAr ? 'المهارات التقنية والتخصصية' : 'Core Technical Arsenal'}
                </h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs text-slate-300 print:text-slate-800">
                  {skills.map((s) => (
                    <div key={s.id} className="flex items-center justify-between p-2 bg-black/60 print:bg-slate-50 border border-slate-800/80 print:border-slate-200 rounded">
                      <span className="font-medium">{s.name}</span>
                      <span className="font-mono text-orange-400 font-bold print:text-black">{s.level}%</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Education & Credentials */}
              <div>
                <h2 className="text-sm font-bold uppercase tracking-wider text-orange-400 print:text-black border-b border-slate-800 print:border-slate-300 pb-1 mb-2 font-cyber">
                  {isAr ? 'المؤهل العلمي' : 'Education'}
                </h2>
                <div className="text-xs text-slate-300 print:text-slate-800 space-y-1">
                  <p className="font-bold text-white print:text-black">
                    {isAr ? 'بكالوريوس هندسة نظم المعلومات وتكنولوجيا الحاسوب' : 'B.Sc. in Information Systems & Computer Engineering'}
                  </p>
                  <p className="text-slate-400 print:text-slate-600">
                    {isAr ? 'تخصص تطوير الأنظمة والتطبيقات الذكية وقواعد البيانات' : 'Specialization in Enterprise Systems, Mobile Engineering & Relational Databases'}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
