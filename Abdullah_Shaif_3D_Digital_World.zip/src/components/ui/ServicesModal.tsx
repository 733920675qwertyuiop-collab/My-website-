import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, ArrowRight, ArrowLeft } from 'lucide-react';
import { ServiceItem } from '../../types/portfolio';
import { cyberAudio } from '../../utils/audio';
import { ModalCloseButton } from './ModalCloseButton';

interface ServicesModalProps {
  isOpen: boolean;
  onClose: () => void;
  services: ServiceItem[];
  lang: 'ar' | 'en';
  onOrderService: (serviceTitle: string) => void;
}

export const ServicesModal: React.FC<ServicesModalProps> = ({
  isOpen,
  onClose,
  services,
  lang,
  onOrderService
}) => {
  const isAr = lang === 'ar';

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-xs"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 25 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -15 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-5xl max-h-[92vh] overflow-y-auto bg-[#08090d] border border-orange-500/30 rounded-2xl p-6 md:p-8 shadow-2xl text-slate-100"
          >
            {/* Global Animated Close Button */}
            <ModalCloseButton onClose={onClose} />

            {/* Header */}
            <div className="flex items-center gap-2 text-xs font-semibold text-orange-400 mb-2 uppercase">
              <span>{isAr ? 'الخدمات البرمجية والهندسية المتخصصة' : 'Engineering Services Laboratory'}</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>{services.length} {isAr ? 'خدمات معتمدة' : 'Disciplines'}</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-2 font-cyber">
              {isAr ? 'الخدمات والحلول البرمجية' : 'Full-Spectrum Engineering Services'}
            </h2>
            <p className="text-sm text-slate-300 mb-8 max-w-2xl">
              {isAr
                ? 'أقدم حلولاً هندسية دقيقة تجمع بين الأمان الفائق، الأداء العالي، ومعمارية النظم القابلة للتوسع.'
                : 'Delivering end-to-end software architecture with rigorous security hardening and resilient scalability.'}
            </p>

            {/* Services Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {services.map((srv, idx) => (
                <div
                  key={srv.id}
                  className="bg-black/60 border border-slate-800/80 hover:border-orange-500/50 rounded-xl p-5 flex flex-col justify-between transition-all group hover:bg-black/80"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-mono text-orange-400 font-bold">0{idx + 1}.</span>
                      <span className="text-[11px] text-lime-400/80 font-mono">STANDARDS_PASS</span>
                    </div>

                    <h3 className="text-base font-bold text-white mb-2 group-hover:text-orange-300 transition-colors">
                      {isAr ? srv.titleAr : srv.titleEn}
                    </h3>

                    <p className="text-xs text-slate-300 leading-relaxed mb-4">
                      {isAr ? srv.descriptionAr : srv.descriptionEn}
                    </p>

                    <div className="space-y-1.5 mb-5">
                      {(isAr ? srv.deliverablesAr : srv.deliverablesEn).map((d, dIdx) => (
                        <div key={dIdx} className="flex items-start gap-2 text-xs text-slate-400">
                          <CheckCircle2 className="w-3.5 h-3.5 text-orange-400 shrink-0 mt-0.5" />
                          <span>{d}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="flex flex-wrap gap-1.5 pt-3 border-t border-slate-800/80 mb-4">
                      {srv.techStack.map((tech, tIdx) => (
                        <span
                          key={tIdx}
                          className="text-[11px] font-mono text-orange-300 bg-slate-950 px-2 py-0.5 rounded border border-slate-800"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>

                    <button
                      onClick={() => {
                        cyberAudio.playClickSound();
                        onOrderService(isAr ? srv.titleAr : srv.titleEn);
                      }}
                      className="w-full flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-slate-200 hover:text-black bg-slate-900 hover:bg-orange-500 rounded-lg transition-all border border-slate-800 hover:border-orange-400 cursor-pointer shadow-sm"
                    >
                      <span>{isAr ? 'طلب هذه الخدمة' : 'Engage Service'}</span>
                      {isAr ? <ArrowLeft className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
