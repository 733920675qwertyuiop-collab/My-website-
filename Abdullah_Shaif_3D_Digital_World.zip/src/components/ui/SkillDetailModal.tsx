import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, Copy, Check } from 'lucide-react';
import { SkillItem } from '../../types/portfolio';
import { cyberAudio } from '../../utils/audio';
import { ModalCloseButton } from './ModalCloseButton';

interface SkillDetailModalProps {
  skill: SkillItem | null;
  onClose: () => void;
  lang: 'ar' | 'en';
}

export const SkillDetailModal: React.FC<SkillDetailModalProps> = ({
  skill,
  onClose,
  lang
}) => {
  const [copied, setCopied] = useState(false);
  const isAr = lang === 'ar';

  const handleCopy = () => {
    if (skill?.codeSnippet) {
      navigator.clipboard.writeText(skill.codeSnippet);
      setCopied(true);
      cyberAudio.playClickSound();
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <AnimatePresence>
      {skill && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-xs"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 25 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -15 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-2xl bg-[#08090d] border border-orange-500/30 rounded-2xl p-6 md:p-8 shadow-2xl text-slate-100"
          >
            {/* Global Animated Close Button */}
            <ModalCloseButton onClose={onClose} />

            {/* Category Header */}
            <div className="flex items-center gap-2 text-xs font-semibold text-orange-400 mb-2 uppercase tracking-wide">
              <span>{isAr ? 'فحص التقنية ثلاثية الأبعاد' : '3D Technology Inspection'}</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>{skill.category}</span>
            </div>

            {/* Skill Title & Proficiency Indicator */}
            <div className="flex items-center justify-between gap-4 mb-4">
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-cyber flex items-center gap-3">
                <span
                  className="w-4 h-4 rounded-full inline-block shadow-sm"
                  style={{ backgroundColor: skill.color }}
                />
                {skill.name}
              </h2>

              <div className="text-right rtl:text-left">
                <span className="text-xl font-bold font-cyber text-orange-400">{skill.level}%</span>
                <span className="text-xs text-slate-400 block">{isAr ? 'مستوى التمكن' : 'Proficiency'}</span>
              </div>
            </div>

            {/* Level Progress Bar */}
            <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden mb-6">
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{
                  width: `${skill.level}%`,
                  backgroundColor: skill.color
                }}
              />
            </div>

            {/* Description */}
            <p className="text-sm leading-relaxed text-slate-300 mb-6 bg-black/60 p-4 rounded-xl border border-slate-800">
              {isAr ? skill.descriptionAr : skill.descriptionEn}
            </p>

            {/* Practical Use Cases */}
            <div className="mb-6">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                {isAr ? 'مجالات الاستخدام والتطبيق العملي:' : 'Real-World Production Applications:'}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {(isAr ? skill.useCasesAr : skill.useCasesEn).map((uc, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-xs text-slate-200 bg-black/60 p-2.5 rounded-lg border border-slate-800">
                    <CheckCircle className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                    <span>{uc}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Code Snippet if present */}
            {skill.codeSnippet && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-slate-400 font-mono">
                    {isAr ? 'نموذج الكود البرمجي (Snippet):' : 'Code Pattern:'}
                  </span>
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-1 text-xs text-orange-400 hover:text-orange-300 transition-colors"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-lime-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? (isAr ? 'تم النسخ' : 'Copied') : (isAr ? 'نسخ' : 'Copy')}</span>
                  </button>
                </div>
                <pre className="p-3 bg-black border border-orange-500/20 rounded-xl text-xs text-orange-300 font-mono overflow-x-auto text-left" dir="ltr">
                  <code>{skill.codeSnippet}</code>
                </pre>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
