import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search } from 'lucide-react';
import { SkillItem } from '../../types/portfolio';
import { cyberAudio } from '../../utils/audio';
import { ModalCloseButton } from './ModalCloseButton';

interface SkillsBrowserModalProps {
  isOpen: boolean;
  onClose: () => void;
  skills: SkillItem[];
  lang: 'ar' | 'en';
  onSelectSkill: (s: SkillItem) => void;
}

export const SkillsBrowserModal: React.FC<SkillsBrowserModalProps> = ({
  isOpen,
  onClose,
  skills,
  lang,
  onSelectSkill
}) => {
  const [filter, setFilter] = useState<'all' | 'backend' | 'frontend' | 'mobile' | 'database' | 'languages'>('all');
  const [search, setSearch] = useState('');
  const isAr = lang === 'ar';

  const filtered = skills.filter((s) => {
    const matchesCat = filter === 'all' || s.category === filter;
    const matchesSearch = s.name.toLowerCase().includes(search.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-xs"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 25 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -15 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-5xl max-h-[92vh] overflow-y-auto bg-[#08090d] border border-orange-500/30 rounded-2xl p-6 md:p-8 shadow-2xl text-slate-100"
          >
            {/* Global Animated Close Button */}
            <ModalCloseButton onClose={onClose} />

            {/* Header */}
            <div className="flex items-center gap-2 text-xs font-semibold text-orange-400 mb-2 uppercase">
              <span>{isAr ? 'الترسانة التقنية والبرمجية' : 'Technical Engineering Arsenal'}</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>{skills.length} {isAr ? 'تقنيات ولغات' : 'Technologies'}</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-4 font-cyber">
              {isAr ? 'مصفوفة المهارات ولغات البرمجة' : 'Skills & Tech Stacks Matrix'}
            </h2>

            {/* Filter bar and search */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-6">
              <div className="flex items-center gap-1.5 p-1 bg-black/70 border border-slate-800 rounded-xl overflow-x-auto">
                {(['all', 'backend', 'frontend', 'mobile', 'database', 'languages'] as const).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setFilter(cat)}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                      filter === cat ? 'bg-orange-500 text-black shadow-sm font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {cat === 'all'
                      ? isAr ? 'الكل' : 'All'
                      : cat === 'backend'
                      ? isAr ? 'الخوادم' : 'Backend'
                      : cat === 'frontend'
                      ? isAr ? 'الواجهات' : 'Frontend'
                      : cat === 'mobile'
                      ? isAr ? 'الهواتف' : 'Mobile'
                      : cat === 'database'
                      ? isAr ? 'قواعد البيانات' : 'Databases'
                      : isAr ? 'لغات برمجية' : 'Languages'}
                  </button>
                ))}
              </div>

              <div className="relative w-full sm:w-60">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 rtl:left-auto rtl:right-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder={isAr ? 'بحث عن تقنية...' : 'Search tech...'}
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full pl-9 rtl:pl-3 rtl:pr-9 pr-3 py-1.5 text-xs text-white bg-black/80 border border-slate-800 focus:border-orange-500 rounded-xl outline-none"
                />
              </div>
            </div>

            {/* Skills Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filtered.map((skill) => (
                <div
                  key={skill.id}
                  onClick={() => {
                    cyberAudio.playClickSound();
                    onSelectSkill(skill);
                  }}
                  className="bg-black/60 border border-slate-800/80 hover:border-orange-500/50 p-4 rounded-xl cursor-pointer transition-all hover:-translate-y-0.5 group shadow-sm hover:bg-black/80"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span
                        className="w-3.5 h-3.5 rounded-full inline-block"
                        style={{ backgroundColor: skill.color }}
                      />
                      <h3 className="text-sm font-bold text-white group-hover:text-orange-400 transition-colors">
                        {skill.name}
                      </h3>
                    </div>
                    <span className="text-xs font-mono font-bold text-orange-400">{skill.level}%</span>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden mb-3">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${skill.level}%`, backgroundColor: skill.color }}
                    />
                  </div>

                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed mb-3">
                    {isAr ? skill.descriptionAr : skill.descriptionEn}
                  </p>

                  <div className="text-[11px] text-orange-400 flex items-center gap-1 group-hover:underline font-semibold">
                    <span>{isAr ? 'فحص الكود والخصائص 3D ↗' : 'Inspect 3D Node ↗'}</span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
