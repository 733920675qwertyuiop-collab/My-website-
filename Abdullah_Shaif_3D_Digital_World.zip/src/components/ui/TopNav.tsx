import React from 'react';
import { Volume2, VolumeX, Shield, Globe } from 'lucide-react';
import { SceneStation } from '../../types/portfolio';
import { cyberAudio } from '../../utils/audio';

interface TopNavProps {
  currentStation: SceneStation;
  onNavigate: (station: SceneStation) => void;
  lang: 'ar' | 'en';
  onToggleLang: () => void;
  isMuted: boolean;
  onToggleSound: () => void;
  onOpenAdmin: () => void;
  onOpenContact: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentStation,
  onNavigate,
  lang,
  onToggleLang,
  isMuted,
  onToggleSound,
  onOpenAdmin,
  onOpenContact
}) => {
  const isAr = lang === 'ar';

  const navLinks: { station: SceneStation; labelAr: string; labelEn: string }[] = [
    { station: 'home', labelAr: 'العالم الرقمي', labelEn: '3D World' },
    { station: 'about', labelAr: 'من أنا', labelEn: 'About' },
    { station: 'skills', labelAr: 'المهارات', labelEn: 'Skills' },
    { station: 'projects', labelAr: 'المشاريع', labelEn: 'Projects' },
    { station: 'services', labelAr: 'الخدمات', labelEn: 'Services' },
    { station: 'contact', labelAr: 'تواصل', labelEn: 'Contact' }
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-30 flex items-center justify-between gap-8 px-6 py-4 bg-[#06070a]/90 border-b border-orange-500/20">
      {/* Zone 1: Single-element Brand Wordmark */}
      <button
        onClick={() => {
          cyberAudio.playClickSound();
          onNavigate('home');
        }}
        className="text-left rtl:text-right group flex items-center gap-2 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-orange-400 rounded-sm"
      >
        <span className="text-lg font-bold tracking-tight text-white group-hover:text-orange-400 transition-colors whitespace-nowrap shrink-0">
          {isAr ? 'المهندس عبدالله عبدة شايف' : 'Eng. Abdullah Abdo Shaif'}
        </span>
      </button>

      {/* Zone 2: 5 Clean single-line text navigation links */}
      <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-300">
        {navLinks.map((item) => {
          const isActive = currentStation === item.station;
          return (
            <button
              key={item.station}
              onClick={() => {
                cyberAudio.playClickSound();
                onNavigate(item.station);
              }}
              className={`transition-colors whitespace-nowrap shrink-0 hover:text-orange-400 py-1 ${
                isActive ? 'text-orange-400 font-semibold border-b-2 border-orange-400' : 'text-slate-300'
              }`}
            >
              {isAr ? item.labelAr : item.labelEn}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: 1 Primary Action + Utility Controls */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Sound Toggle */}
        <button
          onClick={onToggleSound}
          title={isMuted ? 'تشغيل المؤثرات الصوتية' : 'كتم الصوت'}
          className="p-2 text-slate-300 hover:text-orange-400 hover:bg-slate-800/60 rounded-lg transition-colors cursor-pointer"
          aria-label="Toggle Sound"
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-orange-400" />}
        </button>

        {/* Language Toggle */}
        <button
          onClick={onToggleLang}
          title="تبديل اللغة / Toggle Language"
          className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-slate-200 hover:text-orange-400 hover:bg-slate-800/60 rounded-lg border border-slate-700/60 transition-colors cursor-pointer"
        >
          <Globe className="w-3.5 h-3.5" />
          <span className="uppercase">{isAr ? 'EN' : 'عربي'}</span>
        </button>

        {/* Admin Dashboard trigger */}
        <button
          onClick={() => {
            cyberAudio.playClickSound();
            onOpenAdmin();
          }}
          title={isAr ? 'لوحة تحكم الموقع' : 'Admin Console'}
          className="p-2 text-slate-400 hover:text-orange-400 hover:bg-slate-800/60 rounded-lg transition-colors cursor-pointer"
          aria-label="Admin Dashboard"
        >
          <Shield className="w-4 h-4" />
        </button>

        {/* Primary CTA in Electric Orange */}
        <button
          onClick={() => {
            cyberAudio.playClickSound();
            onOpenContact();
          }}
          className="px-4 py-2 text-xs font-bold text-black bg-orange-500 hover:bg-orange-400 active:scale-95 rounded-lg transition-all shadow-md shadow-orange-500/25 whitespace-nowrap shrink-0 cursor-pointer"
        >
          {isAr ? 'بدء مشروع جديد' : 'Initiate Project'}
        </button>
      </div>
    </header>
  );
};
