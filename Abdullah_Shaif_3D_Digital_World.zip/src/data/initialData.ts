import { ProfileInfo, ProjectItem, SkillItem, ServiceItem } from '../types/portfolio';

export const initialProfile: ProfileInfo = {
  nameAr: 'المهندس عبدالله عبدة شايف',
  nameEn: 'Eng. Abdullah Abdo Shaif',
  titleAr: 'مهندس نظم معلومات | مطور تطبيقات أندرويد | مطور مواقع وأنظمة إلكترونية',
  titleEn: 'Information Systems Engineer | Android & Full-Stack Systems Developer',
  subTitleAr: 'أحوّل الأفكار إلى حلول رقمية مبتكرة وعوالم برمجية متكاملة',
  subTitleEn: 'Transforming complex ideas into innovative, scalable digital realities',
  bioAr: 'أنا عبدالله عبدة شايف، مهتم بعالم البرمجة وتطوير الأنظمة والتطبيقات والمواقع الإلكترونية. أسعى إلى بناء حلول تقنية مبتكرة تجمع بين قوة البرمجة وجمال التصميم وسهولة الاستخدام. أحب اكتشاف التقنيات الحديثة، وتطوير مهاراتي باستمرار، وتحويل الأفكار إلى مشاريع رقمية حقيقية قابلة للتطوير والتوسع المستقبلي.',
  bioEn: 'I am Abdullah Abdo Shaif, passionate about software engineering, systems architecture, and mobile/web development. I strive to engineer robust technical solutions that fuse algorithmic rigor, elegant UX design, and rock-solid reliability. Constantly learning modern technologies to turn visionary ideas into production-ready software.',
  avatarUrl: '/assets/aistudio/Screenshot_20261111-161120_d453d279.png',
  originalPhotoUrl: '/assets/aistudio/Screenshot_20261111-161120_d453d279.png',
  email: 'bdh681100@gmail.com',
  phone: '+967 770 000 000',
  whatsapp: '+967770000000',
  locationAr: 'اليمن — متاح للعمل عن بعد وحول العالم',
  locationEn: 'Yemen — Available for Global Remote Contracts',
  github: 'https://github.com/abdullah-shaif',
  linkedin: 'https://linkedin.com/in/abdullah-shaif',
  telegram: 'https://t.me/abdullah_shaif',
  yearsExperience: 5,
  completedProjects: 40,
  satisfiedClients: 42,
  availableForHire: true
};

export const initialProjects: ProjectItem[] = [
  {
    id: 'tareeqi',
    titleAr: 'طريقي — منصة المواصلات اليمنية',
    titleEn: 'Tareeqi — Yemeni Smart Transport Platform',
    taglineAr: 'منظومة حجز رحلات وتتبع خطوط النقل الذكي بين المدن اليمنية',
    taglineEn: 'Intercity and urban ride booking & dispatch logistics network',
    descriptionAr: 'منصة رقمية متطورة مصممة خصيصاً لتنظيم قطاع المواصلات والنقل الداخلي والبيني في اليمن. توفر حجز المقاعد الفوري، متابعة مسارات الحافلات والسيارات بالـ GPS في الزمن الفعلي، وإدارة محطات الانطلاق والوصول بكل دقة.',
    descriptionEn: 'A high-concurrency transit booking and dispatch ecosystem tailored for Yemeni intercity travel. Features real-time GPS tracking, ticket issuance, seat selection, and automated depot scheduling.',
    technologies: ['Android (Kotlin)', 'PHP 8.2', 'MySQL', 'REST API', 'Leaflet / GPS Geolocation', 'Tailwind CSS'],
    category: 'mobile',
    imageUrl: '/assets/projects/tareeqi.svg',
    featuresAr: [
      'تتبع مباشر لمسار الرحلات والمواقع الجغرافية بالزمن الحقيقي',
      'نظام حجز تذاكر رقمي سريع مع رمز QR آمن للمسافرين',
      'لوحة تحكم ذكية لإدارة السائقين وتوزيع الرحلات وحساب العوائد',
      'دعم كامل للعمل مع شبكات الاتصال البطيئة وغير المستقرة'
    ],
    featuresEn: [
      'Live GPS telemetry and dynamic ETA routing',
      'Encrypted digital boarding passes with instant QR validation',
      'Fleet dispatch hub for drivers, depots, and revenue allocation',
      'Offline-tolerant sync designed for resilient mobile usage'
    ],
    architectureDetailsAr: 'معمارية بنظام RESTful Micro-services مبنية بـ PHP وMySQL مع تخزين مؤقت لبيانات المسارات وتطبيق أندرويد بلغة Kotlin يدعم تخزين البيانات محلياً (Room DB) لضمان العمل حتى عند انقطاع الإنترنت.',
    architectureDetailsEn: 'Modular PHP/MySQL backend with optimized geospatial indexing, connected to a robust native Android Kotlin application utilizing Room local persistence for intermittent connectivity.',
    liveUrl: '#',
    githubUrl: '#',
    featured: true
  },
  {
    id: 'legaci',
    titleAr: 'Legaci — منصة الميراث الرقمي والتركات',
    titleEn: 'Legaci — Digital Inheritance & Estate Platform',
    taglineAr: 'خزنة رقمية مشفرة لإدارة وتوريث الأصول والوصايا الرقمية بأمان',
    taglineEn: 'Cryptographic vault for secure estate planning and legacy transition',
    descriptionAr: 'حل تقني ريادي يحل معضلة انتقال الأصول الرقمية والحسابات والوثائق الحساسة بعد الوفاة وفق الشريعة والقوانين المنظمة. يعتمد على التشفير العسكري وتقنيات التحقق التلقائي لضمان وصول التركات للمستحقين بسرية تامة.',
    descriptionEn: 'A cutting-edge cryptographic security platform that automates the succession of digital assets, sensitive credentials, and legal testaments to designated beneficiaries with multi-factor proof-of-life protocols.',
    technologies: ['React.js', 'PHP OOP', 'MySQL PDO', 'AES-256 Encryption', 'Tailwind CSS', 'REST API'],
    category: 'system',
    imageUrl: '/assets/projects/legaci.svg',
    featuresAr: [
      'خزنة سحابية فائقة الأمان بتشفير طرف إلى طرف من درجة AES-256',
      'حاسبة تركات شرعية متطورة تبرمج أنصبة الورثة بدقة رياضية صارمة',
      'بروتوكول تحقق دوري ذكي (Proof-of-Life Check) قبل تفعيل وصايا الانتقال',
      'إدارة أذونات متعددة المستويات ومفاتيح استرداد مجزأة'
    ],
    featuresEn: [
      'End-to-end AES-256 cryptographic vault with zero-knowledge architecture',
      'Algorithmic estate dividend calculation respecting legal rules',
      'Automated heartbeat verification trigger before testament execution',
      'Shamir secret-sharing key distribution for authorized trustees'
    ],
    architectureDetailsAr: 'تطبيق ويب آمن بنظام MVC كامل مع PHP 8.2، فصل طبقة التشفير التام في جانب الخادم وقاعدة بيانات MySQL محمية ضد ثغرات SQLi وCSRF وجلسات مؤمنة بـ JWT.',
    architectureDetailsEn: 'Full MVC architecture powered by modern PHP 8.2 with rigorous CSRF/XSS defense, prepared PDO statements, and tokenized session authentication.',
    liveUrl: '#',
    githubUrl: '#',
    featured: true
  },
  {
    id: 'dawrak',
    titleAr: 'Dawrak — نظام إدارة الطوابير والحجوزات',
    titleEn: 'Dawrak — Integrated Queue & Appointment System',
    taglineAr: 'منظومة ذكية لإدارة تدفق المراجعين وشاشات الخدمة وحجز المواعيد',
    taglineEn: 'Enterprise smart ticketing, queue dispatch, and appointment scheduling',
    descriptionAr: 'نظام متكامل للمستشفيات، البنوك، والمؤسسات الخدمية لإدارة طوابير الانتظار وحجز المواعيد إلكترونياً. يقلل زمن الانتظار بنسبة 60% مع شاشات عرض تفاعلية وإشعارات فورية عبر الواتساب والرسائل النصية.',
    descriptionEn: 'An enterprise-grade queue orchestration suite featuring touchscreen kiosk ticketing, digital counter signage, real-time ticket tracking, and multi-channel SMS/WhatsApp alerts for banks and medical facilities.',
    technologies: ['React.js', 'PHP / Laravel', 'MySQL', 'WebSockets', 'Android Kiosk', 'Tailwind CSS'],
    category: 'system',
    imageUrl: '/assets/projects/dawrak.svg',
    featuresAr: [
      'لوحة قيادة تفاعلية للموظفين لنداء وإحالة التذاكر بنقرة واحدة',
      'شاشات عرض تفاعلية ذكية للصالات تدعم الصوت التوجيهي والوسائط',
      'تطبيق أندرويد لأكشاك التذاكر الذاتية (Self-Service Kiosk)',
      'تقارير إحصائية دقيقة لزمن خدمة العملاء وكفاءة الكوادر'
    ],
    featuresEn: [
      'Single-click teller dispatch dashboard with priority rerouting',
      'Real-time TV display boards with synchronized Arabic voice synthesis',
      'Android kiosk application with thermal printer USB/Bluetooth integration',
      'Executive analytics on service latency, peak hours, and staff throughput'
    ],
    architectureDetailsAr: 'مبني بنظام مزدوج: خادم PHP REST API عالي السرعة وقاعدة بيانات MySQL مع واجهة تفاعلية بـ React وشاشات عرض تعمل بدون توقف، بالإضافة إلى تطبيق أندرويد مخصص لأكشاك الطباعة الحرارية.',
    architectureDetailsEn: 'High-throughput PHP REST API backed by an optimized MySQL schema with React-driven counter interfaces and native Android kiosks for thermal ticket printing.',
    liveUrl: '#',
    githubUrl: '#',
    featured: true
  },
  {
    id: 'baseera_ai',
    titleAr: 'بصيرة AI — منصة الرؤية الحاسوبية وتحليل الصور',
    titleEn: 'Baseera AI — Computer Vision Intelligence Platform',
    taglineAr: 'تحليل الصور الطبية والصناعية واكتشاف الأنماط بدقة فائقة بالذكاء الاصطناعي',
    taglineEn: 'Computer vision engine for diagnostic image segmentation and pattern recognition',
    descriptionAr: 'منظومة ذكاء اصطناعي متخصصة في تحليل وتصنيف الصور بدقة عالية، وتحديد العيوب في خطوط الإنتاج أو تحليل الفحوصات الطبية، مع توليد تقارير بيانية تفاعلية فورية للباحثين والمشرفين.',
    descriptionEn: 'A deep-learning powered image analytics platform capable of semantic segmentation, anomaly detection, and automated report generation for diagnostic imaging and industrial quality inspection.',
    technologies: ['Python', 'TensorFlow / PyTorch', 'FastAPI / PHP Bridge', 'React.js', 'Tailwind CSS'],
    category: 'ai',
    imageUrl: '/assets/projects/baseera_ai.svg',
    featuresAr: [
      'محرك ذكاء اصطناعي لتحليل الصور وتقسيم المعالم في أجزاء من الثانية',
      'واجهة مستخدم تفاعلية لفحص الصور بطبقات حرارية وخاصية التكبير الدقيق',
      'تصدير تقارير فحص احترافية بصيغة PDF تتضمن النتائج والمقاييس البيانية',
      'دعم كامل لمعالجة دفعات الصور الكبيرة تلقائياً'
    ],
    featuresEn: [
      'Sub-second inference for convolutional neural network image segmentation',
      'Interactive visualizer with heatmap overlays and sub-pixel inspection',
      'Automated diagnostic PDF generation with statistical confidence scores',
      'High-throughput batch image processing pipeline'
    ],
    architectureDetailsAr: 'هيكلية تجمع بين محرك استدلال سريع بلغة Python مع جسر API للاتصال بواجهة الويب التفاعلية، وتخزين النتائج في قاعدة بيانات منظمة مع تشفير وحماية تامة للبيانات.',
    architectureDetailsEn: 'Hybrid micro-service architecture pairing high-performance Python inference with an asynchronous API gateway and responsive React visualizer.',
    liveUrl: '#',
    githubUrl: '#',
    featured: true
  },
  {
    id: 'miqwat',
    titleAr: 'مِقْوَت — منصة تجارة المحاصيل والتوصيل السريع',
    titleEn: 'Miqwat — Agricultural Marketplace & On-Demand Delivery',
    taglineAr: 'منصة تجارة إلكترونية متخصصة في بيع وشراء وتوصيل القات والمحاصيل الطازجة',
    taglineEn: 'Dedicated e-commerce marketplace and logistics system for fresh produce and Qat trade',
    descriptionAr: 'منصة تجارة إلكترونية متكاملة تربط بين المزارعين والتجار والعملاء مباشرة، مع نظام تسعير فوري يعتمد على الجودة وموقع المزرعة، وإدارة أسطول المندوبين مع تتبع مسار التوصيل السريع خطوة بخطوة.',
    descriptionEn: 'A specialized hyper-local e-commerce marketplace connecting verified growers, distributors, and buyers with dynamic quality grading, scheduled courier dispatch, and multi-currency accounting.',
    technologies: ['PHP 8.2 OOP', 'MySQL', 'Android Native', 'REST API', 'Google Maps Platform', 'Tailwind CSS'],
    category: 'web',
    imageUrl: '/assets/projects/miqwat.svg',
    featuresAr: [
      'كتالوج منتجات تفاعلي مع تصنيف دقيق للجودة ومصدر المحصول',
      'نظام سلة وتسوق فوري مع دعم المحافظ الإلكترونية المحلية والدفع عند الاستلام',
      'تطبيق مخصص لمندوبي التوصيل مع إشعارات الرحلات وخرائط الطرق المثالية',
      'لوحة تحكم للمزارعين والتجار لمتابعة المبيعات والأرباح والمخزون'
    ],
    featuresEn: [
      'Interactive crop catalog with strict origin and freshness rating indices',
      'Instant checkout supporting cash-on-delivery and local mobile wallets',
      'Dedicated courier app with automated routing and drop-off confirmation',
      'Merchant management dashboard for inventory, revenue, and daily balances'
    ],
    architectureDetailsAr: 'نظام متكامل مبني بمعمارية PHP MVC نقية وقاعدة بيانات MySQL علائقية محسنة، مع واجهات برمجة تطبيقات REST API لخدمة تطبيقي العميل والمندوب بكفاءة وسرعة فائقة.',
    architectureDetailsEn: 'Pure PHP 8.2 MVC architecture paired with an optimized relational MySQL schema, powering high-throughput mobile endpoints for buyers, merchants, and couriers.',
    liveUrl: '#',
    githubUrl: '#',
    featured: true
  },
  {
    id: 'waynak_dsa',
    titleAr: 'وينك (Waynak) — محرك الملاحة الذكي وهياكل البيانات المتقدمة بـ Java',
    titleEn: 'Waynak — Intelligent Navigation Engine & Advanced DSA (Java)',
    taglineAr: 'منظومة ملاحة وحساب أقصر المسارات بالزمن الفعلي باستخدام خوارزميات الرسوم البيانية والأشجار الموزونة',
    taglineEn: 'Real-time spatial navigation and shortest-path computation powered by Graph Theory & Weighted Trees',
    descriptionAr: 'مشروع تطبيقي عميق تم بناؤه بلغة Java يجسد القوة الهندسية لهياكل البيانات والخوارزميات (Data Structures & Algorithms). يقوم بحساب المسارات الأكثر كفاءة بين مئات النقاط الجغرافية عبر خوارزميات Dijkstra وA*، وإدارة نقاط التوقف عبر Min-Heap وAdjacency Lists مع معالجة حية للاختناقات المرورية.',
    descriptionEn: 'A high-performance algorithmic navigation engine engineered in Java demonstrating advanced DSA patterns. Implements Dijkstra, A* heuristic pathfinding, and Priority Queues over dynamic spatial graphs for real-time optimal routing.',
    technologies: ['Java 21', 'Graph Algorithms (Dijkstra/A*)', 'Data Structures (Min-Heap, Trees)', 'Spring Boot REST', 'Leaflet GIS'],
    category: 'system',
    imageUrl: '/assets/projects/waynak_dsa.svg',
    featuresAr: [
      'محرك بحث مسارات فائق السرعة بزمن تنفيذ O((V + E) log V) بالاعتماد على خوارزمية دكسترا وأشجار باينري هيب',
      'تمثيل شبكة الطرق والمدن بهياكل الرسوم البيانية الموجهة والموزونة (Weighted Directed Graphs)',
      'محاكاة حركة المرور وتحديث أوزان المسارات ديناميكياً لتجنب الحوادث والازدحام',
      'واجهة برمجية RESTful لربط المحرك بتطبيقات الهواتف المحمولة والخرائط التفاعلية'
    ],
    featuresEn: [
      'Sub-millisecond route calculation using binary min-heaps and adjacency list representations',
      'Dynamic edge re-weighting responding to real-time telemetry and congestion feeds',
      'Zero-allocation memory optimization for large-scale geographic coordinate processing',
      'RESTful microservice interface for cross-platform integration with mobile map clients'
    ],
    architectureDetailsAr: 'بنية برمجية معيارية بـ Java OOP النقية، حيث تم بناء هياكل البيانات يدوياً بدون الاعتماد على مكتبات جاهزة لضمان أقصى سرعة ومعالجة ذاكرة، مع غلاف Spring Boot لتوفير واجهات RESTful سريعة.',
    architectureDetailsEn: 'Hand-crafted DSA core built with pure Java OOP to maximize cache locality and low garbage-collection latency, wrapped in a lightweight Spring Boot container.',
    liveUrl: '#',
    githubUrl: '#',
    featured: true
  },
  {
    id: 'alshamel_erp',
    titleAr: 'الشامل ERP — منظومة إدارة الموارد والمؤسسات المتكاملة بـ .NET C#',
    titleEn: 'Al-Shamel ERP — Enterprise Resource Planning & Ledger Suite (.NET C#)',
    taglineAr: 'نظام إدارة الشركات والمستودعات والحسابات العامة متعدد الفروع والعملات',
    taglineEn: 'Enterprise multi-branch accounting, double-entry ledger, and supply chain ERP',
    descriptionAr: 'منظومة مؤسسية ضخمة طُورت باستخدام تقنيات Microsoft .NET وC# مع قاعدة بيانات Microsoft SQL Server. تتضمن دورة محاسبية متكاملة (شجرة الحسابات، قيود اليومية، ميزان المراجعة، الأرباح والخسائر)، مع إدارة المخازن والمشتريات والمبيعات ومزامنة الفروع عبر شبكات VPN.',
    descriptionEn: 'An enterprise-tier resource planning platform engineered with C# .NET and MS SQL Server. Delivers complete double-entry general ledger, multi-currency journal balancing, inventory replenishment, and multi-branch transaction synchronization.',
    technologies: ['C# .NET 8', 'WPF / WinUI', 'MS SQL Server Enterprise', 'Entity Framework Core', 'LINQ', 'Crystal Reports'],
    category: 'system',
    imageUrl: '/assets/projects/alshamel_erp.svg',
    featuresAr: [
      'شجرة حسابات مالية تفاعلية متعددة المستويات تتوافق مع المعايير المحاسبية الدولية',
      'نظام جرد دوري ومستمر للمستودعات مع دعم الباركود وتواريخ الصلاحية وتكلفة الوارد أولاً صادر أولاً (FIFO)',
      'إدارة أذونات المستخدمين والأدوار الوظيفية بنظام RBAC الدقيق وتسجيل عمليات التدقيق (Audit Logs)',
      'محرك تقارير مالية تفصيلية وميزانيات ختامية وتصدير فوري إلى Excel وPDF'
    ],
    featuresEn: [
      'Hierarchical chart of accounts supporting multi-currency and cost-center allocations',
      'Perpetual inventory tracking with barcode scanning, batch expiry tracking, and FIFO valuation',
      'Granular Role-Based Access Control (RBAC) paired with cryptographic transaction audit logs',
      'Real-time financial statement generation including balance sheets and cash-flow projections'
    ],
    architectureDetailsAr: 'معمارية ثلاثية الطبقات (3-Tier Architecture) تفصل واجهات المستخدم WPF عن منطق الأعمال (BLL) وطبقة الوصول للبيانات (DAL) باستخدام Repository Pattern وUnit of Work مع إجراءات مخزنة (Stored Procedures) في SQL Server.',
    architectureDetailsEn: 'Enterprise 3-tier architecture utilizing WPF presentation, Business Logic Layer (BLL), and EF Core Repository/Unit-of-Work patterns with optimized SQL Server stored procedures.',
    liveUrl: '#',
    githubUrl: '#',
    featured: true
  },
  {
    id: 'smart_pharmacy',
    titleAr: 'الصيدلي الذكي — نظام نقاط البيع وإدارة الصيدليات بـ .NET C#',
    titleEn: 'Smart Pharmacy POS & Drug Inventory System (.NET C#)',
    taglineAr: 'إدارة متكاملة لبيانات الأدوية، تواريخ الصلاحية، الوصفات الطبية، ونقاط البيع السريعة',
    taglineEn: 'Complete pharmaceutical retail dispensing, drug interaction checker, and inventory suite',
    descriptionAr: 'برنامج مخصص للصيدليات ومستودعات الأدوية طُور بـ C# .NET. يوفر بيعاً سريعاً بالباركود، وتنبيهات تلقائية للأدوية المنتهية الصلاحية والجرعات المتعارضة، وإدارة حسابات الموردين وشركات التأمين الصحي.',
    descriptionEn: 'A specialized pharmaceutical point-of-sale and prescription fulfillment application built with C# .NET. Features instant barcode lookup, batch expiry alerts, drug-to-drug contraindication warnings, and insurance claim processing.',
    technologies: ['C# .NET', 'Windows Forms / WPF', 'SQL Server Express', 'Barcode Scanning API', 'Thermal Receipt Printing'],
    category: 'system',
    imageUrl: '/assets/projects/smart_pharmacy.svg',
    featuresAr: [
      'فواتير بيع سريعة مع قراءة الباركود الدولي والمحلي ودعم الدفع النقدي والإلكتروني',
      'قاعدة بيانات للأدوية والبدائل الجنيسة وتنبيهات تداخل الأدوية',
      'نظام جرد آلي وتنبيهات بالحد الأدنى للأصناف وتواريخ انتهاء الصلاحية قبل 30 و60 و90 يوماً',
      'الربط المباشر مع الطابعات الحرارية ودرج النقود وشاشات العميل'
    ],
    featuresEn: [
      'High-velocity checkout with integrated barcode scanners and multi-tender payments',
      'Comprehensive drug registry with generic equivalents and interaction alerts',
      'Automated reorder triggers and shelf-life expiration threshold monitoring',
      'Hardware integration with ESC/POS thermal printers and customer-facing pole displays'
    ],
    architectureDetailsAr: 'تطبيق سطحي عالي الاستجابة مبني بـ C# .NET وقاعدة بيانات محلية SQL Server مدمجة مع نظام نسخ احتياطي تلقائي للبيانات وحماية من انقطاع التيار الكهربائي.',
    architectureDetailsEn: 'Fault-tolerant offline desktop system utilizing C# .NET, local SQL Server instance, and automated background transaction logging to prevent power-failure data corruption.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'nabdh_hms',
    titleAr: 'نبض المشافي — نظام إدارة المستشفيات والملفات الطبية بـ C# و.NET',
    titleEn: 'Nabdh Hospital Information & EMR System (C# .NET)',
    taglineAr: 'منظومة السجلات الطبية الإلكترونية، غرف العمليات، التنويم، ومختبرات التحاليل',
    taglineEn: 'Integrated Electronic Medical Records (EMR), bed occupancy, and laboratory suite',
    descriptionAr: 'منظومة صحية شاملة لإدارة المستشفيات والمراكز التخصصية. تشمل استقبال المرضى، السجلات الطبية الإلكترونية (EMR)، إدارة أقسام التنويم والعمليات، وحجز المواعيد، وربط نتائج المختبرات والأشعة.',
    descriptionEn: 'A full-scale hospital management information system (HMIS) built with C# ASP.NET Core and SQL Server, orchestrating inpatient beds, outpatient clinics, surgical theaters, and laboratory diagnostics.',
    technologies: ['C# .NET 8', 'ASP.NET Core', 'SQL Server', 'React.js', 'SignalR Real-time', 'HL7 / FHIR Standards'],
    category: 'system',
    imageUrl: '/assets/projects/nabdh_hms.svg',
    featuresAr: [
      'سجل طبي إلكتروني موحد لكل مريض يشمل التاريخ المرضي والوصفات والتشخيصات والتحاليل',
      'خريطة بصرية تفاعلية لشواغر أسرّة المستشفى وأجنحة العناية المركزة بالزمن الفعلي',
      'نظام إدارة المختبرات مع إرسال النتائج للمرضى عبر بوابة إلكترونية ورسائل SMS',
      'حماية وتشفير عالي المستوى للبيانات الطبية وفق معايير الأمان الصحية'
    ],
    featuresEn: [
      'Unified EMR clinical history documenting diagnoses, allergies, and lab results',
      'Visual real-time bed management matrix across intensive care and general wards',
      'Laboratory information module with automated digital report delivery',
      'HIPAA-compliant encrypted data storage and role-partitioned medical auditing'
    ],
    architectureDetailsAr: 'هيكلية ويب مؤسسية تعتمد على واجهات ASP.NET Core Web API مع قاعدة بيانات SQL Server ضخمة مدعومة بخاصية SignalR لتحديث شاشات غرف الطوارئ والاستقبال فوراً.',
    architectureDetailsEn: 'Enterprise microservices backend using ASP.NET Core and SQL Server, utilizing SignalR WebSockets for zero-latency dashboard updates across emergency bays and triage desks.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'madrasati_plus',
    titleAr: 'مدرستي بلس — منصة الإدارة المدرسية والتعليم الإلكتروني التفاعلي',
    titleEn: 'Madrasati Plus — Smart School ERP & Interactive E-Learning',
    taglineAr: 'منظومة تعليمية ذكية تربط إدارة المدرسة والمعلمين والطلاب وأولياء الأمور',
    taglineEn: 'Connected school administration, grading ledger, and parent-teacher communication portal',
    descriptionAr: 'منصة ويب متكاملة لإدارة المدارس والمنشآت التعليمية تشمل شؤون الطلاب، الجداول المدرسية، رصد الدرجات التلقائي، متابعة الحضور والغياب، وبوابة تواصل مباشرة لأولياء الأمور.',
    descriptionEn: 'An integrated academic management and e-learning portal built with PHP Laravel and React.js, automating student enrollments, exam timetables, grade calculation, and direct parent notifications.',
    technologies: ['PHP 8.2', 'Laravel', 'MySQL', 'React.js', 'WebSockets', 'Tailwind CSS'],
    category: 'web',
    imageUrl: '/assets/projects/madrasati_plus.svg',
    featuresAr: [
      'إصدار الشهادات وكشوفات الدرجات الآلية مع حساب النسب والترتيب التلقائي',
      'تسجيل حضور الطلاب بالباركود وإرسال إشعار فوري لولي الأمر عند التأخر أو الغياب',
      'نظام واجبات واختبارات إلكترونية تفاعلية مع تصحيح فوري وتغذية راجعة',
      'إدارة الرسوم المدرسية والأقساط وفواتير الطلاب وسندات القبض'
    ],
    featuresEn: [
      'Automated transcript generation with dynamic GPA and rank distribution indices',
      'Barcode-driven attendance logging with instant SMS and WhatsApp triggers to guardians',
      'Interactive online quiz module with instant algorithmic grading and analytics',
      'Student tuition installment tracking with automated receipt generation and balance reminders'
    ],
    architectureDetailsAr: 'نظام MVC متقدم مبني بـ Laravel وMySQL مع واجهة تفاعلية بـ React.js، ونظام كاشنج سريع بـ Redis لتحمل دخول آلاف أولياء الأمور في وقت واحد أثناء إعلان النتائج.',
    architectureDetailsEn: 'Full-stack Laravel/MySQL architecture with React.js client interfaces, optimized with Redis caching to handle massive concurrent traffic spikes during grade publication days.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'academia_lms',
    titleAr: 'أكاديميا LMS — نظام إدارة التعليم الجامعي والدورات الافتراضية',
    titleEn: 'Academia Enterprise LMS — Virtual Campus & Courseware Engine',
    taglineAr: 'بيئة تعليمية سحابية متقدمة للمحاضرات المسجلة والبث الحي والشهادات الرقمية',
    taglineEn: 'Scalable university learning management platform with live lectures and digital credentialing',
    descriptionAr: 'منصة تعليم جامعي ومهني سحابية تدعم استضافة مساقات الفيديو، بنوك الأسئلة متعددة النماذج، حلقات النقاش، وتوليد الشهادات الرقمية المشفرة القابلة للتحقق عبر رمز QR.',
    descriptionEn: 'A high-concurrency learning management system catering to universities and training academies, delivering video-on-demand streaming, multi-tier quiz banks, and cryptographic QR-verified credentials.',
    technologies: ['React.js', 'PHP 8.2', 'MySQL', 'AWS S3 / HLS Video', 'REST API', 'Tailwind CSS'],
    category: 'web',
    imageUrl: '/assets/projects/academia_lms.svg',
    featuresAr: [
      'مشغل فيديو ذكي يدعم دقات متعددة (HLS Adaptive Streaming) وحماية المحتوى من التحميل غير المصرح به',
      'نظام اختبارات ذكي مع مانع الغش والتبديل بين التبويبات',
      'منح شهادات إتمام موثقة برمز QR ورقم تسلسلي فريد للتحقق الفوري',
      'لوحة تحكم للمحاضرين لمتابعة تقدم الطلاب ونسب الإنجاز والتفاعل'
    ],
    featuresEn: [
      'Adaptive bitrate video delivery (HLS) with digital watermarking against content piracy',
      'Proctored evaluation engine monitoring tab-switching and timed submissions',
      'Cryptographically signed certificates with instant QR public verification',
      'Instructor analytics measuring student engagement duration and assignment completion'
    ],
    architectureDetailsAr: 'معمارية بنية تحتية سحابية تفصل خوادم الوسائط والفيديو عن خادم واجهات برمجة التطبيقات PHP REST API لضمان استقرار الأداء وسلاسة التصفح.',
    architectureDetailsEn: 'Decoupled cloud architecture utilizing Amazon S3/CloudFront for media distribution and an optimized PHP/MySQL API cluster for session management.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'sadeed_invoicing',
    titleAr: 'سديد للفوترة — نظام الفوترة الإلكترونية ونقاط البيع السحابية',
    titleEn: 'Sadeed Electronic Invoicing & Cloud POS Suite',
    taglineAr: 'إصدار الفواتير الضريبية والمبسطة المتوافقة مع معايير هيئات الزكاة والضريبة والجمارك',
    taglineEn: 'Tax authority compliant electronic invoicing engine with cryptographic QR codes',
    descriptionAr: 'نظام محاسبي وفوترة إلكترونية متوافق مع متطلبات الفوترة الرسمية المشفرة (ZATCA Stage 1 & 2). يقوم بتوليد الفواتير بصيغ XML وPDF وتوقيعها رقمياً برمز QR مشفر بخوارزمية Base64 وECDSA.',
    descriptionEn: 'A certified e-invoicing and cloud POS solution producing tamper-proof tax invoices, credit notes, and debit notes formatted in UBL 2.1 XML with ECDSA digital cryptographic signatures.',
    technologies: ['PHP 8.2 OOP', 'MySQL', 'UBL 2.1 XML', 'ECDSA / SHA-256', 'React.js', 'REST API'],
    category: 'web',
    imageUrl: '/assets/projects/sadeed_invoicing.svg',
    featuresAr: [
      'توليد رموز QR مشفرة تحتوي على بيانات البائع، الرقم الضريبي، الختم الزمني، والمجاميع',
      'تصدير فواتير بصيغة XML UBL 2.1 المعتمدة ومطابقتها وفق الفحص التلقائي',
      'نظام نقاط بيع سحابي سريع يعمل على المتصفحات والأجهزة اللوحية',
      'إدارة ضريبة القيمة المضافة والإقرارات الضريبية الشهرية والربع سنوية'
    ],
    featuresEn: [
      'Cryptographic QR code encoding seller identity, VAT number, timestamp, and signature hash',
      'Automated UBL 2.1 XML schema compliance validation before invoice issuance',
      'Responsive cloud POS interface optimized for touchscreens and tablet terminals',
      'Periodic tax return ledger generation and audit-ready reporting'
    ],
    architectureDetailsAr: 'مبني بـ PHP 8.2 الصارمة مع استخدام مكتبات التشفير المتقدمة لتوليد هاشات SHA-256 وتخزين المعاملات في قاعدة بيانات MySQL محمية بعمليات التراجع (Transactions).',
    architectureDetailsEn: 'Engineered in strict PHP 8.2 leveraging OpenSSL for SHA-256 and ECDSA cryptographic hashing, backed by transactional MySQL ACID storage.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'masari_logistics',
    titleAr: 'مساري — تطبيق المندوبين وإدارة الشحن وتوزيع الطرود',
    titleEn: 'Masari — Parcel Logistics & Courier Dispatch Mobile Suite',
    taglineAr: 'تطبيق أندرويد متكامل لإدارة الشحنات، التوجيه الذكي للمندوبين، وإثبات التسليم الرقمي',
    taglineEn: 'Courier routing, last-mile parcel distribution, and digital proof-of-delivery application',
    descriptionAr: 'تطبيق أندرويد ولوحة تحكم سحابية لشركات الشحن والتوصيل. ينظم استلام الطرود وفرزها حسب المناطق الجغرافية، ويرشد المندوبين لأقصر الطرق، مع توثيق التسليم بالتوقيع الإلكتروني وصورة الطرد.',
    descriptionEn: 'A full-cycle courier and parcel dispatch system consisting of a high-performance Android mobile application and web dispatcher cockpit with real-time waypoint optimization and digital proof of delivery.',
    technologies: ['Android (Kotlin)', 'Flutter', 'PHP 8.2 REST', 'MySQL', 'Google Maps Platform', 'Firebase FCM'],
    category: 'mobile',
    imageUrl: '/assets/projects/masari_logistics.svg',
    featuresAr: [
      'توزيع تلقائي للطرود على المندوبين حسب النطاق الجغرافي وكثافة الوجهات',
      'ملاحة خطوة بخطوة وإرشاد صوتي للمندوبين عبر خرائط الطرق الحية',
      'إثبات التسليم الرقمي عبر التوقيع باللمس، والتقاط صورة للشحنة، والرمز السري OTP',
      'إشعارات فورية للعملاء برابط تتبع مباشر لتحركات المندوب على الخريطة'
    ],
    featuresEn: [
      'Algorithmic parcel clustering allocating shipments by geographic density and capacity',
      'Turn-by-turn navigation overlay with dynamic traffic waypoint optimization',
      'Multi-factor Proof-of-Delivery capturing digital touch signature, photo evidence, and OTP',
      'Real-time customer SMS webhook notifications with interactive live delivery tracking links'
    ],
    architectureDetailsAr: 'تطبيق أندرويد نيتف بلغة Kotlin مع معمارية MVVM وRoom Database للعمل في المناطق الوعرة وضعيفة التغطية، مع مزامنة خلفية تلقائية عند توفر شبكة الإنترنت.',
    architectureDetailsEn: 'Native Android Kotlin application architected on clean MVVM and offline-first Room persistence, syncing cached parcel states via background WorkManager workers.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'aman_microfinance',
    titleAr: 'أمان للتمويل الأصغر — نظام الحسابات المصرفية والقروض بـ Java Enterprise',
    titleEn: 'Aman Microfinance & Core Banking Ledger Engine (Java Enterprise)',
    taglineAr: 'منظومة مصرفية دقيقة لإدارة حسابات الادخار، التمويل الإسلامي، وجداول السداد',
    taglineEn: 'Transactional micro-banking ledger managing Islamic financing, savings, and amortization',
    descriptionAr: 'محرك مصرفي آمن مبني بلغة Java ومنصة Spring Boot لإدارة حسابات التمويل الأصغر ومؤسسات الإقراض الحسن. يوفر إدارة دقيقة لخطط الأقساط، حساب الأرباح، وتوثيق حركات الصناديق بدون أي هامش للخطأ.',
    descriptionEn: 'A mission-critical banking ledger engine developed with Java Enterprise and Spring Boot for micro-finance institutions. Features double-entry transaction posting, automated loan amortization, and strict compliance reporting.',
    technologies: ['Java 21', 'Spring Boot', 'PostgreSQL / MySQL', 'Hibernate ORM', 'Spring Security', 'Docker'],
    category: 'system',
    imageUrl: '/assets/projects/aman_microfinance.svg',
    featuresAr: [
      'محرك قيود مصرفية مزدوجة مع ضمان توازن الحسابات والتدقيق المحاسبي الصارم',
      'جدولة الأقساط الشهرية وحساب نسب السداد والفوائض وفق المعايير الشرعية',
      'سجل تدقيق أمني غير قابل للتعديل (Immutable Audit Trail) لجميع الحركات المالية',
      'تقارير المخاطر والتعثر المالي وتنبيهات الاستحقاق التلقائية عبر الرسائل'
    ],
    featuresEn: [
      'ACID-compliant double-entry ledger ensuring mathematical equilibrium across all accounts',
      'Automated loan amortization scheduling compliant with Islamic Murabaha standards',
      'Cryptographically sealed audit trail recording every debit and credit transaction',
      'Delinquency risk evaluation scoring and automated scheduled SMS payment reminders'
    ],
    architectureDetailsAr: 'معمارية بنية تحتية بنكية بـ Spring Boot تعتمد على عزل كامل لطبقات الأمان، وجلسات Stateless JWT، مع حماية المعاملات المالية عبر عزل المعاملات وقفل السجلات (Pessimistic Locking).',
    architectureDetailsEn: 'Enterprise Java Spring Boot microservice employing pessimistic database locks on balance transfers to prevent race conditions during high-volume ledger postings.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'smart_warehouse',
    titleAr: 'المستودع الذكي — نظام إدارة المخازن بالباركود وRFID بـ C# .NET',
    titleEn: 'Smart Warehouse — RFID & Barcode WMS Suite (C# .NET)',
    taglineAr: 'أتمتة إدارة المستودعات، التخزين المكاني، أجهزة القراءة اللاسلكية، والتتبع الآلي للأرفف',
    taglineEn: 'Automated warehouse management system with RFID zoning, bin locations, and handheld RF scanners',
    descriptionAr: 'برنامج لإدارة المستودعات الكبرى والمراكز اللوجستية طور بـ C# .NET. يوفر مسحاً سريعاً بالباركود وRFID، وتحديد مواقع البضائع على الأرفف (Bin Locations)، وإدارة أوامر الاستلام والفرز والشحن.',
    descriptionEn: 'An industrial warehouse management system (WMS) built with C# .NET Core, integrating handheld barcode terminals and fixed RFID gates for automated pallet tracking and bin-location optimization.',
    technologies: ['C# .NET Core', 'WPF', 'SQL Server', 'Zebra RFID SDK', 'Barcode / QR Reader API'],
    category: 'system',
    imageUrl: '/assets/projects/smart_warehouse.svg',
    featuresAr: [
      'خريطة بصرية للمستودع توضح توزيع الأرفف والممرات ونسب الامتلاء لكل موقع تخزين',
      'أتمتة جرد البضائع عبر أجهزة المسح اللاسلكية بنقرة واحدة دون إيقاف العمليات',
      'إدارة تواريخ الصلاحية ورقم التشغيلة (Batch Number) للأصناف الحساسة',
      'إصدار أذونات الصرف والإضافة وتتبع مسار كل كرتون من الاستلام حتى التسليم'
    ],
    featuresEn: [
      'Interactive 2D spatial warehouse layout mapping bin coordinates and aisle occupancy',
      'Instant continuous inventory cycle counting via ruggedized wireless RF scanner terminals',
      'Lot and batch traceability enabling targeted product recall and shelf-life rotation',
      'Automated dispatch and receiving manifests integrated with shipping carrier APIs'
    ],
    architectureDetailsAr: 'تطبيق سطح مكتب قوي وسريع بـ WPF مع بروتوكولات اتصال TCP/IP مع أجهزة المسح اللاسلكية، وتخزين مؤقت للعمليات المحلية في حال انقطاع الشبكة.',
    architectureDetailsEn: 'High-performance WPF client application interfacing via socket protocols with Zebra handheld terminals, backed by a robust SQL Server transactional repository.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'autocare_pro',
    titleAr: 'أوتو كار — نظام إدارة مراكز صيانة السيارات وقطع الغيار بـ C# .NET',
    titleEn: 'AutoCare Pro — Automotive Workshop & Parts ERP (C# .NET)',
    taglineAr: 'إدارة كروت الصيانة، فحص المركبات، قطع الغيار، وفواتير الورش ومراكز الصيانة',
    taglineEn: 'Automotive service center management, vehicle job cards, parts stock, and technician billing',
    descriptionAr: 'نظام متكامل لمراكز صيانة وخدمات السيارات ووكالات قطع الغيار. يدير دورة دخول المركبة، فتح كرت الصيانة، فحص الأعطال، صرف قطع الغيار من المستودع، واحتساب أجور الفنيين بدقة.',
    descriptionEn: 'A specialized automotive service and repair shop software suite developed in C# .NET. Manages intake job cards, diagnostic checklists, inventory requisition, and automated mechanic commission tracking.',
    technologies: ['C# .NET', 'Windows Forms / DevExpress', 'SQL Server', 'SMS Notification API', 'Barcode Engine'],
    category: 'system',
    imageUrl: '/assets/projects/autocare_pro.svg',
    featuresAr: [
      'سجل تاريخي لكل مركبة برقم الهيكل (VIN) يوضح كافة الصيانات والقطع المستبدلة السابقة',
      'إصدار كروت صيانة إلكترونية مع تحديد الفنيين المسؤولين ومراحل الإصلاح',
      'إدارة متجر قطع الغيار بالباركود وربط أسعار الشراء والبيع وهامش الربح',
      'إرسال رسائل SMS تلقائية للعميل عند اكتمال صيانة السيارة وجاهزيتها للاستلام'
    ],
    featuresEn: [
      'Vehicle VIN master dossier archiving historical maintenance visits, parts, and mechanic notes',
      'Digital technician job cards tracking repair stages, estimated hours, and labor costs',
      'Parts inventory management with barcode scanning, supplier cross-referencing, and margin controls',
      'Automated customer SMS alerts triggering upon inspection completion and final vehicle release'
    ],
    architectureDetailsAr: 'تطبيق C# سطحي متكامل بواجهات DevExpress الحديثة، متصل بقاعدة بيانات SQL Server مركزية ومزود بنظام حماية صلاحيات يعزل الفنيين عن المحاسبين والمديرين.',
    architectureDetailsEn: 'Enterprise Windows desktop application built with C# and DevExpress controls, connecting to an on-premise SQL Server with strict role segmentation.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'fondokey_pms',
    titleAr: 'فندقي — نظام إدارة الفنادق والمنتجعات والحجوزات الفندقية',
    titleEn: 'Fondokey PMS — Hotel & Resort Property Management System',
    taglineAr: 'إدارة غرف الفنادق، النزلاء، الحجوزات السريعة، وخدمات الضيافة والفواتير',
    taglineEn: 'Full hospitality property management, room dispatch, folio billing, and guest services',
    descriptionAr: 'منظومة فندقية سحابية متقدمة لإدارة الفنادق والشقق المفروشة. تتيح حجز الغرف، تسجيل وصول النزلاء وسحب بيانات الجوازات والبطاقات، وإدارة خدمات الغرف، وتصدير التقارير السياحية والأمنية.',
    descriptionEn: 'A comprehensive hotel property management platform engineered with PHP 8.2 and React.js, orchestrating front-desk check-in, housekeeping dispatch, guest folios, and tourism compliance manifests.',
    technologies: ['PHP 8.2 MVC', 'MySQL', 'React.js', 'Tailwind CSS', 'PDF Engine', 'REST API'],
    category: 'web',
    imageUrl: '/assets/projects/fondokey_pms.svg',
    featuresAr: [
      'شاشة استيعاب فندقية بصرية تعرض حالة الغرف (شاغرة، مشغولة، صيانة، نظافة) بالألوان',
      'تسجيل وصول ومغادرة سريع (Fast Check-in/out) مع طباعة كروت المفاتيح والإيصالات',
      'نظام فواتير النزلاء الشامل (Guest Folio) الذي يجمع إيجار الغرفة والمطعم والمغسلة',
      'إدارة كادر النظافة والصيانة وتحديث حالة الغرفة فورياً من الهواتف المحمولة'
    ],
    featuresEn: [
      'Interactive visual room matrix displaying real-time occupancy, cleanliness, and maintenance states',
      'Rapid guest registration with identity document capture and folio balance aggregation',
      'Unified guest billing combining room charges, room service dining, and laundry services',
      'Mobile-responsive housekeeping portal allowing cleaners to mark rooms ready in real time'
    ],
    architectureDetailsAr: 'معمارية بنظام PHP MVC قوي وقاعدة بيانات MySQL تدعم تعدد الفنادق والفروع، مع واجهة أمامية عصرية بـ React ومزامنة فورية لحالات الغرف.',
    architectureDetailsEn: 'Multi-property PHP 8.2 MVC architecture paired with an optimized relational MySQL schema, powering high-throughput React front-desk dashboards.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'emdad_b2b',
    titleAr: 'إمداد B2B — منصة التوريد وسلاسل الإمداد الغذائية بالجملة',
    titleEn: 'Emdad B2B — Wholesale FMCG Supply Chain Platform',
    taglineAr: 'ربط مصانع ومستوردي المواد الغذائية بالبقالات ومتاجر التجزئة بأسعار الجملة',
    taglineEn: 'Wholesale marketplace connecting FMCG importers and manufacturers with retail merchants',
    descriptionAr: 'منصة تجارة إلكترونية B2B وسلاسل إمداد متطورة تمكن تجار التجزئة والبقالات من طلب المواد الغذائية والاستهلاكية بأسعار الجملة مباشرة من المستوردين والمصانع، مع جدولة التوصيل وخطوط الائتمان.',
    descriptionEn: 'An enterprise B2B e-commerce platform built with PHP Laravel and React.js, facilitating high-volume wholesale purchasing, deferred trade credit, and scheduled pallet deliveries for retail grocers.',
    technologies: ['PHP Laravel', 'MySQL', 'React.js', 'Redux Toolkit', 'Tailwind CSS', 'REST API'],
    category: 'web',
    imageUrl: '/assets/projects/emdad_b2b.svg',
    featuresAr: [
      'كتالوج بأسعار جملة متغيرة حسب كمية الطلب وفئة التاجر والمنطقة الجغرافية',
      'نظام إدارة التسهيلات الائتمانية والدفع الآجل مع متابعة حدود الائتمان وسجل السداد',
      'جدولة خطوط الشحن والتوزيع عبر أساطيل الشاحنات وتوليد بوالص التحميل الآلية',
      'لوحة تحكم للموردين لمتابعة أوامر الشراء اليومية وإدارة الكميات المتوفرة'
    ],
    featuresEn: [
      'Tiered bulk wholesale pricing dynamically adjusting based on order volume and buyer grade',
      'Merchant trade credit ledger monitoring payment schedules and credit limits',
      'Fleet loading manifest optimization grouping delivery routes by cargo temperature and zone',
      'Supplier command center tracking bulk purchase orders and low-stock replenishment'
    ],
    architectureDetailsAr: 'مبني بـ Laravel وReact.js مع معمارية موجهة بالخدمات (Service-Oriented Architecture) لضمان سرعة معالجة الفواتير الكبيرة وتكاملها مع برامج المحاسبة الخارجية.',
    architectureDetailsEn: 'Enterprise Laravel REST API architecture integrated with a reactive React frontend and background queue workers handling PDF invoice batches and ledger updates.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'sanad_realestate',
    titleAr: 'سند العقاري — منصة إدارة العقارات والأملاك والوساطة العقارية',
    titleEn: 'Sanad Real Estate MLS & Property Management Portal',
    taglineAr: 'إدارة عقود الإيجار، تحصيل الإيجارات، فحص العقارات، وبوابة تسويق العقارات',
    taglineEn: 'Comprehensive property listing MLS, automated lease contract generation, and rent collection',
    descriptionAr: 'منصة رقمية للمكاتب والشركات العقارية والملاك لإدارة العقارات والمجمعات السكنية والتجارية. تتيح إبرام عقود الإيجار، تذكير المستأجرين بمواعيد السداد، وتسويق العقارات مع خريطة تفاعلية.',
    descriptionEn: 'A high-grade real estate portal and property management suite built with React and PHP. Manages tenant lease agreements, recurring rent collections, building maintenance tickets, and interactive GIS listings.',
    technologies: ['React.js', 'PHP 8.2', 'MySQL', 'Leaflet GIS Maps', 'PDF Generation API', 'Tailwind CSS'],
    category: 'web',
    imageUrl: '/assets/projects/sanad_realestate.svg',
    featuresAr: [
      'بحث عقاري ذكي ومتقدم بالخريطة الجغرافية مع تصفية حسب الحي والسعر والمساحة',
      'توليد عقود إيجار موحدة وتوثيقها بصيغة PDF مع الحساب التلقائي للضرائب وعمولات السعي',
      'نظام تنبيهات دوري بالدفعات المتأخرة وإشعارات السداد عبر الواتساب والرسائل',
      'بوابة خاصة للمستأجرين لرفع طلبات الصيانة ومتابعة الفواتير السابقة'
    ],
    featuresEn: [
      'Interactive geospatial property locator with polygon neighborhood filters and price overlays',
      'Automated standardized lease contract generation in signed PDF formats with payment schedules',
      'Automated delinquency notifications delivering SMS and WhatsApp reminder webhooks',
      'Tenant self-service portal for submitting maintenance repair tickets and downloading receipts'
    ],
    architectureDetailsAr: 'نظام متكامل بواجهة أمامية حديثة بـ React.js وخادم PHP 8.2 آمن مدعوم بمحرك بحث جيوغرافي سريع لحساب المسافات الجغرافية وإيجاد العقارات الأقرب بدقة.',
    architectureDetailsEn: 'Modern React SPA backed by an optimized PHP/MySQL geospatial backend calculating coordinate radii for immediate location-based property queries.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'reaya_telehealth',
    titleAr: 'رعاية هيلث — تطبيق الاستشارات الطبية وحجز العيادات عن بعد بـ Android',
    titleEn: 'Reaya Telehealth — Mobile Telemedicine & Doctor Consultation App',
    taglineAr: 'استشارات طبية بالفيديو، حجز مواعيد الأطباء، ومتابعة الوصفات والملف الصحي',
    taglineEn: 'HIPAA-compliant video consultations, specialist appointment booking, and digital prescriptions',
    descriptionAr: 'تطبيق أندرويد يربط المرضى بنخبة من الأطباء والاستشاريين في مختلف التخصصات. يوفر استشارات طبية مرئية عبر مكالمات الفيديو المشفرة، حجز المواعيد في العيادات، وسجل الوصفات والفحوصات.',
    descriptionEn: 'A secure mobile telemedicine platform developed for Android using Kotlin and WebRTC. Connects patients with verified physicians for encrypted video consultations, electronic prescriptions, and appointment booking.',
    technologies: ['Android (Kotlin)', 'WebRTC Video', 'PHP REST API', 'MySQL', 'Firebase FCM', 'Material 3'],
    category: 'mobile',
    imageUrl: '/assets/projects/reaya_telehealth.svg',
    featuresAr: [
      'مكالمات فيديو وصوت مشفرة طرف إلى طرف (End-to-End Encrypted) بتقنية WebRTC',
      'حجز مواعيد العيادات مع اختيار اليوم والساعة ونوع الكشف والتذكير التلقائي',
      'إصدار الروشتة الإلكترونية (e-Prescription) المعتمدة فور انتهاء الاستشارة',
      'ملف صحي للمريض لحفظ نتائج التحاليل وصور الأشعة والتقارير الطبية السابقة'
    ],
    featuresEn: [
      'Peer-to-peer encrypted HD video and audio telemedicine sessions powered by WebRTC protocols',
      'Physician availability calendar with real-time slot locking and automated appointment alarms',
      'Certified electronic prescription issuance with instant printable PDF and pharmacy sharing',
      'Personal health vault archiving diagnostic lab reports, imaging scans, and immunization history'
    ],
    architectureDetailsAr: 'تطبيق أندرويد نيتف بهيكلية Clean Architecture ومكتبات Jetpack، مع وسيط خادم PHP REST API للتحكم بالجلسات وإشارات WebRTC وإشعارات Firebase.',
    architectureDetailsEn: 'Native Android Kotlin application built with Clean Architecture, leveraging WebRTC signaling servers and a secure PHP/MySQL patient records API.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'sarraf_exchange',
    titleAr: 'صرّاف برو — نظام إدارة شركات الصرافة والتحويلات المالية بـ C# .NET',
    titleEn: 'Sarraf Pro — Currency Exchange & Financial Remittance System (C# .NET)',
    taglineAr: 'إدارة عمليات بيع وشراء العملات، الحوالات الصادرة والواردة، وسعر الصرف اللحظي',
    taglineEn: 'Foreign exchange trading desk, intercity money remittance, and AML compliance ledger',
    descriptionAr: 'منظومة مالية مصرفية عالية الدقة طُورت بـ C# .NET لشركات الصرافة وشبكات التحويلات المالية. تدير أسعار صرف العملات اللحظية، وتوثيق الحوالات الصادرة والواردة، ومراقبة السيولة النقدية في الخزائن.',
    descriptionEn: 'A mission-critical financial software suite engineered with C# .NET and MS SQL Server for currency exchange firms and money transfer operators. Features live exchange rate arbitration, remittance escrow, and compliance reporting.',
    technologies: ['C# .NET 8', 'WPF', 'MS SQL Server', 'Live Forex Rates API', 'Thermal Printing', 'SMS Gateway'],
    category: 'system',
    imageUrl: '/assets/projects/sarraf_exchange.svg',
    featuresAr: [
      'شاشة صرافة فائقة السرعة لتنفيذ عمليات البيع والشراء بالعملات الأجنبية مع حساب الأرباح آلياً',
      'إصدار واستلام الحوالات المالية برمز سري مشفر وإرسال رسالة SMS فورية للمستلم',
      'إدارة حركة الخزائن والصناديق النقدية بالعملات المختلفة مع جرد دقيق في نهاية الوردية',
      'سجل الامتثال ومكافحة غسيل الأموال وتنبيهات العمليات الكبيرة أو المشبوهة'
    ],
    featuresEn: [
      'Ultra-fast foreign exchange teller desk executing multi-currency buy/sell orders with live margin calculation',
      'Secure remittance issuance generating cryptographically masked transfer codes and SMS delivery alerts',
      'Multi-currency cash drawer reconciliation tracking teller balances at shift handover',
      'Automated Anti-Money Laundering (AML) monitoring detecting structured or suspicious transactions'
    ],
    architectureDetailsAr: 'نظام سطحي مبني بـ C# WPF مع استخدام التشفير العسكري لبيانات الحوالات، وقاعدة بيانات SQL Server مركزية مدعومة بأنظمة النسخ الاحتياطي اللحظي والاتصال الآمن عبر بروتوكولات TLS.',
    architectureDetailsEn: 'Enterprise WPF application enforcing AES-256 field encryption for remittance PINs, backed by high-availability SQL Server clustering with instantaneous failover.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'maahad_tech',
    titleAr: 'معهد تك — منصة إدارة المراكز التدريبية والشهادات الرقمية',
    titleEn: 'Maahad Tech — Training Academy ERP & Digital Credentials Portal',
    taglineAr: 'تسجيل المتدربين، جداول الدورات، القاعات التدريبية، وإصدار الشهادات المعتمدة بـ QR',
    taglineEn: 'Vocational training management, instructor scheduling, and tamper-proof digital certificates',
    descriptionAr: 'نظام سحابي شامل للمراكز التعليمية والمعاهد المهنية والتدريبية. يدير تسجيل المتدربين، توزيعهم على القاعات، متابعة الحضور، التقييم العملي، وإصدار شهادات التخرج الرقمية المحمية برمز QR.',
    descriptionEn: 'A streamlined academy management and digital certification portal built with PHP 8.2 and React.js, automating course enrollments, classroom utilization, attendance badges, and verifiable student diplomas.',
    technologies: ['PHP 8.2', 'MySQL', 'React.js', 'FPDF Certificate Engine', 'Tailwind CSS', 'REST API'],
    category: 'web',
    imageUrl: '/assets/projects/maahad_tech.svg',
    featuresAr: [
      'توليد وطباعة الشهادات المهنية المعتمدة بتصاميم أنيقة مع رمز QR للتحقق السريع من صحتها عبر الإنترنت',
      'بوابة تسجيل وقبول للطلاب مع سداد الرسوم بالأقساط وطباعة سندات القبض',
      'إدارة المدربين وتوزيع قاعات التدريب وساعات العمل وتقييم المتدربين للدورات',
      'متابعة الحضور والغياب اليومي مع إصدار كشوفات درجات وتقارير إحصائية دورية'
    ],
    featuresEn: [
      'High-resolution PDF certificate generation stamped with public QR verification URLs',
      'Online student enrollment portal supporting tuition installment schedules and automated receipts',
      'Instructor assignment and classroom scheduling preventing overlapping course bookings',
      'Attendance tracking with automated minimum-threshold checks required for course graduation'
    ],
    architectureDetailsAr: 'تطبيق ويب متكامل بـ PHP MVC وReact.js، مع محرك لتوليد مستندات PDF الموجهة بالبيانات ومكتبة تشفير لإنشاء توقيعات إلكترونية للشهادات تمنع تزويرها.',
    architectureDetailsEn: 'Robust PHP 8.2 MVC architecture paired with dynamic React components, utilizing custom server-side vector PDF composition for high-fidelity certificate rendering.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'fastcart_mall',
    titleAr: 'متجر فاست — منصة التجارة الإلكترونية متعددة التجار بـ React وPHP',
    titleEn: 'FastCart Multi-Vendor E-Commerce Marketplace',
    taglineAr: 'سوق إلكتروني متكامل يتيح للبائعين فتح متاجرهم وإدارة المنتجات والمبيعات',
    taglineEn: 'Multi-vendor e-commerce platform with dedicated merchant stores and split payments',
    descriptionAr: 'منصة تجارة إلكترونية متعددة البائعين (Multi-Vendor Marketplace) تتيح للتجار والشركات عرض وبيع منتجاتهم، مع نظام سلة موحد، تقسيم العوائد والعمولات آلياً، وتتبع الشحنات حتى باب العميل.',
    descriptionEn: 'An enterprise-scale multi-vendor marketplace built with React and PHP Laravel. Features individual merchant storefronts, automated commission splitting, multi-carrier tracking, and multi-currency checkouts.',
    technologies: ['React.js', 'PHP Laravel', 'MySQL', 'Redux Toolkit', 'Stripe / Local Wallets', 'Tailwind CSS'],
    category: 'web',
    imageUrl: '/assets/projects/fastcart_mall.svg',
    featuresAr: [
      'لوحة تحكم خاصة لكل تاجر لإدارة المنتجات، المخزون، الأسعار، ومتابعة الأرباح والطلبات',
      'سلة تسوق موحدة تدعم شراء منتجات من عدة بائعين في عملية دفع واحدة مع تقسيم الدفع تلقائياً',
      'نظام تقييم ومراجعات موثق للمنتجات والبائعين يمنع التقييمات الوهمية',
      'دعم الدفع عبر المحافظ الإلكترونية، البطاقات البنكية، وخيار الدفع عند الاستلام'
    ],
    featuresEn: [
      'Vendor management portal for cataloging inventory, setting discounts, and requesting payouts',
      'Unified multi-vendor checkout with automated escrow commission distribution',
      'Verified customer review engine restricting feedback to confirmed product purchasers',
      'Flexible payment gateway supporting card processing, local mobile money, and cash-on-delivery'
    ],
    architectureDetailsAr: 'بنية برمجية حديثة تفصل الواجهة التفاعلية React عن خادم Laravel REST API، مع دعم التخزين السحابي لصور المنتجات ومحرك بحث وفلترة عالي السرعة بـ MySQL Full-Text Search.',
    architectureDetailsEn: 'Headless e-commerce architecture utilizing React SPA and Laravel API, optimized with indexing and caching to deliver sub-second search and product filtering.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'homam_legal',
    titleAr: 'هُمام للمحاماة — نظام إدارة مكاتب المحاماة والقضايا والتوكيلات',
    titleEn: 'Homam Legal Practice & Judicial Case Management System',
    taglineAr: 'أرشفة ملفات القضايا، مواعيد الجلسات، التوكيلات، وحساب الأتعاب والمصروفات',
    taglineEn: 'Court session calendaring, legal litigation docketing, and client retainer accounting',
    descriptionAr: 'نظام إداري وقانوني متخصص لمكاتب المحاماة والاستشارات القانونية. ينظم ملفات القضايا، مواعيد جلسات المحاكم، صحائف الدعاوى والمذكرات، التوكيلات، وحسابات أتعاب الموكلين بدقة وسرية تامة.',
    descriptionEn: 'A confidential legal practice management platform engineered with PHP and React. Organizes judicial case dockets, court appearance hearings, legal document drafts, client retainers, and billing hours.',
    technologies: ['PHP 8.2 MVC', 'MySQL', 'React.js', 'Document Encryption Engine', 'Tailwind CSS'],
    category: 'system',
    imageUrl: '/assets/projects/homam_legal.svg',
    featuresAr: [
      'سجل شامل لكل قضية يوثق رقم الدعوى، الدائرة القضائية، القاضي، الخصوم، ومراحل التقاضي',
      'تقويم جلسات ذكي يرسل تنبيهات مسبقة بمواعيد الجلسات وفترات الطعن القانونية المحددة باليوم',
      'أرشيف إلكتروني مشفر للمستندات والعرائض والأحكام القضائية مع إمكانية البحث السريع',
      'إدارة أتعاب المحاماة والدفعات المالية والمصروفات القضائية وإصدار كشوفات الحساب'
    ],
    featuresEn: [
      'Comprehensive litigation docket tracking case numbers, judicial circuits, opponents, and appeal stages',
      'Intelligent court hearing calendar delivering proactive deadline alerts for judicial appeals',
      'Encrypted digital filing repository archiving court judgments, contracts, and evidence submissions',
      'Client retainer management calculating hourly billing, court expenses, and invoice statements'
    ],
    architectureDetailsAr: 'مبني وفق مبادئ الخصوصية التامة والتشفير، حيث يتم تشفير المستندات الحساسة بقاعدة بيانات MySQL واستخدام نظام صلاحيات صارم يمنع وصول غير المصرح لهم لملفات القضايا.',
    architectureDetailsEn: 'Security-hardened PHP 8.2 MVC platform featuring AES-256 encrypted document attachments and granular access privilege controls protecting legal privilege.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'sharyan_bloodbank',
    titleAr: 'شريان — شبكة التبرع بالدم وربط بنوك الدم في الطوارئ بـ Android',
    titleEn: 'Sharyan — Emergency Blood Bank & Donor Network (Android)',
    taglineAr: 'تطبيق إنساني ذكي لربط المستشفيات والمتبرعين بالدم جغرافياً في الحالات الحرجة',
    taglineEn: 'Geofenced blood donor matching, hospital blood inventory, and urgent emergency alerts',
    descriptionAr: 'تطبيق أندرويد ومنظومة سحابية تربط بنوك الدم في المستشفيات بالمتبرعين المتطوعين. يقوم بإرسال إشعارات طارئة للمتبرعين المتواجدين بالقرب من المستشفى عند الحاجة لفصائل دم نادرة لإنقاذ الأرواح.',
    descriptionEn: 'A life-saving mobile platform developed for Android that links hospital blood banks with voluntary registered donors. Dispatches geofenced emergency alerts to compatible donors nearby when critical blood shortages occur.',
    technologies: ['Android (Kotlin)', 'PHP REST API', 'MySQL', 'Firebase Cloud Messaging', 'Leaflet / Geolocation'],
    category: 'mobile',
    imageUrl: '/assets/projects/sharyan_bloodbank.svg',
    featuresAr: [
      'خوارزمية مطابقة فصائل الدم الطارئة وتحديد المتبرعين المؤهلين في محيط المستشفى',
      'إرسال إشعارات استغاثة فورية بالصوت والصورة للمتبرعين المتواجدين على مسافة قريبة',
      'لوحة تحكم للمستشفيات لإدارة مخزون أكياس الدم وتواريخ الصلاحية والفصائل المتوفرة',
      'سجل تبرع شخصي للمتطوع مع احتساب الفترة الموصى بها بين التبرع والآخر طبياً'
    ],
    featuresEn: [
      'Blood type compatibility algorithm matching urgent hospital requisitions with eligible registered donors',
      'High-priority geofenced push notifications targeting voluntary donors within a specific kilometer radius',
      'Hospital dashboard tracking blood bag inventory counts, component types, and expiry dates',
      'Personal donor profile recording donation history and calculating medical waiting intervals before next donation'
    ],
    architectureDetailsAr: 'تطبيق أندرويد بلغة Kotlin متصل بخادم PHP REST API عالي الاستجابة مع قاعدة بيانات مخصصة للحسابات الجغرافية (Spatial Indexing) لسرعة استخراج المتبرعين الأقرب خلال ثوانٍ.',
    architectureDetailsEn: 'Native Android Kotlin client communicating with a geospatial PHP/MySQL backend utilizing spatial indexes to query nearest compatible donors in sub-second latency.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'matbakhi_kds',
    titleAr: 'مطبخي POS & KDS — نظام نقاط بيع المطاعم وشاشات المطابخ التفاعلية',
    titleEn: 'Matbakhi Cloud POS & Kitchen Display System (KDS)',
    taglineAr: 'إدارة طلبات الطاولات، التوصيل، نقاط البيع السريعة، وشاشات تجهيز الطعام في المطبخ',
    taglineEn: 'Restaurant table ordering, waiter handhelds, kitchen display timing, and thermal receipt routing',
    descriptionAr: 'نظام متكامل للمطاعم والكافيهات يشمل نقاط البيع (POS)، وتطبيق النوادل لطلب الطاولات، وشاشات المطبخ الذكية (KDS) لتجهيز الأطباق وتحديد أوقات التحضير، مع طابعات الأقسام الحرارية.',
    descriptionEn: 'A modern restaurant point-of-sale and kitchen display system (KDS) built with C# .NET and Flutter. Streamlines table orders, waiter handhelds, kitchen prep line timing, and split bill payments.',
    technologies: ['C# .NET Core', 'Flutter', 'WebSockets', 'SQL Server', 'Thermal Printer ESC/POS'],
    category: 'system',
    imageUrl: '/assets/projects/matbakhi_kds.svg',
    featuresAr: [
      'خريطة بصرية للطاولات توضح حالة كل طاولة (شاغرة، مشغولة، قيد المحاسبة) مع دمج وتقسيم الفواتير',
      'شاشات مطبخ تفاعلية (KDS) تعرض الطلبات لحظياً مع توقيت إعداد كل صنف وتنبيهات التأخير',
      'طباعة آلية للأصناف على طابعات المطبخ والأفران والشواء فور تأكيد النادل للطلب',
      'إدارة مكونات الوجبات وحساب تكلفة الوجبة (Food Cost) والخصم التلقائي من المخزون'
    ],
    featuresEn: [
      'Visual interactive floor plan representing table occupancy, split checks, and dining durations',
      'Real-time Kitchen Display System (KDS) showing pending tickets with color-coded prep timing counters',
      'Automated multi-printer routing sending kitchen tickets to grill, salad, and beverage stations simultaneously',
      'Recipe ingredient mapping calculating food cost and automatically deducting raw stock per order'
    ],
    architectureDetailsAr: 'نظام هجين يدمج استقرار برمجيات C# .NET ونقاط البيع السريعة مع تطبيقات Flutter اللوحية للنوادل وشاشات KDS المتصلة عبر شبكة داخلية بدون الحاجة للإنترنت.',
    architectureDetailsEn: 'Hybrid architecture combining an on-premise C# .NET server with Flutter tablets over a local WebSocket network, guaranteeing uninterrupted service even during Internet outages.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'rowad_incubator',
    titleAr: 'روّاد — منصة متابعة المشاريع الريادية وحاضنات الأعمال',
    titleEn: 'Rowad — Startup Incubator & Venture Milestone Tracker',
    taglineAr: 'إدارة مسرعات الأعمال، تقييم الشركات الناشئة، ومتابعة مراحل النمو وجولات الاستثمار',
    taglineEn: 'Venture capital and incubator pipeline managing startup milestones, mentorship, and funding stages',
    descriptionAr: 'منصة ويب للمؤسسات التنموية وحاضنات ومسرعات الأعمال لإدارة طلبات احتضان المشاريع الريادية، وتقييم الجدوى الاقتصادية، وتوزيع الإرشاد وتتبع مراحل تقدم الشركات الناشئة.',
    descriptionEn: 'An incubator management and venture tracking web portal engineered with React and PHP. Manages cohort admissions, mentor matching, milestone KPI evaluations, and pitch deck archives.',
    technologies: ['React.js', 'PHP 8.2', 'MySQL', 'Chart.js / Analytics', 'Tailwind CSS', 'REST API'],
    category: 'web',
    imageUrl: '/assets/projects/rowad_incubator.svg',
    featuresAr: [
      'نظام تقديم وتقييم المشاريع الريادية عبر لجان تحكيم متخصصة ونماذج تقييم معيارية',
      'لوحات مؤشرات أداء (KPIs) لمتابعة نمو المبيعات وعدد العملاء لكل شركة ناشئة محتضنة',
      'جدولة جلسات الإرشاد وتوثيق مخرجات الاستشارات بين المرشدين ورواد الأعمال',
      'مستودع آمن لملفات عروض الاستثمار (Pitch Decks) ودراسات الجدوى المالية'
    ],
    featuresEn: [
      'Structured application pipeline with multi-judge rubric scoring and acceptance workflows',
      'Interactive executive KPI telemetry tracking revenue growth and user acquisition metrics per venture',
      'Mentorship booking calendar logging consultation action items and founder feedback',
      'Secure dataroom hosting investor pitch decks, cap tables, and financial model spreadsheets'
    ],
    architectureDetailsAr: 'تطبيق ويب متكامل بواجهات React.js تفاعلية ورسوم بيانية ديناميكية، مع خادم PHP 8.2 لمعالجة البيانات وتوفير حماية كاملة للملفات والدراسات الاستثمارية.',
    architectureDetailsEn: 'Modular React.js single-page application integrating interactive Chart.js visualizations with a transactional PHP/MySQL backend.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'solartrack_iot',
    titleAr: 'طاقة سولار — نظام مراقبة وتحليل كفاءة منظومات الطاقة الشمسية',
    titleEn: 'SolarTrack — IoT Photovoltaic Monitoring & Yield Analytics',
    taglineAr: 'قراءة وتحليل إنتاج الألواح والبطاريات، التنبؤ بالأعطال، وتنبيهات تفريغ الطاقة',
    taglineEn: 'Real-time solar inverter telemetry, battery health forecasting, and load management',
    descriptionAr: 'منظومة إنترنت الأشياء (IoT) وتحليل البيانات لمراقبة محطات ومنظومات الطاقة الشمسية المنزلية والتجارية. تجمع قراءات الجهد والتيار ودرجة الحرارة، وتقدم تحليلات بيانية لأداء البطاريات والألواح.',
    descriptionEn: 'An IoT telemetry analytics platform developed with Python and React. Collects live sensor readings from solar charge controllers and inverters, delivering predictive battery health analytics and energy yield dashboards.',
    technologies: ['Python', 'MQTT Protocol', 'React.js', 'MySQL', 'FastAPI / PHP Telemetry', 'Chart.js'],
    category: 'ai',
    imageUrl: '/assets/projects/solartrack_iot.svg',
    featuresAr: [
      'لوحة قيادة حية تعرض إنتاج الألواح اللحظي (واط/كيلوواط) ومستوى شحن البطاريات بالزمن الفعلي',
      'تنبيهات تلقائية فورية عند انخفاض جهد البطاريات إلى المستويات الحرجة أو ارتفاع درجة الحرارة',
      'حسابات إحصائية لمقارنة الإنتاج الفعلي بالمتوقع وتحديد نسب الفاقد والغبار على الألواح',
      'تطبيق متوافق مع كافة مقاسات الشاشات والهواتف لمتابعة المنظومة عن بعد'
    ],
    featuresEn: [
      'Live energy production telemetry monitoring instantaneous wattage, amps, and battery state of charge',
      'Automated threshold alarms dispatching warnings during battery low-voltage or thermal stress events',
      'Historical yield modeling calculating soiling degradation loss and photovoltaic efficiency curves',
      'Responsive web visualizer providing remote diagnostics from any smartphone or tablet'
    ],
    architectureDetailsAr: 'معمارية هجينة تجمع بين وسيط MQTT لاستقبال حزم البيانات من حساسات ESP32، ومحرك معالجة بلغة Python، مع واجهة أمامية عصرية بـ React.js لعرض المخططات البيانية اللحظية.',
    architectureDetailsEn: 'Distributed IoT architecture utilizing MQTT message brokers for hardware sensor ingestion, paired with Python processing pipelines and React streaming visualizers.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'albayan_hr',
    titleAr: 'البيان HR — نظام إدارة شؤون الموظفين والرواتب والبصمة بـ C# .NET',
    titleEn: 'Al-Bayan HR — Human Resources, Payroll & Biometrics Suite (C# .NET)',
    taglineAr: 'أتمتة الحضور والانصراف بأجهزة البصمة، مسيرات الرواتب، الإجازات، ومكافأة نهاية الخدمة',
    taglineEn: 'Automated biometric attendance integration, payroll disbursement, and labor law compliance',
    descriptionAr: 'نظام متكامل لإدارة الموارد البشرية وشؤون الموظفين طُور بـ C# .NET. يرتبط مباشرة بأجهزة البصمة والتعرف على الوجه، ويقوم باحتساب التأخير والغياب والعمل الإضافي، وإعداد مسيرات الرواتب بضغطة زر واحدة.',
    descriptionEn: 'An enterprise human resource management and payroll engine engineered with C# .NET and MS SQL Server. Integrates with biometric fingerprint/facial recognition terminals to calculate overtime, leaves, and salary slips.',
    technologies: ['C# .NET 8', 'WPF / WinForms', 'MS SQL Server', 'ZKTeco Biometric SDK', 'Crystal Reports'],
    category: 'system',
    imageUrl: '/assets/projects/albayan_hr.svg',
    featuresAr: [
      'ربط مباشر مع أجهزة البصمة (ZKTeco) وسحب سجلات الحضور والانصراف تلقائياً عبر الشبكة',
      'احتساب مسيرات الرواتب الشهرية والبدلات والاستقطاعات والتأمينات والسلف وقروض الموظفين',
      'إدارة رصيد الإجازات السنوية والمرضية مع دورة اعتماد إلكترونية تبدأ من الموظف وتمر بالمدير',
      'أرشفة عقود العمل والوثائق الرسمية للموظفين مع تنبيهات بانتهاء الإقامات والعقود'
    ],
    featuresEn: [
      'Automated background synchronization with ZKTeco biometric clocking terminals over TCP/IP',
      'Comprehensive payroll engine computing base salaries, allowances, overtime, and loan amortizations',
      'Self-service vacation request workflow routing approvals between supervisors and HR directors',
      'Employee personnel file vault providing expiration reminders for contracts and identification IDs'
    ],
    architectureDetailsAr: 'تطبيق سطح مكتب عالي الأمان مبني بـ C# .NET وقاعدة بيانات SQL Server علائقية محمية بصلاحيات مشددة مع نظام تقارير متقدم لطباعة كشوفات الرواتب وسندات الصرف.',
    architectureDetailsEn: 'Enterprise desktop system built with C# and SQL Server, enforcing strict role access controls and automated background tasks for biometric log retrieval.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'watheeq_archive',
    titleAr: 'وثيق للأرشفة — نظام التوثيق والأرشفة الإلكترونية المشفرة بـ Java',
    titleEn: 'Watheeq Archive — Secure Cryptographic Document Archiving (Java)',
    taglineAr: 'أرشفة الوثائق الرسمية، الفهرسة المتقدمة، التعرف الضوئي على الحروف (OCR)، والتشفير',
    taglineEn: 'Enterprise document digitization, OCR indexing, metadata tagging, and cryptographic retention',
    descriptionAr: 'منظومة أرشفة إلكترونية للشركات والمؤسسات الحكومية طُورت بلغة Java. تحول الملفات الورقية إلى أرشيف رقمي مفهرس، وتتعرف على النصوص العربية ضوئياً (OCR)، مع تشفير المحتوى بخوارزميات متقدمة لحمايته من التسريب.',
    descriptionEn: 'An institutional document management and archival system engineered with Java and Spring Boot. Features optical character recognition (OCR) for Arabic and English scans, full-text indexing, and tamper-proof cryptographic hashing.',
    technologies: ['Java 21', 'Spring Boot', 'MySQL', 'Tesseract OCR', 'Lucene Search', 'AES-256 Storage'],
    category: 'system',
    imageUrl: '/assets/projects/watheeq_archive.svg',
    featuresAr: [
      'محرك بحث متطور يبحث في محتويات الوثائق الممسوحة ضوئياً وليس فقط في أسمائها (Full-Text Search)',
      'تشفير كل وثيقة بمفتاح تشفير منفصل وحفظ بصمتها الرقمية (SHA-256) لمنع التلاعب بالمستندات',
      'شجرة تصنيف إدارية مرنة للأقسام والمجلدات والملفات مع أذونات قراءة وطباعة وتحميل محددة',
      'سجل تاريخي كامل (Audit Log) يوثق كل من فتح أو طبع أو شارك أي وثيقة مع الطابع الزمني'
    ],
    featuresEn: [
      'Full-text search engine indexing Arabic and English text extracted directly from scanned images via OCR',
      'Granular AES-256 document-level encryption paired with SHA-256 digital fingerprint validation',
      'Hierarchical corporate folder tree enforcing strict view, edit, print, and export authorization policies',
      'Forensic audit logging recording every document access, download, and modification with timestamps'
    ],
    architectureDetailsAr: 'مبني بـ Java 21 ومحرك Apache Lucene للفهرسة السريعة، مع خادم Spring Boot لتوفير حماية وأداء فائقين أثناء البحث في ملايين المستندات والصفحات المؤرشفة.',
    architectureDetailsEn: 'Engineered with Java 21 and Spring Boot, integrating Lucene indexing for sub-second retrieval across repositories containing millions of archived pages.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'itqan_exams',
    titleAr: 'إتقان للاختبارات — بنك الأسئلة والامتحانات الإلكترونية والتصحيح الآلي',
    titleEn: 'Itqan — Automated Online Examination & Proctoring Engine',
    taglineAr: 'بنوك أسئلة ذكية، اختبارات إلكترونية عشوائية، تصحيح فوري، وكشف محاولات الغش',
    taglineEn: 'Question bank repository, dynamic exam generation, automated grading, and anti-cheating proctoring',
    descriptionAr: 'نظام متقدم للاختبارات الإلكترونية والتقييم الأكاديمي والمهني. يتيح إنشاء بنوك أسئلة مصنفة حسب الصعوبة، وتوليد نماذج اختبارات متباينة تلقائياً لكل طالب، مع التصحيح الفوري وإصدار التقارير التحليلية.',
    descriptionEn: 'A high-concurrency online examination engine developed with PHP 8.2 and React.js. Features multi-level question banks, randomized exam generation, instant automated grading, and anti-cheating tab detection.',
    technologies: ['PHP 8.2', 'React.js', 'MySQL', 'WebSockets', 'Anti-Cheating API', 'Tailwind CSS'],
    category: 'web',
    imageUrl: '/assets/projects/itqan_exams.svg',
    featuresAr: [
      'توليد نماذج اختبارات متباينة وعشوائية لكل طالب لضمان النزاهة ومنع تناقل الإجابات',
      'نظام حماية يكتشف محاولات فتح تبويبات جديدة أو تصغير الشاشة وينهي الاختبار تلقائياً عند تكرار المخالفة',
      'تصحيح فوري للأسئلة الموضوعية مع شروحات وتبريرات للإجابات الصحيحة فور إعلان النتائج',
      'إحصائيات دقيقة لمعامل صعوبة كل سؤال ومؤشرات تمييز الطلاب المتفوقين'
    ],
    featuresEn: [
      'Dynamic permutation engine shuffling question order and multiple-choice options uniquely per student',
      'Client-side proctoring monitoring focus loss, window minimization, and external clipboard copying',
      'Sub-second automated grading delivering personalized feedback and rationale upon exam submission',
      'Psychometric question difficulty index analytics identifying ambiguous or defective questions'
    ],
    architectureDetailsAr: 'تطبيق ويب عالي الاستجابة بـ React.js وخادم PHP 8.2 مصمم لتحمل دخول آلاف الطلاب في نفس اللحظة لبدء الاختبار دون أي بطء أو انقطاع.',
    architectureDetailsEn: 'Resilient web platform pairing an optimized React test-taking interface with an asynchronous PHP/MySQL submission pipeline capable of high concurrent exam throughput.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'wesal_crm',
    titleAr: 'وصال CRM — منصة خدمة العملاء وإدارة التذاكر وتكامل قنوات الدعم',
    titleEn: 'Wesal — Omnichannel CRM & Support Ticket Management Suite',
    taglineAr: 'توحيد قنوات الواتساب، البريد، والموقع في صندوق محادثات واحد مع أتمتة الردود',
    taglineEn: 'Unified customer support desk integrating WhatsApp Cloud API, email tickets, and web chat',
    descriptionAr: 'منصة سحابية متقدمة لإدارة علاقات العملاء (CRM) ومكاتب الدعم الفني. توحد رسائل الواتساب والبريد والمحادثات المباشرة في صندوق وارد واحد، مع توزيع التذاكر على الموظفين وقياس زمن الاستجابة.',
    descriptionEn: 'An omnichannel customer relationship and support ticket management platform engineered with PHP Laravel, React.js, and WebSockets. Consolidates WhatsApp Cloud API, email tickets, and live chat into a single agent inbox.',
    technologies: ['PHP 8.2 / Laravel', 'React.js', 'MySQL', 'WebSockets', 'WhatsApp Cloud API', 'Tailwind CSS'],
    category: 'web',
    imageUrl: '/assets/projects/wesal_crm.svg',
    featuresAr: [
      'صندوق محادثات موحد (Omnichannel Inbox) يجمع محادثات الواتساب والتذاكر والبريد في مكان واحد',
      'توزيع ذكي للمحادثات على موظفي خدمة العملاء حسب التخصص وحالة التواجد لسرعة الرد',
      'قوالب ردود جاهزة وسريعة وبوت محادثة تفاعلي للرد على الاستفسارات المتكررة على مدار الساعة',
      'لوحة قيادة تفاعلية لقياس مؤشرات الأداء (SLA) ومعدل رضا العملاء ومتوسط زمن الحل'
    ],
    featuresEn: [
      'Unified omnichannel agent desk aggregating WhatsApp Business threads, email, and live website chats',
      'Intelligent round-robin routing assigning tickets based on agent availability and query subject',
      'Canned responses library and interactive automated bot flows answering frequent queries 24/7',
      'Real-time SLA analytics tracking first-response duration, resolution efficiency, and CSAT scores'
    ],
    architectureDetailsAr: 'منظومة سحابية بـ Laravel وReact.js مع خادم WebSockets لتحديث الرسائل فورياً لدى موظفي الدعم دون الحاجة لتحديث الصفحة، مع تكامل رسمي بـ WhatsApp Cloud API.',
    architectureDetailsEn: 'Real-time support architecture utilizing WebSockets for live conversation sync, connected to the official Meta WhatsApp Cloud API and an optimized MySQL archive.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'smart_pos_retail',
    titleAr: 'كاشير برو — نقاط البيع والمخازن السحابية بـ C# .NET وWPF',
    titleEn: 'CashierPro — High-Throughput Retail POS & Inventory Suite',
    taglineAr: 'نظام كاشير فائق السرعة يدعم الباركود والطباعة الحرارية والمزامنة دون إنترنت',
    taglineEn: 'Sub-millisecond barcode checkout terminal with offline cache & SQL Server sync',
    descriptionAr: 'منظومة نقاط بيع سريعة للمحلات التجارية ومحلات السوبرماركت والمولات، مبنية بأحدث معايير C# وWPF. تدعم شاشات اللمس، قارئ الباركود، موازين الديجيتال، طابعات الإيصالات الحرارية، وإدارة الصناديق وورديات الكاشير بدقة مطلقة.',
    descriptionEn: 'An ultra-responsive desktop POS station engineered in C# .NET with WPF and SQLite/SQL Server hybrid synchronization, featuring thermal receipt printing, weigh-scale integrations, and multi-shift cashier reconciliation.',
    technologies: ['C# .NET 8', 'WPF / XAML', 'SQL Server Express', 'SQLite Local Cache', 'Hardware POS APIs'],
    category: 'system',
    imageUrl: '/assets/projects/smart_pos_retail.svg',
    featuresAr: [
      'معالجة الفواتير في أقل من 50 ميلي ثانية حتى أثناء الضغط العالي',
      'دعم كامل للعمل أوفلاين مع مزامنة خلفية تلقائية عند عودة الاتصال',
      'تكامل مباشر مع طابعات الإيصالات، درج الكاشير، وقارئات الباركود 2D/QR',
      'إدارة متقدمة لورديات الكاشير، الجرد الفعلي، وفروقات الصندوق'
    ],
    featuresEn: [
      'Sub-50ms bill checkout latency under high transaction volumes',
      'Resilient offline operations with automatic background data sync',
      'Direct ESC/POS hardware interface for thermal printers and cash drawers',
      'Granular cashier shift management and automated register reconciliation'
    ],
    architectureDetailsAr: 'معمارية بنظام MVVM نظيف مبنية بـ C# .NET مع قاعدة بيانات محلية مدمجة للتسجيل فائق السرعة ومزامنة سحابية دورية مع خادم SQL Server المركزي.',
    architectureDetailsEn: 'Clean MVVM desktop architecture with local embedded caching for zero latency checkout, backed by periodic delta synchronization to centralized SQL Server clusters.',
    liveUrl: '#',
    githubUrl: '#',
    featured: true
  },
  {
    id: 'tameen_insurance',
    titleAr: 'تأمين تك — محرك مطالبات التأمين الصحي بـ Java Spring Boot',
    titleEn: 'TameenTech — Health Insurance Claims & Adjudication Engine',
    taglineAr: 'معالجة آلية لموافقات ومطالبات شركات التأمين والمستشفيات والمختبرات الطبية',
    taglineEn: 'High-volume medical policy underwriting and real-time claim adjudication engine',
    descriptionAr: 'محرك ضخم لمعالجة وتدقيق مطالبات التأمين الصحي للمستشفيات والمراكز الطبية وشركات التأمين. يعتمد على قواعد أعمال متطورة (Business Rules Engine) للتحقق الفوري من التغطية التأمينية والحدود القصوى للوثائق.',
    descriptionEn: 'An enterprise-grade medical claims adjudication platform built in Java with Spring Boot, Hibernate, and PostgreSQL. Handles policy eligibility checks, pre-authorizations, and provider settlements in real time.',
    technologies: ['Java 21', 'Spring Boot 3', 'PostgreSQL', 'Redis Queue', 'Docker', 'REST API'],
    category: 'system',
    imageUrl: '/assets/projects/tameen_insurance.svg',
    featuresAr: [
      'محرك تدقيق فوري لمطالبات التأمين والنسب المخصومة لكل مستفيد',
      'نظام تقديم طلبات الموافقة المسبقة إلكترونياً مع فحص التعارض الدوائي',
      'إصدار كشوفات التسوية المالية والمطالبات المعلقة للمستشفيات والعيادات',
      'سجل تدقيق كامل (Audit Log) غير قابل للتعديل لجميع العمليات المالية'
    ],
    featuresEn: [
      'Real-time automated claim adjudication against complex policy parameters',
      'Digital pre-authorization workflow with drug contraindication alerts',
      'Automated reconciliation billing statements for hospitals and providers',
      'Immutable audit trail recording every state change and transaction decision'
    ],
    architectureDetailsAr: 'خدمات مصغرة (Microservices) مبنية بـ Java Spring Boot وPostgreSQL مع طوابير Redis لمعالجة المطالبات المتزامنة والاتصال الآمن ببروتوكولات التشفير المصرفي.',
    architectureDetailsEn: 'Spring Boot microservices architecture with distributed Redis queuing, horizontal scaling via Docker containers, and robust financial ledger integrity.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'fleet_tracking',
    titleAr: 'أسطول GPS — منصة تتبع وإدارة أساطيل النقل واللوجستيات',
    titleEn: 'Ostool — Real-Time GPS Fleet Telematics & Driver Logistics',
    taglineAr: 'تتبع حركة الشاحنات والمركبات لحظياً مع مراقبة استهلاك الوقود وأجهزة IoT',
    taglineEn: 'Live vehicle telemetry, geofence trip dispatch, and fuel consumption analytics',
    descriptionAr: 'منظومة ذكية لإدارة وتتبع أساطيل الشاحنات والمركبات بالزمن الفعلي عبر أجهزة الـ GPS وبروتوكول TCP/UDP. توفر خريطة تفاعلية حية، تنبيهات تجاوز السرعة والمناطق الجغرافية (Geofences)، وتقارير الصيانة الوقائية واستهلاك الوقود.',
    descriptionEn: 'A high-performance vehicle telematics dashboard engineered with PHP, Node.js, MySQL, and Android Kotlin. Connects directly to Teltonika GPS tracker devices, translating telemetry pings into live maps and fleet analytics.',
    technologies: ['Android (Kotlin)', 'PHP 8.2', 'Node.js Socket.IO', 'MySQL', 'Leaflet / OpenStreetMap', 'TCP Protocols'],
    category: 'mobile',
    imageUrl: '/assets/projects/fleet_tracking.svg',
    featuresAr: [
      'خريطة حية تعرض مواقع جميع المركبات مع رسم خط السير ومحطات التوقف',
      'تنبيهات فورية عند الخروج عن المسار أو تجاوز السرعة القانونية',
      'مستشعرات ذكية لمراقبة فتح الأبواب، درجة حرارة التبريد، ومستوى خزان الوقود',
      'تطبيق أندرويد خاص بالسائقين لاستلام مهام التوصيل وتأكيد التسليم'
    ],
    featuresEn: [
      'Live interactive map displaying real-time vehicle vectors and trip history',
      'Instant push alerts on geofence breaches, speeding, and ignition anomalies',
      'Sensor telemetry monitoring cold-chain cargo temps and fuel level drops',
      'Dedicated Android driver companion app for manifest delivery signatures'
    ],
    architectureDetailsAr: 'مستمع بروتوكول TCP/UDP مبني بـ Node.js لمعالجة حزم بيانات الـ GPS وتخزينها في MySQL، مع واجهة إدارة مبنية بـ PHP وخرائط Leaflet وتطبيق أندرويد بلغة Kotlin.',
    architectureDetailsEn: 'Low-latency TCP/UDP daemon parsing NMEA/Teltonika telemetry, feeding a MySQL spatial database, accompanied by a native Android Kotlin dispatch client.',
    liveUrl: '#',
    githubUrl: '#',
    featured: true
  },
  {
    id: 'albaraka_accounting',
    titleAr: 'البركة المحاسبي — نظام القيود اليومية والميزانيات العمومية بـ C# .NET',
    titleEn: 'Al-Baraka — Enterprise General Ledger & Financial Reporting ERP',
    taglineAr: 'شجرة حسابات مرنة متعددة المستويات، قيود آلية، وميزان مراجعة فوري',
    taglineEn: 'Multi-tiered chart of accounts, automated journal entries, and real-time trial balances',
    descriptionAr: 'نظام محاسبي مالي متقدم يغطي كافة جوانب المحاسبة المالية: شجرة الحسابات، قيود اليومية، سندات القبض والصرف، ميزان المراجعة، قائمة الدخل، والميزانية العمومية، مع دعم مراكز التكلفة المتعددة والضرائب.',
    descriptionEn: 'A financial accounting software suite written in C# .NET and Microsoft SQL Server, featuring multi-currency transactions, dynamic cost-center allocation, depreciation schedules, and automated IFRS-compliant trial balance generation.',
    technologies: ['C# .NET', 'Windows Forms', 'SQL Server Enterprise', 'FastReport', 'LINQ to SQL'],
    category: 'system',
    imageUrl: '/assets/projects/albaraka_accounting.svg',
    featuresAr: [
      'دليل حسابات شجري تفاعلي يدعم عدداً غير محدود من المستويات والفروع',
      'توليد قيود اليومية آلياً من فواتير المبيعات والمشتريات وسندات الصندوق',
      'إصدار فوري لميزان المراجعة، الأرباح والخسائر، والميزانية العمومية الختامية',
      'نظام أرشفة إلكتروني مرفق مع كل قيد محاسبي لتوثيق المستندات والوصولات'
    ],
    featuresEn: [
      'Hierarchical tree chart of accounts supporting unlimited multi-branch nesting',
      'Automated journal voucher creation from invoicing, procurement, and payroll',
      'Instantaneous trial balance, profit & loss statement, and year-end balance sheet',
      'Integrated digital voucher attachment archive securing scanned bank slips'
    ],
    architectureDetailsAr: 'بنية C# .NET تعتمد على الإجراءات المخزنة (Stored Procedures) في SQL Server لضمان اتساق القيود المحاسبية ومبدأ القيد المزدوج، مع معالجة قيود الإغلاق السنوي بسرعة فائقة.',
    architectureDetailsEn: 'Robust C# client with heavy SQL Server transactional integrity, stored procedure triggers for double-entry enforcement, and sub-second multi-year financial reporting.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'smart_dentist',
    titleAr: 'عيادتي برو — نظام إدارة مراكز طب الأسنان ومخطط الأسنان الرقمي',
    titleEn: 'DentalPro — Clinical Practice & 3D Interactive Odontogram System',
    taglineAr: 'ملف المريض الإلكتروني، مخطط الأسنان التفاعلي، وجدولة المواعيد الذكية',
    taglineEn: 'Interactive tooth odontogram, patient clinical history, and automated appointment recall',
    descriptionAr: 'نظام شامل ومبتكر لعيادات ومراكز طب وجراحة الأسنان. يحتوي على مخطط أسنان تفاعلي (Interactive Odontogram) لتسجيل الحالات السريرية لكل سن، وإدارة مواعيد الزيارات وجلسات العلاج، مع أرشفة صور الأشعة والفواتير.',
    descriptionEn: 'A specialized dental clinic management platform equipped with a digital dental chart (odontogram), treatment plans, multi-visit appointment scheduler, and digital X-ray radiographic archive.',
    technologies: ['PHP 8.2 / Laravel', 'React.js', 'Canvas / SVG Odontogram', 'MySQL', 'Tailwind CSS'],
    category: 'web',
    imageUrl: '/assets/projects/smart_dentist.svg',
    featuresAr: [
      'مخطط أسنان رقمي تفاعلي (بالغين وأطفال) لتحديد نوع المعالجة والتركيبات',
      'خطة علاجية مقسمة على مراحل مع توضيح التكاليف والمدفوعات والمتبقي',
      'أرشفة صور الأشعة (Panoramic & Periapical X-Rays) ومقارنة التطور',
      'إرسال رسائل تذكير بالمواعيد عبر الواتساب والـ SMS تلقائياً للمرضى'
    ],
    featuresEn: [
      'Interactive vector odontogram for adult and pediatric dental charting',
      'Phased treatment planning linking clinical procedures to stage billing',
      'High-resolution radiographic image vault with side-by-side progression compare',
      'Automated WhatsApp appointment reminder triggers reducing patient no-shows'
    ],
    architectureDetailsAr: 'تطبيق ويب متطور بـ Laravel وReact.js مع مصفوفة SVG تفاعلية للأسنان تخزن إحداثيات وحالات كل سن في قاعدة بيانات MySQL بصيغة JSON مهيكلة.',
    architectureDetailsEn: 'Modern Laravel backend with React frontend rendering SVG canvas dental charts, persisting tooth status vectors in indexed MySQL schemas.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'jawda_qms',
    titleAr: 'جودة QMS — نظام إدارة الجودة ومعايير ISO وتوثيق التدقيق الداخلي',
    titleEn: 'Jawda — Enterprise Quality Management & ISO Compliance Suite',
    taglineAr: 'إدارة وثائق الجودة (SOPs)، حالات عدم المطابقة (NCR)، ومتابعة خطط التحسين',
    taglineEn: 'SOP document control, non-conformance tracking (CAPA), and internal audit management',
    descriptionAr: 'منظومة مؤسسية لإدارة أنظمة الجودة والامتثال لمعايير الآيزو (ISO 9001 / ISO 27001). تدير دورة حياة وثائق الإجراءات التشغيلية، وتسجيل حالات عدم المطابقة والإجراءات التصحيحية والوقائية (CAPA)، مع إدارة خطط التدقيق السنوي.',
    descriptionEn: 'An enterprise Quality Management System (QMS) built with PHP, MySQL, and TypeScript. Streamlines standard operating procedures (SOP), corrective and preventive actions (CAPA), risk registers, and audit schedules.',
    technologies: ['PHP 8.2', 'MySQL', 'TypeScript', 'Tailwind CSS', 'PDF Generation Engine'],
    category: 'web',
    imageUrl: '/assets/projects/jawda_qms.svg',
    featuresAr: [
      'إدارة إصدارات وثائق الجودة وإجراءات العمل (SOP) مع اعتماد التواقيع الرقمية',
      'سجل شامل لحالات عدم المطابقة (Non-Conformance) ومتابعة مسار إغلاقها',
      'خطة التدقيق الداخلي ومصفوفة تقييم المخاطر وتحديد الإجراءات الوقائية',
      'لوحات مؤشرات قياس أداء العمليات (KPIs) ونسب تحقيق أهداف الجودة'
    ],
    featuresEn: [
      'Document revision control for SOPs with role-based sign-off workflows',
      'Non-conformance and CAPA resolution tracking with automated escalations',
      'Internal audit agenda planner and dynamic corporate risk assessment register',
      'Executive KPI dashboards displaying continuous improvement milestones'
    ],
    architectureDetailsAr: 'نظام مبني بـ PHP 8.2 بتصميم MVC نظيف مع إدارة صارمة للصلاحيات وسجل تتبع غير قابل للحذف (Audit Trail) لجميع الوثائق والتعديلات.',
    architectureDetailsEn: 'Strict MVC PHP backend implementing role-based access control (RBAC), tamper-evident audit trails, and automated PDF export engines for ISO inspection readiness.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'omran_contracting',
    titleAr: 'عِمران — نظام إدارة شركات المقاولات والمشاريع الإنشائية والمستخلصات',
    titleEn: 'Omran — Construction ERP & Subcontractor Progress Billing Suite',
    taglineAr: 'حساب كميات، مستخلصات المقاولين والاستشاريين، ومتابعة الجداول الزمنية للمشاريع',
    taglineEn: 'Bill of quantities (BOQ), interim payment certificates (IPC), and structural milestones',
    descriptionAr: 'نظام ERP متخصص لإدارة شركات المقاولات والبناء والمشاريع الهندسية. يدير جداول الكميات (BOQ)، مستخلصات المالك ومقاولي الباطن، مراقبة المواد وتكاليف العمالة والمعدات في الموقع، ومقارنة الإنجاز الفعلي بالمخطط.',
    descriptionEn: 'A comprehensive construction and contracting ERP system written in C# .NET and SQL Server. Handles quantity surveying, owner & subcontractor IPC payment certificates, job-costing, and site equipment logs.',
    technologies: ['C# .NET', 'WPF', 'SQL Server', 'Excel Interop', 'Gantt Chart Engine'],
    category: 'system',
    imageUrl: '/assets/projects/omran_contracting.svg',
    featuresAr: [
      'إدخال جداول الكميات (BOQ) وحساب تكلفة البنود ونسب الإنجاز التراكمية',
      'إصدار مستخلصات جارية وختامية مع خصم الدفعات المقدمة وضمان الأعمال',
      'متابعة المواد الموردة للموقع ومقارنتها بالكميات المعتمدة في التصميم',
      'مخطط زمني للمشروع يوضح المسار الحرج (Critical Path) ونسب التأخير'
    ],
    featuresEn: [
      'Hierarchical Bill of Quantities (BOQ) with cumulative physical progress tracking',
      'Interim and final progress billing certificates factoring retention and advances',
      'On-site material inventory logs checking received supplies against tender specs',
      'Critical path method Gantt visualization monitoring project delay variance'
    ],
    architectureDetailsAr: 'تطبيق مكتبي متين بـ C# .NET مع قاعدة بيانات SQL Server تدعم ملايين السجلات وحسابات التكاليف الدقيقة للبناء وفق معايير فيديك (FIDIC).',
    architectureDetailsEn: 'Heavyweight C# .NET desktop application utilizing SQL Server stored calculations for precision FIDIC progress valuations and complex job-costing breakdowns.',
    liveUrl: '#',
    githubUrl: '#',
    featured: false
  },
  {
    id: 'safir_travel',
    titleAr: 'سفير ترافل — منظومة حجوزات الطيران والتأشيرات وبرامج العمرة والسياحة',
    titleEn: 'Safir Travel — Global Flight Ticketing & Umrah Package ERP',
    taglineAr: 'إصدار تذاكر الطيران، إدارة برامج العمرة والسياحة، وإصدار التأشيرات الإلكترونية',
    taglineEn: 'GDS flight booking connector, Umrah visa logistics, and hotel package allocations',
    descriptionAr: 'منظومة سحابية متكاملة لوكالات السفر والسياحة وخدمات الحج والعمرة. تدير حجز المقاعد وتذاكر الطيران، حجز الفنادق في مكة والمدينة، إصدار التأشيرات، وتنظيم تفويج المعتمرين مع متابعة كشوفات الحسابات والعمولات.',
    descriptionEn: 'A cloud-based tourism and pilgrimage management platform built in PHP Laravel, React, and MySQL. Manages flight booking inventories, Umrah packages, hotel bed allotment, visa issuance batches, and agency commission ledgers.',
    technologies: ['PHP 8.2 / Laravel', 'React.js', 'MySQL', 'REST API', 'PDF Invoicing', 'Tailwind CSS'],
    category: 'web',
    imageUrl: '/assets/projects/safir_travel.svg',
    featuresAr: [
      'إدارة باقات وبرامج العمرة الشاملة (طيران، فنادق، نقل بري، وإعاشة)',
      'إصدار فوري لتأشيرات المعتمرين مع فحص بيانات الجوازات وتواريخ الصلاحية',
      'حساب عمولات الوكلاء الخارجيين والفرعيين وإصدار سندات القبض الإلكترونية',
      'نظام تفويج آلي لربط المجموعات بالباصات والفنادق والمشرفين في الأراضي المقدسة'
    ],
    featuresEn: [
      'Comprehensive Umrah package builder aggregating flights, hotel rooms, and bus fleets',
      'Batch passport validation and automated electronic visa application manifests',
      'Sub-agent commission ledger with automated electronic vouchers and statement receipts',
      'Pilgrim group dispatch coordinator linking travel manifests to hotels and field supervisors'
    ],
    architectureDetailsAr: 'منظومة ويب متطورة بـ Laravel وReact.js مع واجهات برمجة تطبيقات RESTful وقاعدة بيانات MySQL محسنة للبحث السريع في حجوزات آلاف المعتمرين وتوليد الفواتير بتنسيق PDF.',
    architectureDetailsEn: 'High-availability Laravel and React web architecture utilizing indexed MySQL database schemas, distributed caching, and fast PDF manifest rendering for airport dispatch.',
    liveUrl: '#',
    githubUrl: '#',
    featured: true
  }
];

export const initialSkills: SkillItem[] = [
  {
    id: 'php',
    name: 'PHP 8.2+',
    category: 'backend',
    level: 95,
    color: '#777bb4',
    descriptionAr: 'لغة الخوادم الأساسية لبناء أنظمة الويب المتينة، معمارية MVC، برمجة كائنية متقدمة OOP، وحماية قصوى ضد ثغرات الويب.',
    descriptionEn: 'Core backend engineering language for building enterprise web applications, strict OOP, MVC architecture, and secure APIs.',
    useCasesAr: ['بناء الـ RESTful APIs', 'معمارية MVC النظيفة', 'تأمين الجلسات والبيانات', 'التعامل مع ملفات الخوادم وقواعد البيانات'],
    useCasesEn: ['High-throughput RESTful APIs', 'Clean MVC Architecture', 'Zero-trust Session Security', 'File & Stream Processing'],
    codeSnippet: '<?php\ndeclare(strict_types=1);\n\nclass SystemKernel {\n    public function __construct(private PDO $db) {}\n    public function execute(string $query): array {\n        $stmt = $this->db->prepare($query);\n        $stmt->execute();\n        return $stmt->fetchAll(PDO::FETCH_ASSOC);\n    }\n}'
  },
  {
    id: 'react',
    name: 'React.js',
    category: 'frontend',
    level: 92,
    color: '#61dafb',
    descriptionAr: 'بناء واجهات المستخدم التفاعلية الحديثة، Single Page Applications، إدارة الحالة بكفاءة، ودمج الرسوميات الثلاثية الأبعاد.',
    descriptionEn: 'Crafting responsive, high-performance SPAs, reactive component state machines, and immersive 3D/canvas viewports.',
    useCasesAr: ['واجهات الأنظمة المعقدة', 'دمج عوالم Three.js', 'إدارة الحالة بـ Hooks', 'تحسين سرعة التفاعل والاستجابة'],
    useCasesEn: ['Complex Enterprise Dashboards', 'Three.js 3D WebGL Integration', 'State Management & Custom Hooks', 'Ultra-low Latency Interactions'],
    codeSnippet: 'export function Terminal() {\n  const [active, setActive] = useState(true);\n  useEffect(() => {\n    console.log("Kernel booted.");\n  }, []);\n  return <div className="terminal-screen font-mono" />;\n}'
  },
  {
    id: 'mysql',
    name: 'MySQL & Database Design',
    category: 'database',
    level: 94,
    color: '#00758f',
    descriptionAr: 'تصميم وبناء قواعد البيانات العلائقية المعقدة، الفهرسة المتقدمة، الاستعلامات المحسنة، وضمان تكامل البيانات ومعاملات ACID.',
    descriptionEn: 'Relational database architecture, advanced indexing, query execution optimization, and strict ACID transaction guarantees.',
    useCasesAr: ['تصميم الجداول والـ Schemas', 'استعلامات الربط المعقدة (JOINs)', 'الفهرسة لتقليل زمن الاستعلام', 'النسخ الاحتياطي وإجراءات الأمان'],
    useCasesEn: ['Normalized Schema Design', 'Complex Multi-table Joins', 'B-Tree & Spatial Indexing', 'High-availability Backups'],
    codeSnippet: 'SELECT u.id, u.full_name, COUNT(o.id) as orders_count\nFROM users u\nINNER JOIN orders o ON o.user_id = u.id\nWHERE o.status = "completed"\nGROUP BY u.id\nORDER BY orders_count DESC;'
  },
  {
    id: 'android',
    name: 'Android Development',
    category: 'mobile',
    level: 90,
    color: '#3ddc84',
    descriptionAr: 'تطوير تطبيقات أندرويد أصلية (Native) وهجينة، التعامل مع مستشعرات الهاتف، نظام الـ GPS، والعمل بكفاءة بدون إنترنت.',
    descriptionEn: 'Native Android ecosystem engineering, Jetpack components, location/GPS tracking, and resilient offline-first architectures.',
    useCasesAr: ['تطبيقات النقل والمواقع الحية', 'أكشاك الخدمات الذاتية (Kiosks)', 'تخزين البيانات بـ Room DB', 'تكامل الكاميرا وقارئات الـ QR'],
    useCasesEn: ['Live Transit & Telemetry Apps', 'Self-service Android Kiosks', 'Room Database Local Caching', 'Camera & Hardware Integrations'],
    codeSnippet: 'class MainActivity : AppCompatActivity() {\n    private lateinit var binding: ActivityMainBinding\n    override fun onCreate(savedInstanceState: Bundle?) {\n        super.onCreate(savedInstanceState)\n        binding = ActivityMainBinding.inflate(layoutInflater)\n        setContentView(binding.root)\n    }\n}'
  },
  {
    id: 'kotlin',
    name: 'Kotlin',
    category: 'languages',
    level: 88,
    color: '#7f52ff',
    descriptionAr: 'اللغة الرسمية الحديثة لتطبيقات أندرويد، تدعم البرمجة الوظيفية، الأمان من مؤشرات العدم (Null Safety)، والـ Coroutines المتزامنة.',
    descriptionEn: 'Modern expressive language for Android and backend services, featuring first-class coroutines and compile-time null safety.',
    useCasesAr: ['تطبيقات أندرويد الحديثة', 'معالجة العمليات في الخلفية بـ Coroutines', 'كود نظيف وآمن من الأخطاء', 'تكامل سلس مع مكتبات جافا'],
    useCasesEn: ['Modern Android Architecture', 'Asynchronous Coroutines', 'Robust Null-safe Business Logic', 'Java Interoperability']
  },
  {
    id: 'laravel',
    name: 'Laravel Framework',
    category: 'backend',
    level: 90,
    color: '#ff2d20',
    descriptionAr: 'أقوى أطر عمل PHP لبناء المنظومات السريعة، Eloquent ORM، نظام المصادقة والصلاحيات المتطورة، والـ Queues المجدولة.',
    descriptionEn: 'Premier PHP web application framework with expressive Eloquent ORM, robust authentication, queues, and artisan tooling.',
    useCasesAr: ['أنظمة المؤسسات الإدارية', 'واجهات API المؤتمنة بـ Sanctum', 'جدولة المهام والرسائل', 'التحكم بالصلاحيات متعددة الأدوار (RBAC)'],
    useCasesEn: ['Enterprise Management Systems', 'Sanctum/JWT API Gateways', 'Scheduled Background Queues', 'Role-Based Access Control (RBAC)']
  },
  {
    id: 'javascript',
    name: 'JavaScript (ES6+)',
    category: 'languages',
    level: 94,
    color: '#f7df1e',
    descriptionAr: 'إتقان عميق لمحرك جافاسكريبت، البرمجة غير المتزامنة (Async/Await)، معالجة البيانات، والتفاعل المباشر مع واجهات المتصفح.',
    descriptionEn: 'Deep mastery of modern JavaScript, asynchronous event loops, DOM manipulation, and dynamic client runtime systems.',
    useCasesAr: ['التحكم بواجهات المستخدم التفاعلية', 'التواصل بالزمن الفعلي عبر WebSockets', 'تطوير مكتبات الأدوات والألعاب', 'البرمجة الوظيفية والـ Closures'],
    useCasesEn: ['Interactive UI Animation', 'Real-time WebSocket Streaming', 'Utility Tooling & Canvas Renderers', 'Functional Programming Patterns']
  },
  {
    id: 'java',
    name: 'Java (Core & Enterprise)',
    category: 'languages',
    level: 86,
    color: '#f89820',
    descriptionAr: 'لغة رصينة للبرمجة الكائنية الصارمة، تطوير تطبيقات سطح المكتب وأندرويد، ومعالجة البيانات المتوازية عبر الـ Multi-threading.',
    descriptionEn: 'Rigorous object-oriented engineering, multi-threading, concurrency control, and backend system foundations.',
    useCasesAr: ['تطوير أنظمة سطح المكتب والشركات', 'تطبيقات أندرويد الكلاسيكية', 'الخوارزميات وهياكل البيانات', 'معالجة المهام المتوازية الكثيفة'],
    useCasesEn: ['Desktop & Enterprise Tooling', 'Legacy Android Native Apps', 'Algorithms & Data Structures', 'Concurrent Multi-threaded Processing']
  },
  {
    id: 'csharp',
    name: 'C# & .NET',
    category: 'languages',
    level: 85,
    color: '#239120',
    descriptionAr: 'تطوير البرمجيات والأنظمة التجارية القوية لبيئات ويندوز والخوادم، بناء قواعد البيانات، وتطبيقات إدارة المبيعات ونقاط البيع.',
    descriptionEn: 'Building robust commercial software on Microsoft .NET, POS retail solutions, and enterprise database integrations.',
    useCasesAr: ['أنظمة نقاط البيع والمحاسبة (POS)', 'برامج إدارة المخازن وسطح المكتب', 'الاتصال بقواعد بيانات SQL Server / MySQL', 'بناء واجهات سطح مكتب سريعة'],
    useCasesEn: ['Point of Sale (POS) Systems', 'Inventory & Accounting Desktop Apps', 'Database Layer Integrations', 'High-performance Desktop GUIs']
  },
  {
    id: 'flutter',
    name: 'Flutter & Dart',
    category: 'mobile',
    level: 88,
    color: '#02569b',
    descriptionAr: 'تطوير تطبيقات متعددة المنصات (Android & iOS) بكود موحد فائق السرعة، واجهات عصرية جذابة وتجربة مستخدم سلسة.',
    descriptionEn: 'Cross-platform mobile development for Android & iOS using single codebase with 60/120fps native-compiled graphics.',
    useCasesAr: ['تطبيقات المتاجر والطلبات السريعة', 'واجهات مستخدم ذات حركات جذابة', 'التطبيقات متعددة المنصات', 'التكامل مع خدمات الـ Firebase والـ APIs'],
    useCasesEn: ['E-Commerce & Food Delivery Apps', 'Fluid Motion & Micro-interactions', 'Multi-platform Mobile Releases', 'Firebase & REST API Integrations']
  },
  {
    id: 'python',
    name: 'Python',
    category: 'languages',
    level: 85,
    color: '#3776ab',
    descriptionAr: 'أتمتة المهام، معالجة البيانات الضخمة، بناء واجهات الذكاء الاصطناعي، وتحليل الصور بالرؤية الحاسوبية.',
    descriptionEn: 'Data processing, backend microservices, automation scripts, and computer vision neural network pipelines.',
    useCasesAr: ['نماذج الذكاء الاصطناعي وتحليل الصور', 'أتمتة العمليات والـ Web Scraping', 'بناء الـ Microservices بـ FastAPI', 'تحليل البيانات والإحصائيات'],
    useCasesEn: ['AI Inference & Computer Vision', 'Scripting & Automation Pipelines', 'FastAPI Lightweight Backends', 'Data Analytics & Modeling']
  },
  {
    id: 'htmlcss',
    name: 'HTML5 & CSS3 / Tailwind',
    category: 'frontend',
    level: 96,
    color: '#e34f26',
    descriptionAr: 'بناء هياكل صفحات متوافقة مع معايير الويب العالمية، تصميم متجاوب لكافة الشاشات، وتأثيرات بصرية سينمائية متقدمة.',
    descriptionEn: 'Semantic markup, accessible responsive architecture, CSS custom properties, and fluid cyber visual effects.',
    useCasesAr: ['تصميم متجاوب 100% للهواتف والشاشات', 'تأثيرات Glassmorphism والإضاءة', 'دعم كامل للاتجاه العربي RTL', 'تحسين محركات البحث SEO والأداء'],
    useCasesEn: ['Pixel-perfect Responsive Layouts', 'Glassmorphism & Cyber Aesthetics', 'Native RTL/LTR Bi-directional UI', 'Core Web Vitals Optimization']
  }
];

export const initialServices: ServiceItem[] = [
  {
    id: 'web-dev',
    titleAr: 'تصميم وتطوير المواقع والمنصات الإلكترونية',
    titleEn: 'Full-Stack Web & SaaS Platform Engineering',
    descriptionAr: 'بناء مواقع وتطبيقات ويب متكاملة من الصفر، تجمع بين قوة الأداء، التصميم البصري الحديث، والتوافق التام مع كافة الشاشات والأجهزة.',
    descriptionEn: 'Architecting end-to-end responsive web applications and scalable SaaS platforms with rock-solid performance and bespoke design.',
    deliverablesAr: [
      'واجهات تفاعلية سريعة بتقنية Single Page Application',
      'لوحات تحكم إدارية متكاملة للتحكم في كافة المحتويات',
      'تهيئة محركات البحث (SEO) والأداء الفائق',
      'تكامل مع بوابات الدفع الإلكترونية المحلية والعالمية'
    ],
    deliverablesEn: [
      'Reactive single-page client applications',
      'Executive content & data management consoles',
      'Lighthouse 95+ performance & SEO optimization',
      'Payment gateway integrations & webhooks'
    ],
    techStack: ['React.js', 'PHP 8.2', 'MySQL', 'Tailwind CSS', 'REST API'],
    icon: 'Globe'
  },
  {
    id: 'php-mysql',
    titleAr: 'برمجة أنظمة PHP وMySQL المتطورة',
    titleEn: 'High-Performance PHP & MySQL Architectures',
    descriptionAr: 'تطوير الواجهات الخلفية (Backends) وقواعد البيانات المعقدة بكود نظيف وفق معمارية MVC وبرمجة كائنية OOP مع حماية قصوى ضد الاختراق.',
    descriptionEn: 'Developing robust server-side infrastructures and optimized relational schemas strictly enforcing OOP and OWASP security standards.',
    deliverablesAr: [
      'معمارية برمجية نقية (MVC Architecture)',
      'حماية شاملة ضد ثغرات SQLi, XSS, CSRF',
      'فهرسة متقدمة لقواعد البيانات لضمان سرعة الاستعلامات الضخمة',
      'واجهات برمجة تطبيقات REST APIs موثقة وجاهزة للتطبيقات'
    ],
    deliverablesEn: [
      'Pure modular MVC codebase with zero bloat',
      'Strict OWASP security hardening against injections & tampering',
      'Optimized indexing for million-row queries',
      'Standardized JSON REST API endpoints'
    ],
    techStack: ['PHP 8.2', 'PDO', 'MySQL', 'JWT', 'REST API'],
    icon: 'Server'
  },
  {
    id: 'android-apps',
    titleAr: 'تطوير تطبيقات أندرويد (Android Development)',
    titleEn: 'Native & Modern Android Mobile Engineering',
    descriptionAr: 'برمجة تطبيقات هواتف ذكية لنظام أندرويد بأداء سلس وتجربة استخدام راقية، تدعم العمل بدون إنترنت والاتصال بمستشعرات الأجهزة.',
    descriptionEn: 'Crafting responsive, native-feel Android mobile applications with offline storage, real-time geolocation, and intuitive UX.',
    deliverablesAr: [
      'تطبيقات أندرويد أصلية بلغة Kotlin وJava',
      'دعم كامل للتخزين المحلي (Offline-First Architecture)',
      'تكامل مع خرائط Google وخدمات تحديد المواقع GPS',
      'إشعارات فورية وتكامل مع الكاميرا والماسحات'
    ],
    deliverablesEn: [
      'Native Android builds using Kotlin/Java',
      'Offline-first synchronization with Room DB',
      'GPS location telemetry & mapping integration',
      'Push notification dispatchers and hardware camera links'
    ],
    techStack: ['Kotlin', 'Android SDK', 'Room DB', 'Retrofit', 'Firebase'],
    icon: 'Smartphone'
  },
  {
    id: 'ui-ux',
    titleAr: 'تصميم واجهات وتجربة المستخدم UI/UX',
    titleEn: 'UI/UX Design Systems & Spatial Craft',
    descriptionAr: 'ابتكار واجهات رقمية جذابة وسهلة الاستخدام ترتكز على دراسة سلوك المستخدم وتطبيق مبادئ علم النفس البصري والتصميم العصري.',
    descriptionEn: 'Designing immersive, intuitive visual systems anchored in behavioral psychology, accessibility standards, and modern aesthetic elegance.',
    deliverablesAr: [
      'نماذج تفاعلية ونظم تصميم متناسقة (Design Systems)',
      'دعم كامل للتجربة العربية RTL والتجربة الإنجليزية LTR',
      'تصاميم مظلمة سينمائية Dark Mode مع تباين لوني مريح',
      'مخططات تدفق المستخدم والـ Wireframes'
    ],
    deliverablesEn: [
      'Atomic design systems and component palettes',
      'Flawless bi-directional RTL and LTR ergonomics',
      'Dark cinematic palettes with WCAG AA compliance',
      'High-fidelity prototypes and user journey maps'
    ],
    techStack: ['Figma', 'CSS Architecture', 'Tailwind CSS', 'Motion'],
    icon: 'Palette'
  },
  {
    id: 'databases',
    titleAr: 'بناء وهندسة قواعد البيانات (Database Architecture)',
    titleEn: 'Relational Database Architecture & Tuning',
    descriptionAr: 'تخطيط وبناء قواعد البيانات العلائقية المعقدة، إزالة التكرار (Normalization)، تحسين الأداء، وإعداد آليات النسخ الاحتياطي التلقائي.',
    descriptionEn: 'Engineering scalable relational schemas, schema normalization, query execution profiling, and automated backup routines.',
    deliverablesAr: [
      'مخططات الكيانات والعلاقات (ER Diagrams)',
      'تحسين سرعة الاستعلامات المعقدة ومراقبة الـ Indexes',
      'إجراءات الحفظ المخزنة (Stored Procedures & Triggers)',
      'استراتيجيات الاسترداد من الكوارث والحماية'
    ],
    deliverablesEn: [
      'Comprehensive Entity Relationship Diagrams (ERD)',
      'Query profiling and index optimization',
      'ACID transaction triggers and stored routines',
      'Automated disaster recovery scripts'
    ],
    techStack: ['MySQL', 'PostgreSQL', 'PDO', 'Database Profilers'],
    icon: 'Database'
  },
  {
    id: 'erp-commercial',
    titleAr: 'تطوير الأنظمة الإدارية والتجارية (ERP & POS)',
    titleEn: 'Commercial ERP, POS & Business Software',
    descriptionAr: 'برمجة أنظمة مخصصة لإدارة الشركات، المخازن، المبيعات، الفواتير، ونقاط البيع السريعة التي تضمن دقة الحسابات وسرعة الدورة التشغيلية.',
    descriptionEn: 'Building custom enterprise resource planning, warehouse tracking, and point-of-sale systems built for accuracy and throughput.',
    deliverablesAr: [
      'نظام إدارة مخازن وجرد بالباركود في الزمن الفعلي',
      'نظام مبيعات وفواتير إلكترونية متوافق مع الطابعات الحرارية',
      'تقارير محاسبية مفصلة وكشوفات حساب العملاء والموردين',
      'إدارة صلاحيات الموظفين والمستخدمين بمستويات أمان عالية'
    ],
    deliverablesEn: [
      'Real-time barcode inventory & stock reconciliation',
      'Thermal receipt printing & electronic billing modules',
      'Detailed balance sheets and ledger analytics',
      'Granular role-based staff permissions'
    ],
    techStack: ['PHP 8.2', 'MySQL', 'C# / .NET', 'JavaScript', 'REST API'],
    icon: 'Briefcase'
  },
  {
    id: 'custom-solutions',
    titleAr: 'حلول برمجية مخصصة وتكامل الأنظمة (Custom Software & APIs)',
    titleEn: 'Custom Software Engineering & System Integration',
    descriptionAr: 'تحويل الأفكار والعمليات المعقدة إلى برمجيات حقيقية مخصصة، ربط الأنظمة غير المتوافقة، وأتمتة المهام الروتينية لرفع الإنتاجية.',
    descriptionEn: 'Custom software modules, bespoke API bridges between disparate platforms, and background workflow automation.',
    deliverablesAr: [
      'بوابات ربط API بين المنصات المختلفة',
      'أتمتة العمليات والمهام المكررة لتوفير الوقت والتكلفة',
      'حلول الذكاء الاصطناعي ومعالجة البيانات المتخصصة',
      'استشارات فنية وهندسة الحلول للمشاريع الناشئة'
    ],
    deliverablesEn: [
      'Secure third-party API integration bridges',
      'Workflow automation and batch background jobs',
      'Domain-specific intelligence and analytics plugins',
      'Technical consulting and software architecture reviews'
    ],
    techStack: ['PHP', 'Python', 'React', 'REST', 'WebSockets'],
    icon: 'Cpu'
  }
];
