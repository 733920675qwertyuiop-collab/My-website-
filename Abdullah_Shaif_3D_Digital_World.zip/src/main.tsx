import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Global Cybernetic Ripple Effect for all UI elements
if (typeof window !== 'undefined') {
  window.addEventListener('pointerdown', (e: PointerEvent) => {
    // Check if target is clickable or interactive (button, a, input, select, card, or element with cursor-pointer)
    const target = e.target as HTMLElement | null;
    if (!target) return;

    // Create ripple element
    const ripple = document.createElement('div');
    ripple.className = 'cyber-ripple';
    const size = Math.max(window.innerWidth, window.innerHeight) * 0.12;
    const clampedSize = Math.max(60, Math.min(size, 180));

    ripple.style.width = `${clampedSize}px`;
    ripple.style.height = `${clampedSize}px`;
    ripple.style.left = `${e.clientX}px`;
    ripple.style.top = `${e.clientY}px`;

    document.body.appendChild(ripple);

    // Clean up after animation finishes
    setTimeout(() => {
      if (ripple.parentNode) {
        ripple.parentNode.removeChild(ripple);
      }
    }, 700);
  }, { passive: true });
}

createRoot(document.getElementById('root')!).render(<App />);
