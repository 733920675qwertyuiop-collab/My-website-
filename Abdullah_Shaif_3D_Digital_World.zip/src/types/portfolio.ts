export interface ProfileInfo {
  nameAr: string;
  nameEn: string;
  titleAr: string;
  titleEn: string;
  subTitleAr: string;
  subTitleEn: string;
  bioAr: string;
  bioEn: string;
  avatarUrl: string;
  originalPhotoUrl: string;
  email: string;
  phone: string;
  whatsapp: string;
  locationAr: string;
  locationEn: string;
  github: string;
  linkedin: string;
  telegram: string;
  yearsExperience: number;
  completedProjects: number;
  satisfiedClients: number;
  availableForHire: boolean;
}

export interface SkillItem {
  id: string;
  name: string;
  category: 'backend' | 'frontend' | 'mobile' | 'database' | 'languages';
  level: number; // 0 - 100
  color: string;
  descriptionAr: string;
  descriptionEn: string;
  useCasesAr: string[];
  useCasesEn: string[];
  codeSnippet?: string;
}

export interface ProjectItem {
  id: string;
  titleAr: string;
  titleEn: string;
  taglineAr: string;
  taglineEn: string;
  descriptionAr: string;
  descriptionEn: string;
  technologies: string[];
  category: 'web' | 'mobile' | 'system' | 'ai';
  imageUrl: string;
  featuresAr: string[];
  featuresEn: string[];
  liveUrl?: string;
  githubUrl?: string;
  architectureDetailsAr?: string;
  architectureDetailsEn?: string;
  featured: boolean;
}

export interface ServiceItem {
  id: string;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  deliverablesAr: string[];
  deliverablesEn: string[];
  techStack: string[];
  icon: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone?: string;
  serviceInterest?: string;
  message: string;
  createdAt: string;
  isRead: boolean;
}

export type SceneStation = 
  | 'home' 
  | 'about' 
  | 'skills' 
  | 'projects' 
  | 'services' 
  | 'contact';
